DRIFTSKETCH 0.9.6 — VETËM TRAFFIC CONES
========================================

DriftSketch regjistron vijën ku vozit dhe vendos vetëm traffic cones në të dy
anët, pastaj mund ta përdorësh pistën në replay. Versioni 0.9.6 zëvendëson
mënyrën e rëndë të 0.9.5: konat nuk krijohen më si makina JBeam të veçanta.
Kur vetura prek hapësirën e konit, mesh-i anohet dhe rrëzohet me animacion të
lehtë. Kjo është ndërveprim vizual, jo simulim fizik me masë/collision.

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, çaktivizoji/fshiji versionet e
   vjetra të DriftSketch (mos i mbaj dy ZIP-a aktive njëkohësisht).
2. Kopjo DriftSketch_v0.9.6.zip në folderin Mods pa e nxjerrë nga ZIP-i.
3. Aktivizo DriftSketch te Mod Manager nëse duhet dhe rinise BeamNG.drive.
4. Në hartë: App menu > Add App > DriftSketch.

Nëse po përditëson nga 0.9.5, pastro skenën/reload level-in pas instalimit.
0.9.6 përpiqet t'i fshijë vetë automjetet-kona JBeam të lëna nga versioni i
vjetër kur ngarkohet extension-i, bëhet Rebuild ose shtypet Clear.

PËRDORIMI
---------
1. Rregullo hapësirën mes konave dhe distancën nga vetura.
2. Lëre "Rrëzohen kur preken" ON për animacionin vizual të rrëzimit. OFF i lë
   konat drejt.
3. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
4. Hap replay-in normal të BeamNG; konat e krijuara mbeten në skenë.
5. REBUILD i rindërton drive-t e ruajtura me cilësimet aktuale. CLEAR heq
   konat dhe drive-t e krijuara nga DriftSketch.

SHËNIM I RËNDËSISHËM PËR NDËRVEPRIMIN
------------------------------------
Konat e 0.9.6 janë mesh-e vizuale pa collision të fortë. Kur vëllimi i makinës
i prek, koni anohet dhe zhvendoset pak; makina mund të kalojë përmes tij dhe
nuk godet një objekt të palëvizshëm si mur. Nuk ka nga një automjet JBeam për
çdo kon, ndaj kjo mënyrë shmang koston e madhe të performancës që u pa në 0.9.5.
Nuk pretendohet si fizikë e vërtetë 1 kg. Nuk është kryer test brenda lojës
për këtë paketim; animacioni duhet provuar në BeamNG nga përdoruesi.

ÇFARË KA NDRYSHUAR NË 0.9.6
---------------------------
- U hoqën automjetet JBeam për çdo kon; konat e 0.9.6 janë TSStatic me
  collision të çaktivizuar.
- U shtua animacion i lehtë i rrëzimit kur koni hyn në OOBB-në e veturës.
- Gjatë ngarkimit, Rebuild dhe Clear, pastrohen automjetet-kona të mbetura
  nga 0.9.5 që të mos vazhdojnë të konsumojnë FPS.
- U hoq pretendimi se konat e 0.9.5 sillen si objekte fizike 1 kg.
- U ruajt workflow i regjistrimit, pistave të ruajtura, Rebuild dhe Clear.

ÇFARË KA NDRYSHUAR NË 0.9.5
---------------------------
- DriftSketch u bë vetëm për traffic cones: u hoqën gomat, kerbs, apex bumps,
  flamujt, tabelat e frenimit, START/FINISH dhe rrathët.
- Kufiri i konave u bë global për skenën (50–500, parazgjedhja 200).
- Ky version kishte një JBeam vehicle për secilin kon; në testin real kjo
  shkaktoi kone të padukshme/të paqëndrueshme dhe rënie të madhe të FPS-it.
  Përdor 0.9.6 në vend të 0.9.5.

CILËSIMET
---------
- Hapësira: largësia mes konave në të njëjtën vijë.
- Hapësira nga kerri: largësia e konave nga ana e veturës; gjerësia e makinës
  matet automatikisht.
- Kufiri total i konave: numri maksimal i mesh-eve për tërë skenën.
- Lartësia rezervë: përdoret vetëm kur raycast-i nuk gjen sipërfaqen e tokës.
- Vijë e lëmuar: zbut korrigjimet e timonit dhe dridhjet e drift-it.
- Zgjero në drift: hap korridorin lokalisht kur vetura është anash.
- Ruaj pistat: mban drive-t e mëparshme; ato ndajnë të njëjtin kufi total.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
