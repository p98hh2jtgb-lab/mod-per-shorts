load('driftModes')
setExtensionUnloadMode('driftModes', 'manual')
