-- Drift assist v4 (Arab / Tokyo / Formula): latches the drift, holds it until you steer the other way. SAFE rigid-torque version. Spreads the force over every node of the car
-- like a real rigid yaw torque, so the body never gets stressed or torn apart.
local M = {}
local STEER_SIGN = 1      -- if drifts kick the WRONG way, change to -1
local PHYS_HZ = 2000
local MAX_ALPHA = 3.5     -- hard cap on assist (rad/s^2). Lower = gentler/safer, higher = stronger anti-spin
local P = {
  target = 45, max = 62,
  init = 1.0, hold = 1.2, save = 3.0, trans = 2.2,
  latchAngle = 32,   -- slip angle where the drift gets 'locked in'
  holdMin = 28, holdMax = 58,
  minSpeed = 6, saveSpeed = 2.5,
}
local enabled = false
local prevFwd = nil
local alphaSmooth = 0     -- smoothed assist, nose-right positive
local latch, holdAngle, trans = 0, 45, 0
local transT, steerOppT, noThrT = 0, 0, 0

function M.setEnabled(e)
  enabled = e
  prevFwd = nil
  alphaSmooth = 0
  latch, holdAngle, trans = 0, 45, 0
  transT, steerOppT, noThrT = 0, 0, 0
end

local function clamp(x, a, b) return math.max(a, math.min(b, x)) end

local function applyYaw(alphaRight, dt)
  local up = obj:getDirectionVectorUp()
  local alphaCCW = -alphaRight
  local comp = clamp(dt * PHYS_HZ, 1, 20)
  -- center of mass
  local sx, sy, sz, sm = 0, 0, 0, 0
  local nodes = v.data.nodes
  for cid, n in pairs(nodes) do
    local m = n.nodeWeight or 0
    if m > 0 then
      local p = obj:getNodePosition(cid)
      sx = sx + p.x * m; sy = sy + p.y * m; sz = sz + p.z * m; sm = sm + m
    end
  end
  if sm <= 0 then return end
  local com = vec3(sx / sm, sy / sm, sz / sm)
  for cid, n in pairs(nodes) do
    local m = n.nodeWeight or 0
    if m > 0 then
      local r = obj:getNodePosition(cid) - com
      local f = up:cross(r) * (m * alphaCCW * comp)
      obj:applyForceVector(cid, f)
    end
  end
end

function M.updateGFX(dt)
  if not enabled or dt <= 0 then return end
  local vel = obj:getVelocity()
  local fwd = obj:getDirectionVector()
  local up = obj:getDirectionVectorUp()
  local right = fwd:cross(up)
  local speed = vel:length()

  local yawRate = 0   -- positive = nose turning right
  if prevFwd then yawRate = -(prevFwd:cross(fwd)):dot(up) / dt end
  prevFwd = vec3(fwd.x, fwd.y, fwd.z)

  local target = 0
  if speed >= P.saveSpeed then
    local vf, vl = vel:dot(fwd), vel:dot(right)
    local angle = math.deg(math.atan2(vl, vf))
    local aAbs, aSign = math.abs(angle), (angle >= 0 and 1 or -1)
    local throttle = electrics.values.throttle or 0
    local hbrake = electrics.values.parkingbrake or 0
    local steer = (electrics.values.steering_input or 0) * STEER_SIGN
    local yawDir, strength = 0, 0
    local spinning = (yawRate * aSign) < -0.8 and aAbs > 35

    -- keep / release the locked-in drift
    if latch ~= 0 then
      if aSign ~= latch or aAbs < 12 or speed < P.minSpeed * 0.7 or vf <= 0 then
        latch = 0
      else
        holdAngle = clamp(holdAngle + (aAbs - holdAngle) * clamp(dt * 0.6, 0, 1), P.holdMin, P.holdMax)
        noThrT = (throttle < 0.1) and (noThrT + dt) or 0
        if noThrT > 0.8 then latch = 0 end
        -- player steers the OTHER way -> swing the car to the other side
        steerOppT = (steer * latch > 0.4) and (steerOppT + dt) or 0
        if steerOppT > 0.12 and latch ~= 0 then
          trans = (steer > 0) and 1 or -1
          transT, steerOppT, latch = 0, 0, 0
        end
      end
    elseif trans == 0 and aAbs >= P.latchAngle and vf > 0 and speed >= P.minSpeed and throttle > 0.2 then
      latch = aSign
      holdAngle = clamp(aAbs, P.holdMin, P.holdMax)
      noThrT, steerOppT = 0, 0
    end

    if aAbs > P.max or (spinning and aAbs > 35) then
      -- ANTI-SPIN always wins
      trans = 0
      yawDir = aSign
      local over = math.max(aAbs - P.max, 0) / 20
      local rate = clamp(math.abs(yawRate) / 3, 0, 1)
      strength = P.save * clamp(0.4 + over + rate, 0.4, 1.5)
    elseif trans ~= 0 then
      -- TRANSITION: swing the nose toward the new side
      transT = transT + dt
      if (aSign == -trans and aAbs > 25) or transT > 1.5 or vf <= 0 then
        trans = 0
      else
        yawDir = trans
        strength = P.trans * (0.6 + 0.4 * throttle)
      end
    elseif latch ~= 0 then
      -- HOLD the long drift at the angle you were at
      local err = (holdAngle - aAbs) / holdAngle
      yawDir = -aSign * (err > 0 and 1 or -1)
      strength = P.hold * math.abs(err) * (0.6 + throttle)
    elseif speed >= P.minSpeed and vf > 0 and (hbrake > 0.3 or throttle > 0.3) and math.abs(steer) > 0.2 and aAbs < P.latchAngle then
      -- INITIATE
      yawDir = steer > 0 and 1 or -1
      strength = P.init * math.abs(steer) * (hbrake > 0.3 and 1.3 or 1)
    end
    target = clamp(yawDir * strength * 0.8, -MAX_ALPHA, MAX_ALPHA)
  end

  -- smooth so the push ramps in/out gently (no sudden jolts)
  alphaSmooth = alphaSmooth + (target - alphaSmooth) * clamp(dt * 8, 0, 1)
  if math.abs(alphaSmooth) < 0.02 then return end
  applyYaw(alphaSmooth, dt)
end

return M
