local M = {}
local on = false

local function apply(veh)
  if not veh then return end
  veh:queueLuaCommand("extensions.load('driftAssist'); driftAssist.setEnabled(" .. tostring(on) .. ")")
end
local function applyPlayer() apply(be:getPlayerVehicle(0)) end

function M.toggle()
  on = not on
  applyPlayer()
  guihooks.message({txt = on and "Formula Drift Mode: ON" or "Formula Drift Mode: OFF"}, 4, "driftmode")
end

function M.onVehicleSwitched() applyPlayer() end
function M.onVehicleSpawned(id) local v = be:getObjectByID(id); if v then apply(v) end end
return M
