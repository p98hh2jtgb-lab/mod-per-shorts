BEAMDRIFT 1.2.0 — CONFIGURABLE DRIFT ASSIST
===========================================

A standalone BeamNG.drive mod with a live in-game tuning panel. BeamDrift helps
initiate and hold a controlled drift angle, assists transitions and adds a
bounded anti-spin response. Tune it from the BeamDrift app without editing Lua.

INSTALL
-------
1. Put BeamDrift_v1.2.0.zip in your BeamNG.drive user mods folder.
2. Disable/remove the original Formula Drift Mode v4 while using BeamDrift; do not
   run two drift-assist controllers on the same vehicle at once.
3. Restart BeamNG.drive after installing.
4. Open the in-game app menu, add the BeamDrift app, then enter a vehicle.
5. Use the panel's switches. Drift-assist settings save automatically.
6. For a keyboard/controller binding, open Options > Controls and search for
   "BeamDrift: Toggle Assist" or "BeamDrift: Quick R-D / J-Turn". Bind the
   J-turn action to a separate key/button so it does not conflict with the
   normal gear controls.

PANEL / QUICK R-D
-----------------
- Street, Formula, Tandem and High Angle one-click presets.
- Target drift angle, assist strength, anti-spin strength, transition strength,
  minimum engage speed, maximum slip angle and response cap.
- Quick Shift switch clears supported automatic/arcade wait timers on the active
  player vehicle, independently of the drift assist.
- The Quick R-D / J-Turn action requests the opposite direction through the
  active gearbox controller: R -> D (or first gear on a manual), and D -> R.
  It also enables Quick Shift automatically. Only the active player vehicle is
  affected; traffic/AI vehicles are not.

LIMITS / SAFETY
---------------
- The J-turn action requests a gear change; different gearbox types may still
  enforce their own speed/clutch safeguards. It cannot guarantee a physical
  zero-millisecond shift on every vehicle.
- Forcing the opposite direction while the car is still moving can create a
  sudden wheel-torque hit or drivetrain damage in BeamNG. Test in an empty area
  at low speed first. Turn Quick Shift off for normal gearbox behavior.
- Quick Shift changes supported controller timer values at runtime; it does not
  edit JBeam or vehicle files. Manual H-shifters and some custom transmissions
  may not expose the same timers or accept the same request.
- The drift assist operates on the active vehicle's physics nodes and can feel
  different between vehicles, tyres, steering setups and game versions. If it
  pushes the wrong way, switch it off and note the vehicle and steps to repro.

CREDITS / COMPATIBILITY
-----------------------
BeamDrift is a standalone implementation built around the behavior requested
from the user-supplied Formula Drift Mode reference. That archive contained no
author/license metadata. No third-party meshes are included; confirm rights
and attribution before publicly redistributing any derivative or reused code.

Tested with Lua syntax checks, mocked BeamNG runtime tests, and an Angular/JSDOM
UI check. A real in-game BeamNG test is still recommended before relying on the
quick direction change or the force tuning.
