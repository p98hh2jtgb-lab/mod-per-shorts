DRIFTSKETCH 0.9.7 — VETËM TRAFFIC CONES
========================================

DriftSketch regjistron vijën ku vozit dhe vendos vetëm traffic cones në të dy
anët, pastaj mund ta përdorësh pistën në replay. Versioni 0.9.7 kthen dendësinë
e konave në nivelin e versioneve para 0.9.5: kufiri parazgjedhur është 2000,
me slider deri në 4000. Kjo lejon që një pistë e gjatë të mos mbetet me vetëm
pak konë për shkak të kufirit të ulët.

Kur vetura prek hapësirën e konit, mesh-i anohet dhe rrëzohet me animacion të
lehtë. Ky është ndërveprim vizual, jo simulim fizik me masë/collision. Vetura
mund të kalojë përmes konit; nuk ka JBeam vehicle të veçantë për çdo kon.

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, çaktivizoji/fshiji ZIP-at e
   vjetër të DriftSketch. Mos i mbaj dy versione aktive bashkë.
2. Kopjo DriftSketch_v0.9.7.zip në folderin Mods pa e nxjerrë nga ZIP-i.
3. Aktivizo DriftSketch te Mod Manager nëse duhet dhe rinise BeamNG.drive.
4. Në hartë: App menu > Add App > DriftSketch.

Nëse po përditëson nga 0.9.5 ose 0.9.6, hiqe ZIP-in e vjetër dhe rinise
BeamNG.drive. 0.9.7 përpiqet t'i fshijë vetë automjetet-kona JBeam të lëna
nga 0.9.5 kur ngarkohet extension-i, nis regjistrimi, bëhet Rebuild ose Clear.
Nëse njoftimi “Error loading vehicle: driftsketchcone” vazhdon pas rinisjes,
kontrollo që ZIP-i 0.9.5 të mos jetë ende aktiv në Mod Manager.

PËRDORIMI
---------
1. Rregullo hapësirën mes konave dhe distancën nga vetura.
2. Lëre "Rrëzohen kur preken" ON për animacionin vizual të rrëzimit. OFF i lë
   konat drejt.
3. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
4. Hap replay-in normal të BeamNG; konat e krijuara mbeten në skenë.
5. REBUILD i rindërton drive-t e ruajtura me cilësimet aktuale. CLEAR heq
   konat dhe drive-t e krijuara nga DriftSketch.

SHËNIM I RËNDËSISHËM PËR NDËRVEPRIMIN
------------------------------------
Konat e 0.9.7 janë TSStatic me collision të fortë të çaktivizuar. Kur vëllimi i
makinës i prek, koni anohet dhe zhvendoset pak; makina mund të kalojë përmes tij
dhe nuk godet një objekt të palëvizshëm si mur. Vetëm konat që rrëzohen
zëvendësohen me TSStatic jo-instanced për animacion, për të shmangur artefaktet
grafike gjatë lëvizjes. Nuk pretendohet si fizikë e vërtetë 1 kg.

ÇFARË KA NDRYSHUAR NË 0.9.7
---------------------------
- U kthye kufiri parazgjedhur 2000 dhe slider-i 100–4000, si te versionet para
  0.9.5; në përditësim, vlera e ulët 200 nga 0.9.5/0.9.6 migrohet në 2000.
- Konat që preken zëvendësohen me një TSStatic jo-instanced para animimit, për
  të mos lëvizur një mesh të instancuar.
- Pastrimi i JBeam konave të vjetra kontrollon edhe emrin e tyre, jo vetëm ID-në
  e modelit, dhe bëhet para/mbas regjistrimit.

ÇFARË KA NDRYSHUAR NË 0.9.6
---------------------------
- U hoqën automjetet JBeam për çdo kon; konat u bënë TSStatic pa collision.
- U shtua animacioni vizual i rrëzimit kur vetura prek konin.
- Kjo shmang koston e madhe të FPS-it që u pa në 0.9.5, por nuk është fizikë e
  vërtetë; vetura mund të kalojë përmes konave.

ÇFARË KA NDRYSHUAR NË 0.9.5
---------------------------
- DriftSketch u bë vetëm për traffic cones: u hoqën gomat, kerbs, apex bumps,
  flamujt, tabelat e frenimit, START/FINISH dhe rrathët.
- Ky version krijonte një JBeam vehicle për secilin kon; në testin real kjo
  shkaktoi kone të padukshme/të paqëndrueshme dhe rënie të madhe të FPS-it.
  Përdor 0.9.7 në vend të 0.9.5.

CILËSIMET
---------
- Hapësira: largësia mes konave në të njëjtën vijë.
- Hapësira nga kerri: largësia e konave nga ana e veturës; gjerësia e makinës
  matet automatikisht.
- Kufiri total i konave: numri maksimal i mesh-eve për tërë skenën.
- Lartësia rezervë: përdoret vetëm kur raycast-i nuk gjen sipërfaqen e tokës.
- Vijë e lëmuar: zbut korrigjimet e timonit dhe dridhjet e drift-it.
- Zgjero në drift: hap korridorin lokalisht kur vetura është anash.
- Ruaj pistat: mban drive-t e mëparshme; ato ndajnë të njëjtin kufi total.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
