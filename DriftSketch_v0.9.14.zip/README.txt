DRIFTSKETCH 0.9.14 — THREE SHORTS COUNTER STYLES & TRAFFIC CONES
========================================================

DriftSketch regjistron vijën ku vozit, vendos traffic cones përgjatë pistës dhe
numëron live konat që rrëzohen. HUD-i i ridizajnuar për Shorts shfaq p.sh.
CONES DOWN 10/5000: numri i rrëzimeve bëhet i kuq pas prekjes së parë, ndërsa
totali mbetet i gjelbër. Madhësia, pozita, etiketa, totali, stili, outline-i i zi,
glow dhe përforcimi i tingullit personalizohen.

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, çaktivizoji ZIP-at e vjetër të
   DriftSketch. Mos i mbaj disa versione aktive bashkë.
2. Kopjo DriftSketch_v0.9.14.zip në folderin Mods pa e nxjerrë nga ZIP-i.
3. Aktivizo DriftSketch te Mod Manager nëse duhet dhe rinise BeamNG.drive.
4. Shto panelin DriftSketch te App menu > Add App.
5. Shto ose ri-shto app-in "DriftSketch Counter" që të marrë madhësinë dhe
   pozicionin e ri parazgjedhur; pastaj mund ta lëvizësh e ta ndryshosh.

HUD-I PËR VIDEO
---------------
1. Te paneli DriftSketch, seksioni HUD PËR SHORTS:
   - Totali 0 = numri real i konave të krijuara.
   - Shkruaj p.sh. 5000 për të shfaqur progresin si 3/5000, pa ndryshuar
     numrin e konave në lojë.
   - Etiketa e parazgjedhur është CONES DOWN; mund ta ndryshosh sipas videos.
   - Rrite Madhësia deri në 3×; mund edhe ta zmadhojë frame-in e app-it në UI.
2. Në UI Apps/Edit mode tërhiqe counter-in ku të duash në ekran.
3. Shtyp FILLO para drive-it që të aktivizohet audio playback në UI.
4. Zgjidh NEON, OUTLINE ose GLOW nga paneli. OUTLINE është parazgjedhje;
   konturi i zi dhe glow-i rregullohen veçmas. Neon badge shfaqet vetëm kur e
   zgjedh atë stil. Madhësia/pozita e app-it vazhdojnë të rregullohen veçmas.

Numëruesi i nisur është i gjelbër. Pas prekjes së konit të parë, vetëm numri i
rrëzimeve bëhet i kuq; etiketa dhe totali mbeten të gjelbër. Counter-i numëron
çdo kon të veçantë vetëm një herë. Totali i personalizuar në HUD është vetëm
tekst për video; nuk krijon kone shtesë. Numëruesi rifillon pas Rebuild/Clear.

TINGULLI I RRËZIMIT
-------------------
Tingulli WAV luhet për çdo kon të rrëzuar. Slider-i i ri është përforcim audio
0–500%; parazgjedhja është 300% (3× gain), me kompresim për të ulur clipping-un.
Nëse tingulli deformohet ose është tepër i fortë, ule slider-in; 0% e hesht.
Vlera e vjetër e volumit dhe etiketa parazgjedhur migrohen automatikisht.

PËRDORIMI I PISTËS
------------------
1. Rregullo hapësirën mes konave, distancën nga vetura dhe kufirin total.
2. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
3. Hap replay-in normal të BeamNG; konat e krijuara mbeten në skenë.
4. REBUILD i rindërton drive-t e ruajtura me cilësimet aktuale. CLEAR heq
   konat dhe drive-t e krijuara nga DriftSketch.

NDËRVEPRIMI DHE PERFORMANCA
---------------------------
Konat janë TSStatic me collision të fortë të çaktivizuar. Kur vëllimi i makinës
i prek, mesh-i anohet me animacion të lehtë; vetura mund të kalojë përmes tyre.
Nuk ka një automjet JBeam për çdo kon, për të shmangur rënien e madhe të FPS-it
që u pa në 0.9.5. Vetëm konat që rrëzohen zëvendësohen me mesh jo-instanced
para animimit. Kjo është sjellje vizuale, jo fizikë e vërtetë 1 kg.

Nëse po përditëson nga 0.9.5–0.9.11, hiqe ZIP-in e vjetër dhe rinise
BeamNG.drive. Versioni i ri ruan edhe pozitat e konave që i fshin në World
Editor, që të mos rikrijohen kur makina kalon aty gjatë replay-it. Rebuild i
qëllimshëm i kthen konat e fshira.

ÇFARË KA NDRYSHUAR NË 0.9.14
----------------------------
- U shtuan tri stile të ndërrueshme: NEON (badge neon), OUTLINE (pa sfond)
  dhe GLOW (kontur me ndriçim të butë). OUTLINE është parazgjedhje.
- Konturi i zi dhe glow-i kontrollohen veçmas nga paneli; NEON/GLOW e ndezin
  glow-in si preset, por mund ta fikësh kur të duash.
- U rregullua hapësira e shifrave: numëruesi përdor rreshtim të sigurt pa
  letter-spacing negativ, që shifrat e totalit të mos mbivendosen.
- Cilësimet e 0.9.13 ruhen pa rishkallëzuar madhësinë ose përforcimin e tingullit.

ÇFARË KA NDRYSHUAR NË 0.9.13
----------------------------
- U shtuan dy stile të ndërrueshme nga paneli: SPEED SLANT dhe KOMPAKT.
- Të dyja kanë outline të zi ON dhe glow OFF si parazgjedhje; secili efekt mund
  të ndizet/fiket veçmas. Glow-i është me intensitet të ulët.
- Stili i zgjedhur, outline-i dhe glow-i ruhen bashkë me cilësimet e mod-it.
- Cilësimet e 0.9.12 ruhen pa rishkallëzuar madhësinë ose përforcimin e tingullit.

ÇFARË KA NDRYSHUAR NË 0.9.12
----------------------------
- U hoq krejt sfondi i zi transparent pas counter-it; mbetet vetëm teksti i madh
  pa LIVE, pa vijë akcenti dhe pa hije të zeza. Etiketa parazgjedhje: CONES DOWN.
- U ruajt pozita/madhësia e përdoruesit dhe u bë e sigurt migrimi i cilësimeve
  nga 0.9.10/0.9.11.

ÇFARË KA NDRYSHUAR NË 0.9.11
----------------------------
- U hoqën etiketa LIVE, vija me ngjyra sipër dhe hijet e zeza të tekstit.
- Konat e fshira në World Editor nuk shfaqen përsëri kur makina kalon mbi to
  gjatë replay-it; pozitat ruhen edhe gjatë serializimit.
- Rebuild i qartë i rikthen me qëllim konat e fshira.

ÇFARË KA NDRYSHUAR NË 0.9.10
----------------------------
- HUD më i madh e më i lexueshëm: panel i errët transparent, vijë akcenti,
  status LIVE, numër i theksuar dhe madhësi default më e madhe.
- Etiketa parazgjedhje u bë CONES DOWN; “TOUCHED” nënkuptonte çdo prekje,
  ndërsa ky numërues tregon konat që janë rrëzuar.
- Tingull WAV u normalizua; slider 0–500% përdor Audio Gain/kompresor kur është
  i disponueshëm dhe fallback në volumin maksimal HTML Audio.
- Cilësimet e ruajtura nga 0.9.9 migrohen te etiketa e re, HUD më i madh dhe
  slider-i i ri i përforcimit.

ÇFARË KA NDRYSHUAR NË 0.9.9
---------------------------
- U shtua tingull WAV i paketuar dhe aktivizim nga klikimi FILLO; eventet e
  rrëzimit zbulohen edhe nga state-i live, jo vetëm nga event hook-u.
- Numri i rrëzuar bëhet i kuq pas konit të parë; totali mbetet i gjelbër.
- U ruajt totali i personalizuar deri në 9,999,999, madhësia dhe etiketa.

ÇFARË KA NDRYSHUAR NË 0.9.8
---------------------------
- U shtua counter live dhe app-i DriftSketch Counter, i lëvizshëm në ekran.
- U shtuan etiketa, madhësia, totali i personalizuar, tingulli dhe volumi.

ÇFARË KA NDRYSHUAR NË 0.9.7
---------------------------
- U kthye kufiri parazgjedhur 2000 dhe slider-i 100–4000, si te versionet para
  0.9.5; pistat e gjata mund të kenë përsëri dendësi më të madhe konash.
- Konat e prekura zëvendësohen me mesh jo-instanced para animimit, për të
  shmangur artefaktet grafike gjatë lëvizjes.
- U forcua pastrimi i JBeam konave të vjetra.

ÇFARË KA NDRYSHUAR NË 0.9.6
---------------------------
- U hoqën automjetet JBeam për çdo kon; konat u bënë TSStatic pa collision.
- U shtua animacioni vizual i rrëzimit kur vetura prek konin.

ÇFARË KA NDRYSHUAR NË 0.9.5
---------------------------
- DriftSketch u bë vetëm për traffic cones: u hoqën gomat, kerbs, apex bumps,
  flamujt, tabelat e frenimit, START/FINISH dhe rrathët.
- Versioni 0.9.5 krijonte një automjet JBeam për kon dhe shkaktoi kone të
  padukshme/të paqëndrueshme e rënie të madhe të FPS-it. Përdor versionin e ri.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
