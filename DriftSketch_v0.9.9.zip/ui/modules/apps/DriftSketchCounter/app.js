angular.module('beamng.apps')
.directive('driftSketchCounter', ['$window', function($window) {
  var SOUND_URL = '/ui/modules/apps/DriftSketchCounter/cone-hit.wav';

  function localAudioPool() {
    if ($window.__driftSketchAudioPool) return $window.__driftSketchAudioPool;
    var AudioCtor = $window.Audio;
    if (!AudioCtor) return null;
    try {
      var pool = [];
      for (var i = 0; i < 6; i++) {
        var audio = new AudioCtor(SOUND_URL);
        audio.preload = 'auto';
        pool.push(audio);
      }
      $window.__driftSketchAudioPool = pool;
      $window.__driftSketchAudioIndex = 0;
      return pool;
    } catch (_err) { return null; }
  }

  function playConeSound(data) {
    if (!data || !data.soundEnabled) return;
    if ($window.__driftSketchPlayHitSound) {
      $window.__driftSketchPlayHitSound(data);
      return;
    }
    var key = String(data.eventSession || '') + ':' + String(data.eventSerial || '');
    var seen = $window.__driftSketchPlayedHits || ($window.__driftSketchPlayedHits = {});
    if (seen[key]) return;
    seen[key] = true;
    var volume = Number(data.soundVolume);
    if (!isFinite(volume)) volume = 0.55;
    volume = Math.max(0, Math.min(1, volume));
    if (volume <= 0) return;
    var pool = localAudioPool();
    if (!pool || !pool.length) return;
    try {
      var index = $window.__driftSketchAudioIndex % pool.length;
      $window.__driftSketchAudioIndex = index + 1;
      var audio = pool[index];
      audio.volume = volume;
      audio.muted = false;
      audio.currentTime = 0;
      var playing = audio.play();
      if (playing && playing.catch) playing.catch(function() {});
    } catch (_err) {}
  }

  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/DriftSketchCounter/app.html',
    link: function(scope) {
      scope.state = {
        toppledCount: 0,
        displayTotal: 0,
        settings: {hudLabel:'TOUCHED', hudSize:1.0, soundEnabled:true, soundVolume:0.55}
      };
      scope.pulse = false;
      scope.formatCount = function(value) {
        var number = Number(value);
        return isFinite(number) ? String(Math.max(0, Math.round(number))) : '0';
      };
      scope.numberStyle = function() {
        var size = Math.max(0.5, Math.min(2.5, Number(scope.state.settings.hudSize) || 1));
        return {fontSize:(72 * size) + 'px'};
      };
      scope.labelStyle = function() {
        var size = Math.max(0.5, Math.min(2.5, Number(scope.state.settings.hudSize) || 1));
        return {fontSize:(14 * size) + 'px'};
      };
      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      function pulse() {
        scope.$applyAsync(function() { scope.pulse = true; });
        $window.setTimeout(function() {
          scope.$applyAsync(function() { scope.pulse = false; });
        }, 140);
      }
      function playSerialRange(data, first, last) {
        if (!data || !data.settings) return;
        for (var serial = first; serial <= last; serial++) {
          playConeSound({eventSession:data.eventSession, eventSerial:serial,
            soundEnabled:!!data.settings.soundEnabled, soundVolume:data.settings.soundVolume});
        }
      }

      var lastEventSession = null;
      var lastEventSerial = null;
      var offState = scope.$on('driftSketch.state', function(_event, data) {
        if (!data) return;
        var eventSession = String(data.eventSession || '');
        var eventSerial = Number(data.toppleEventSerial) || 0;
        if (lastEventSession !== eventSession || lastEventSerial === null) {
          lastEventSession = eventSession;
          lastEventSerial = eventSerial;
        } else {
          if (eventSerial > lastEventSerial) {
            playSerialRange(data, lastEventSerial + 1, eventSerial);
            pulse();
          }
          lastEventSerial = eventSerial;
        }
        scope.$applyAsync(function() { scope.state = data; });
      });
      var offHit = scope.$on('driftSketch.hit', function(_event, data) {
        if (!data) return;
        playConeSound(data);
        pulse();
      });
      scope.$on('$destroy', function() {
        if (offState) offState();
        if (offHit) offHit();
      });
      lua('extensions.driftSketch.uiState()');
    }
  };
}]);
