DRIFTSKETCH 0.9.4 — TIGHT STRAIGHTS + CLEAN FINISH END
==================================================================

Record a real drive, then build an object-marked path from your actual trajectory.
DriftSketch is a standalone mod. It does not require CreatorPack.

INSTALL
-------
1. Open BeamNG.drive > Mods > Open Mod Folder (or your user mods folder).
2. Remove ALL older DriftSketch ZIP versions first (including 0.9.1, 0.9.2 and 0.9.3). Two
   copies must never load together.
3. Copy DriftSketch_v0.9.4.zip there without extracting it.
4. Enable DriftSketch in the Mod Manager if needed.
5. Restart BeamNG after replacing an older version so shapes and materials
   reload cleanly.
6. In a map, open the top app menu > Add App > DriftSketch.

WORKFLOW
--------
1. Choose Mesh, Spacing, Gap to car and the other settings.
2. Press Start and drive the line you want.
3. Press Stop & Build. Both sides are always generated.
4. Drive the generated path or open BeamNG's replay; the generated TSStatic
   objects stay in the scene for replay.
5. Change settings and use Rebuild to regenerate saved drives without recording
   again. Clicking a mesh or tyre-colour button rebuilds saved drives at once.
6. Rings: tick "Rings on drive" for your recorded line, or press "Place rings
   ahead". Keep "Follow airborne path" ON to float rings along recorded jumps.
7. Clear generated objects & saved drives deletes only this mod's objects,
   rings and saved paths. Clear rings deletes only the rings.

NEW IN 0.9.4
------------
Tighter, genuinely local drift width
- With Drift widen ON, straight sections now stay at the car's measured width plus Gap and marker
  clearance. The full rotated vehicle footprint opens the corridor only where
  the recorded car is actually sideways; it no longer borrows the car's full
  length as a sideways reach along the road.
- Width eases over a short local distance, so a drift does not leave a long,
  unnecessarily wide tail through the following straight.

Finish row placed beyond the last car
- The finish cross-row is moved forward beyond the last recorded vehicle
  footprint, with a safety margin. Both side lines continue forward and meet
  the row, avoiding a row that appears to cut through the stopped car.
- The extension follows the final path direction and grade. The finish-only
  rule remains unchanged: the start is open, closed loops get no row, and
  optional overhead gates remain separate and OFF by default.

NEW IN 0.9.3
------------
Finish-only marker row
- A cross-row of the currently selected mesh closes the finish end of every
  non-loop drive. The start stays open; the cross-row is independent of the
  optional overhead START / FINISH truss gates.
- Row spacing adapts to marker size and is dense enough to read as a clear
  finish line. Side lines extend beyond the last car and join the cross-row.
- Closed loops do not get an extra row at the join. The row and its side
  extensions are included in the per-drive object cap and use the same
  collision setting.
- Optional truss gates are OFF by default, so a new installation opens at the
  start. Saved gate preferences are retained.

Five new original racing meshes
- Racing Curb: low red/white kerb sections.
- Apex Bump: a dark pad with raised yellow/white domed ribs.
- Checkered Flag: a two-sided geometric flag on a compact stand.
- 100 m Board and 50 m Board: two-sided braking-distance signs with geometric
  numerals. All five are original, flat-PBR COLLADA meshes with no textures.
- Traffic Cone and Tire Stack remain selectable; Red · White and
  Red · White · Blue tire-stack patterns are unchanged.
- The five 0.9.2 road-work props were removed. Old saved selections of those
  props safely fall back to Traffic Cone.

Air-follow stunt rings are retained
-------------------------------
- Follow airborne path is ON by default. If the recorded vehicle path is more
  than 1.25 m above the raycast ground, each ring follows that height and the
  recorded path pitch instead of snapping down to the road.
- The ring opening is lowered about 0.55 m from the recorded vehicle centre so
  the hoop sits around the car's flight line. Ring Lift adds on top of that.
- Turn Follow airborne path OFF to keep rings ground-anchored. The option also
  applies to Place rings ahead when the car is airborne.
- Ground-level rings still sit at the surface with Lift 0, and raised or
  airborne rings no longer create unnecessary gaps in the ground marker lines.

NEW IN 0.9.1
------------
Clean, tight lines like a real cone slalom
- Smooth path now resamples the recorded line every 0.25 m and filters it over
  a few metres (Gaussian). Steering corrections and drift wobble no longer
  reach the marker lines, which flow cleanly instead of zig-zagging.
- Base width is replaced by Gap to car (0-3 m, default 0.3 m): the space
  between the car side and the markers, per side. The real car width is
  measured from the vehicle, so the corridor is always just the car plus Gap.
  Dragging Gap or Spacing rebuilds saved drives by itself after a short pause.
- Wherever the car really ran beside the smoothed line, that side opens by the
  difference, gently, so the tight corridor never cuts into the driven line.
- Drift widen is OFF by default. When enabled, the rotated car footprint opens
  the corridor locally where the car went sideways (at most 2 m extra per
  side); the old point-by-point pushing that scattered cones is gone.
- On the inside of a turn tighter than the corridor the line no longer loops:
  that stretch is left empty instead of folding back over itself.

NEW IN 0.9.0
------------
New look, rebuilt from scratch to match real reference photos
- Every shipped shape is original low-poly geometry; nothing is extracted from
  BeamNG. Racing marker assets are procedural meshes built for DriftSketch.
- No texture files at all. Every material is a flat PBR colour and all
  details (tread, checker squares, START/FINISH lettering, sponsor panels)
  are real geometry, so no shape can fall back to the "No Texture" material.
- The old yellow/white colour set is gone.
- Traffic Cone: orange body, two white reflective bands, square orange base
  with rounded corners, open tip with a dark inside. 0.66 m tall,
  0.41 m base. Cones sit square to their line, like hand-placed cones.
- Tire Stack: four stacked tyres (0.67 m diameter, 0.85 m tall) with rounded
  shoulders, raised chevron tread blocks, darker grooves and a dark hollow
  centre. Colours alternate in pairs:
    Red · White         red, red, white, white, ...
    Red · White · Blue  red, red, white, white, blue, blue, ... (karting look)
  Each stack gets its own yaw so the tread pattern does not repeat.
- START gate: blue box-truss towers with X bracing on base plates, a red-framed
  banner with checker blocks, a white START panel and two generic sponsor
  panels (DRIFT and SKETCH, no real brands).
- FINISH gate: grey steel lattice towers with base plates and caps, and a
  checkered banner with a dark-red FINISH panel.
- Both gates read correctly from the front and from behind.

Rings
- Red/white striped stunt hoops (16 segments) like the reference photo.
- Count: 1-50 rings. Size: clear opening 3-30 m. Gap: 2-100 m between rings.
  Lift: 0-10 m above the ring base (ground or airborne path).
- With Lift 0 a ground-level opening starts at the surface and the bottom tube
  is buried, so cars drive straight through, even with Solid ON. For jumps, the
  default Follow airborne path keeps each hoop around the recorded flight line.
- Rings on drive: rings are centred on the recorded line, every Gap metres,
  starting one Gap after the start. Optional truss gates keep the first and
  last 8 m free; without gates, a short finish margin keeps rings clear of the
  finish row. Ground markers that would cut through a low ring tube leave a
  small gap; airborne rings do not remove markers underneath them.
- Place rings ahead: a straight line of rings in front of the car's current
  position and heading. The first ring is one Gap past the front bumper; with
  Follow airborne path ON, airborne placement uses the car's current height.
- Ring sliders apply by themselves about 0.35 s after you stop moving them. No
  Rebuild needed. Rebuild keeps placed rings; Clear rings removes all of them.
- Grounded rings follow the terrain slope; airborne rings follow the recorded
  path pitch (up to about 20 degrees). Up to 300 rings in total. Rings do not
  use the Performance cap.

Removed
- Traffic Barrel, Flexible Bollard, Jersey Barrier, Arrow Board and Checkpoint
  Beacon from 0.9.2. Saved settings that still ask for one map to Traffic Cone.
- Tall Pylon and Single Tire. Saved settings that still ask for them map to
  Traffic Cone and Tire Stack.

Fixes and other changes
- Fixed the 0.8.1 gate bug where a Finish (or Start) gate could turn into a
  huge dark wall that looked untextured. Gate width came from every marker
  within 2 m along the gate, at any distance sideways, so another leg of the
  track tens of metres away stretched the gate 20-40 times. Now only markers
  near the gate count (up to 4 m beyond the corridor). Gates also scale
  uniformly (0.8x-2.6x) instead of stretching the banner.
- A closed loop that ends within 6 m of its start keeps only the START gate
  and does not get a second finish row at the join.
- Spacing now goes down to 0.5 m (default 1.0 m), so cones can stand much
  closer together.
- Performance cap: up to 4000 objects per drive (default 2000).
- All generated objects live in one SimGroup, DriftSketch_Objects. After a
  Lua reload the old objects are swept and the saved drives, ring sets and
  settings are restored and rebuilt.
- With Solid ON, old collision is reloaded before a rebuild places new
  objects, so ground rays never hit the previous build.
- New asset folder art/shapes/driftsketch_v09/ and new material names
  (driftsketch09_*), so no cached 0.8.1 shape or material can be reused.

PANEL SETTINGS
--------------
Mesh: seven always-visible one-click buttons, with no dropdown: Traffic Cone,
Tire Stack, Racing Curb, Apex Bump, Checkered Flag, 100 m Board and 50 m Board.
Saved drives rebuild immediately. Legacy 0.9.2 selections that were removed
fall back to Traffic Cone.
Tyre colours (Tire Stack only): Red · White, or Red · White · Blue.
Layout: Both sides, always.
Spacing: distance between markers on the same line, 0.5-10 m. Lower means more
markers. Inner and outer curves are sampled independently.
Gap to car (0.9.1, replaces Base width): space between the car side and the
markers on each side. The corridor is the measured car width plus Gap.
Drift widen (OFF by default): straight sections stay narrow; where the car is
sideways, the corridor widens locally to fit its rotated front and rear corners.
Finish row: every non-loop drive closes only its finish end with a cross-row of
the selected marker, placed beyond the last car; both side lines extend to meet
it. The start stays open. The row and extensions count toward the Performance
cap.
Start / Finish truss gates: optional overhead gates at the first and last path
points, OFF by default. Each gate is scaled uniformly so its tower base plates
stay outside nearby marker lines. Gates are independent of the finish row and
use one or two places in the object cap.
Mesh scale: marker size. Clearance includes the scaled marker radius.
Ground fallback: height relative to the recorded point, used only when no ground
raycast hits. -0.55 m is the normal starting value.
Performance cap: maximum side markers, finish row and gates for one drive. Long
drives are sampled more sparsely instead of creating unlimited objects.
Smooth path: strong arc-length smoothing for clean, flowing marker lines.
Keep builds: keep previous runs when you start a new recording.
Solid / car damage: OFF uses collisionType=None, so objects are visual only.
ON uses Visible Mesh Final static collision, so impacts can stop or damage the
car. Changing this, Drift widen, Smooth path, gates or Rings on drive rebuilds saved drives
automatically when recording is stopped.
Rings: Rings on drive, Follow airborne path, Count, Size, Gap, Lift above path,
Place rings ahead and Clear rings. Follow airborne path is ON by default and
uses the recorded vehicle height when it is more than 1.25 m above ground.
Rebuild: regenerate saved paths and placed rings with the current settings.
Clear: remove generated objects, rings and saved drives only.

TRIANGLE BUDGET
---------------
Traffic Cone 608, Tire Stack 1184, Racing Curb 60, Apex Bump 360,
Checkered Flag 380, 100 m Board 516, 50 m Board 444, START gate 4270,
FINISH gate 1872, Ring 1536. The models use flat PBR materials only. All
objects use TSStatic instance rendering.

BEHAVIOR AND SAFETY
-------------------
- Uses real TSStatic meshes, not hundreds of JBeam cone vehicles.
- Finish rows, gates and rings share the tracked-object lifecycle and collision
  setting. They are rebuilt or cleared with the path and remain for replay like
  markers.
- Pure rotation in place does not create a fake path.
- Swept turn clearance uses oriented 2D rectangle/ray tests and a spatial grid.
  It runs during Stop & Build or Rebuild, never in the live recording loop.
- Collision reloads happen only when solid objects are added or removed.
- The material library is loaded explicitly once per map, before the first
  object is created.

VALIDATION
----------
The exact 0.9.4 package was checked for COLLADA validity, triangle/index bounds,
non-degenerate faces, unit normals matching triangle winding, model dimensions
and ground/base extents, material bindings and flat PBR colours across all 12
DAE files. A Fengari mocked-BeamNG Lua runtime test covers all seven marker
selections, finish-only closure, open starts, short drives, closed-loop behavior,
the object cap, legacy setting migration, and grounded/airborne ring placement,
path pitch, lift and ahead rings. The Angular/JSDOM UI integration test verifies
every mesh button and ring control without JavaScript errors. The mocked runtime
also verifies a narrow straight, local sideways widening, and finish-row
clearance beyond the final car footprint. A real BeamNG pass
is still recommended on each map to tune marker clearance, collision behaviour
and performance for your style.

ASSETS AND CREDITS
------------------
All meshes were created procedurally for DriftSketch. The five new 0.9.3
racing models are original assets, not extracted BeamNG content. The
START/FINISH and sponsor lettering is geometry generated from the glyph outlines of Open Sans ExtraBold, Oswald Bold
and Racing Sans One (SIL Open Font License 1.1; license texts are in
tests/fonts). The sponsor panels use the generic words DRIFT and SKETCH and
show no real brands.

HISTORY
-------
0.9.4  Locally adaptive drift width and finish row beyond the car footprint.
0.9.3  Finish-only marker row and five racing-focused mesh choices.
0.9.2  Air-follow stunt rings and five road-work props (removed in 0.9.3).
0.9.1  Smooth marker lines and a tight corridor.
0.9.0  Reference look: new cones, tyre walls, truss gates and rings.
0.8.1  Runtime material loading; yellow/white set (replaced in 0.9.0).
0.8.0  Material fixes, redesigned tyres and gates.
0.7.1  One-click mesh buttons instead of a dropdown.
0.7.0  Start and Finish gates.
0.6.0  Tyre props.
0.5.0  Swept turn clearance.
0.4.0  Drift-aware rear clearance.
0.3.0  Smoother curves, optional solid collision.
0.2.0  Both-side placement, refined meshes.
0.1.0  First replay cone prototype.
