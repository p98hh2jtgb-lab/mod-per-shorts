DRIFTSKETCH 0.9.25 — KONET JASHTË VIJËS SË RIMORKIOS
======================================================
Bazuar te 0.9.4. S'ka rrëzim, s'ka numra/counter, s'ka HUD, s'ka tingull, s'ka
automjet JBeam për kon. Konet janë TSStatic të lehta; "Solid / car damage" OFF.

PSE 0.9.24 PRAP I PREKTE KONAT
------------------------------
Screenshot-et tregonin rimorkion e zbuluar ("clone #2775 · Auto"), rrugë SHUMË
të gjerë, e megjithatë konet nën rimorkio. Shkaku: 0.9.24 ruante vetëm një
**numër gjerësie** te stacioni i MAKINËS dhe e zgjeronte korridorin **simetrikisht
nga të dyja anët**, me një kompensim prej vetëm 6 pikash. Rimorkioja është 4–5 m
PRAPA makinës (≈18–20 stacione me spacing 0.25 m) dhe gjatë drift-it "pret" nga
njëra anë; prandaj gjerësia binte aty ku s'duhej (rrugë e gjerë kot) dhe mungonte
aty ku rimorkioja kalonte (konet prekeshin). Për më tepër, një rimorkio e mbajtur
me collision lëkundet, kështu zbulimi me tolerancë 0.60 m / 13° e humbiste gjatë
drift-it me 80–100 km/h.

ÇFARË NDRYSHOI (RREGULLIMI I VËRTETË)
-------------------------------------
1. **Regjistrohet vija e dytë.** Në çdo pikë të rrugës ruhet qendra reale e
   rimorkios në botë, përmasat E koka e saj e rrotulluar (drejtkëndëshi i
   kthyer), jo një numër. Kjo kap saktë edhe rimorkion që lëkundet / artikulohet
   me kokë tjetër nga makina në drift.
2. **Konet shtyhen vetëm nga ana ku kalon rimorkioja.** Për çdo stacion, mod-i
   kërkon deri 10 m përgjatë vijës, gjen të gjitha qendrat e rimorkios aty dhe
   llogarit `needLeft` / `needRight` VEÇMAS nga drejtkëndëshi i saj. Ana tjetër
   mbetet e ngushtë si te 0.9.4 — rruga nuk është më "shumë e gjerë" kot.
3. **Asnjë kompensim me hamendje.** `applyRigLag` tani vetëm plotëson 2–3 pikat
   e para para zbulimit; vendosja bëhet nga pozita reale, jo nga ±6 pika.
4. **Drive-t e vjetra / të ruajtura** (0.9.4, 0.9.23, 0.9.24 — pa vijë
   rimorkioje) rindërtohen duke projektuar pozitën AKTUALE relative të rimorkios
   mbi çdo stacion, me kokën e makinës së atij stacioni. Kjo riprodhon edhe
   daljen anash në drift, sepse koka e makinës ndryshon nga tangjentja e rrugës.
   Prandaj **REBUILD** e rregullon drive-n tënd pa e regjistruar përsëri.
5. **Zbulimi u bë tolerant:** 1.5 m / ~32° lëkundje relative dhe regjistrimi nuk
   fshihet më kur objekti humbet për disa korniza. Pranon automjete DHE prop-a
   TSStatic të selektuar në World Editor.
6. **Hapësira minimale / Safety floor** u ul nga 2.0 m në **1.0 m** (0–4 m) —
   tani është vetëm dysheme sigurie, jo më mjeti kryesor. Vendos **0 m** për
   vijat sa më të ngushta: vija e rimorkios vazhdon t'i mbrojë konet.
7. Paneli tregon **"✓ N pika të vijës së rimorkios"** — sheh menjëherë nëse
   rimorkioja është realisht në llogaritje. Rreshti i finish-it tani qëndron edhe
   prapa pjesës së pasme të rimorkios.

SI TA PËRDORËSH
----------------
1. Çaktivizo çdo ZIP tjetër DriftSketch → vendos vetëm këtë te Mods, pa e nxjerrë
   → **rindis BeamNG.drive**.
2. Me drive-n e vjetër: shtyp **REBUILD WITH CURRENT SETTINGS** (ose prit 1–2 s
   në replay që zbulimi automatik ta rindërtojë vetë). Duhet të shfaqet "✓ N pika
   të vijës së rimorkios". Konet do të jenë të ngushta nga ana pa rimorkio dhe të
   hapura vetëm aty ku ajo kalon.
3. Për matje maksimale: selekto rimorkion te World Editor → **Përdor rimorkion e
   zgjedhur**. Për një run të ri: FILLO → vozit → NDALO & NDËRTO (vija e rimorkios
   ruhet në drive dhe rindërtohet gjithmonë saktë).
4. Nëse ende prek: rrit **Margjinë sigurie** (0–2 m) ose **Hapësira minimale**.
   Nëse vijat duken larg: ul të dyja. Mos i ngatërro — e para shton hapësirë
   VETËM rreth rimorkios, e dyta e zgjeron të gjithë rrugën.

SHËNIM PËR CILËSIMET E TUA
---------------------------
Ke Gap 0 m, Spacing 0.5 m, Drift widen ON, Performance cap 2000. Me vijën e re
ana e majtë mbetet ~1.2 m nga qendra (si te 0.9.4), ana e djathtë hapet vetëm
në kthesat ku rimorkioja pret. Rreshti i finish-it merr disa objekte më shumë;
nëse vijat anësore duken më të rralla, rrit pak Performance cap (p.sh. 2500).
Asnjë fizikë apo animacion shtesë.

PERFORMANCA DHE SIGURIA
-----------------------
- Llogaritja e vijës së dytë bëhet një herë në ndërtim: për çdo stacion skanohen
  stacionet brenda 10 m dhe drejtkëndëshet e rimorkios. Është aritmetikë e thjeshtë,
  pa objekte të reja, pa fizikë, pa punë për kornizë.
- Zbulimi në replay: 3 herë/sek, vetëm brenda 12 m, vetëm derisa të gjejë
  rimorkion (maks. 90 s), vetëm kur makina lëviz. Gjatë FILLO: vetëm në pikat e
  rrugës. Lista e kandidatëve është e memorizuar 1.5 s dhe e kufizuar në 32
  objekte — një run me 41 pika e lexon listën e automjeteve vetëm 1 herë, jo në
  çdo pikë. Regjistrimi i gjetur nuk fshihet më gjatë drift-it. Nuk skanohen
  kurrë konet.
- Konet TSStatic me instance rendering, collision=None kur "Solid" është OFF.
  As rrëzim, as numërues/HUD, as WAV/tingull, as JBeam-per-kon nuk kthehet.

MIGRIMI
-------
Cilësimet, drive-t e ruajtura dhe rrathët nga 0.9.4 / 0.9.23 / 0.9.24 ruhen.
Drive-t pa `rigPoses` marrin vijën e sintetizuar nga pozita aktuale. Çelësat e
hequr (topple, coneCollision, hud*, sound*) injorohen.

HISTORIA
--------
0.9.4  i pastër, konet TSStatic, pa rrëzim/numra.
0.9.5  konet si automjete JBeam → rënie FPS (NUK rikthehet).
0.9.8  counter/numrat. 0.9.17 collision fizik (FPS 2–3).
0.9.22 kthim i pastër. 0.9.23 zbulim rimorkioje vetëm gjatë regjistrimit.
0.9.24 gjerësi në ndërtim, por simetrike dhe në stacionet e gabuara.
0.9.25 vija e qendrës së rimorkios + pastrim vetëm nga ana e saj.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
