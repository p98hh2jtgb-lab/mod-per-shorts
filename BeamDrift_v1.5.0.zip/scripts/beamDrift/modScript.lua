load('beamDrift')
setExtensionUnloadMode('beamDrift', 'manual')
