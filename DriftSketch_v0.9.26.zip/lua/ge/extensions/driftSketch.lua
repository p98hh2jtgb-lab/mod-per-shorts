-- DriftSketch 0.9.26 — Node Grabber (CTRL+LMB, MMB) swinging trailer support.
-- Based on 0.9.4, the last clean version: no topple, no counter/HUD, no sound,
-- no per-cone JBeam. The rig is attached with the NODE GRABBER: hold CTRL,
-- grab a node with LMB and drop it on another vehicle's node with MMB. That is a
-- soft physics joint: NO coupler event, NO hitch, NO World Editor object, and its
-- relative pose swings a lot. "Attached" is therefore detected by CO-MOTION
-- (the rig travels with the car), not by a fixed relative pose. Both vehicles
-- contribute to the cone corridor; no hitch / no L key / no World Editor needed.
local M = {}
M.version = '0.9.26'

local ASSET_DIR = '/art/shapes/driftsketch_v09/'
local MATERIAL_FILE = ASSET_DIR .. 'main.materials.json'
local GROUP_NAME = 'DriftSketch_Objects'

-- Shape dimensions at scale 1 (lateral radius is used for car clearance).
local MESH_DIMENSIONS = {
  cone = {radius = 0.24, height = 0.66},
  tireStack = {radius = 0.34, height = 0.85},
  raceCurb = {radius = 0.29, height = 0.18},
  apexBump = {radius = 0.32, height = 0.20},
  checkeredFlag = {radius = 0.42, height = 1.23},
  brake100 = {radius = 0.44, height = 1.25},
  brake50 = {radius = 0.44, height = 1.25}
}

local MESH_FILES = {
  cone = 'cone.dae',
  raceCurb = 'race_curb.dae',
  apexBump = 'apex_bump.dae',
  checkeredFlag = 'checkered_flag.dae',
  brake100 = 'brake_board_100.dae',
  brake50 = 'brake_board_50.dae'
}
local GATE_CLEAR_HALF = 4.35      -- inner edge of both tower base plates
local GATE_FOOT_OUTER = 5.25      -- outer edge of the base plates
local GATE_FOOT_ALONG = 0.45      -- base plate half depth along the path
local GATE_TOWER_CENTER = 4.8
local GATE_MIN_SCALE, GATE_MAX_SCALE = 0.8, 2.6
local RING_OPENING, RING_TUBE = 6.0, 0.3   -- clear opening diameter, tube radius
local RING_AIRBORNE_THRESHOLD, RING_VEHICLE_DATUM = 1.25, 0.55
local RING_MAX_TOTAL = 300

local TIRE_PATTERNS = {
  rw = {'red', 'red', 'white', 'white'},
  rwb = {'red', 'red', 'white', 'white', 'blue', 'blue'}
}

local SETTINGS = {
  mesh = 'cone',
  tireColors = 'rw',
  spacing = 1.0,
  gap = 0.3,          -- metres between the car side and the marker, per side
  scale = 1.0,
  groundOffset = -0.55,
  maxCones = 2000,
  smooth = true,
  keepBuilds = true,
  collision = false,
  driftWidth = false,
  gates = false,
  rings = false,
  ringCount = 5,
  ringSize = 7.0,
  ringGap = 15.0,
  ringLift = 0.0,
  ringFollowAir = true,
  rigAware = true,     -- auto-detect rigidly attached vehicles (no hitch needed)
  rigMargin = 0.25,    -- extra clearance around the whole rig, in metres
  -- Build-time clearance applied to EVERY drive, including old saved drives
  -- recorded before this feature existed. This is why Rebuild now widens the
  -- cones even when no trailer was detected during that recording.
  rigPad = 1.0          -- global safety floor; the real fix is the rig centreline
}

local recording = false
local points = {}
local activeVehicleId = nil
local activeVehicleName = 'No vehicle'
local savedPaths = {}
local ringSets = {}
local spawned = {}        -- path markers, finish row and optional gates
local ringObjects = {}    -- rings (path rings and rings placed ahead of the car)
local status = 'Ready. Press Start and drive.'
local statusError = false
local uiClock = 0
local clockTotal = 0
local objectSerial = 0
local session = tostring((os and os.time and os.time() or 0) % 1000000)
local collisionDirty = false
local markersSolid = false
local ringsSolid = false
local ringRebuildAt = nil
local pathRebuildAt = nil
local pendingRestore = false
local restored = false

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function truthy(value)
  return not (value == false or value == 'false' or value == 0 or value == nil)
end

-- A rig pose is the trailer's WORLD centre plus its bounding rectangle in the
-- car's heading frame. Recording the real centre (not a scalar width) is what
-- lets the cones clear a trailer that sits 4-5 m behind and swings in corners.
local function copyRigPoses(source)
  if type(source) ~= 'table' or #source == 0 then return nil end
  local out = {}
  for _, r in ipairs(source) do
    if type(r) == 'table' and type(r.x) == 'number' and type(r.y) == 'number' then
      out[#out + 1] = {x = r.x, y = r.y, fx = r.fx or 1, fy = r.fy or 0,
        hl = tonumber(r.hl) or 2.4, hw = tonumber(r.hw) or 1.0}
    end
  end
  return #out > 0 and out or nil
end

local function interpRigPoses(a, b, t)
  local na, nb = (type(a) == 'table' and #a or 0), (type(b) == 'table' and #b or 0)
  local n = math.max(na, nb)
  if n == 0 then return nil end
  local out = {}
  for k = 1, n do
    local pa, pb = a[k] or b[k], b[k] or a[k]
    local fx = (pa.fx or 1) + ((pb.fx or 1) - (pa.fx or 1)) * t
    local fy = (pa.fy or 0) + ((pb.fy or 0) - (pa.fy or 0)) * t
    local size = math.sqrt(fx * fx + fy * fy)
    if size > 0.001 then fx, fy = fx / size, fy / size else fx, fy = 1, 0 end
    local hlA, hlB = tonumber(pa.hl) or 2.4, tonumber(pb.hl) or 2.4
    local hwA, hwB = tonumber(pa.hw) or 1.0, tonumber(pb.hw) or 1.0
    out[k] = {x = pa.x + (pb.x - pa.x) * t, y = pa.y + (pb.y - pa.y) * t,
      fx = fx, fy = fy, hl = hlA + (hlB - hlA) * t, hw = hwA + (hwB - hwA) * t}
  end
  return out
end

local function copyPoints(source)
  local out = {}
  for i, p in ipairs(source) do
    out[i] = {
      x=p.x, y=p.y, z=p.z, fx=p.fx, fy=p.fy,
      carHalfLength=p.carHalfLength, carHalfWidth=p.carHalfWidth,
      rigHalfWidth=tonumber(p.rigHalfWidth) or 0,
      rigPoses=copyRigPoses(p.rigPoses)
    }
  end
  return out
end

local function pathLength(path)
  local total = 0
  for i = 2, #path do
    local a, b = path[i - 1], path[i]
    local dx, dy = b.x - a.x, b.y - a.y
    total = total + math.sqrt(dx * dx + dy * dy)
  end
  return total
end

-- A short straight drive can finish near its start without being a loop. Require
-- both a nearby endpoint and enough travelled distance before suppressing a cap.
local function isClosedLoop(path)
  if #path < 2 then return false end
  local a, b = path[1], path[#path]
  local dx, dy = b.x - a.x, b.y - a.y
  return dx * dx + dy * dy <= 6.0 * 6.0 and pathLength(path) > 6.0
end

local function currentVehicle()
  if not be or not be.getPlayerVehicleID then return nil, nil end
  local id = be:getPlayerVehicleID(0)
  if not id then return nil, nil end
  local veh
  if be.getObjectByID then
    local ok, value = pcall(be.getObjectByID, be, id)
    if ok then veh = value end
  end
  if not veh and be.getPlayerVehicle then
    local ok, value = pcall(be.getPlayerVehicle, be, 0)
    if ok then veh = value end
  end
  return veh, id
end

local function vehicleName(veh, id)
  local name
  if core_vehicles and core_vehicles.getCurrentVehicleDetails then
    local ok, details = pcall(core_vehicles.getCurrentVehicleDetails)
    if ok and details and details.model then
      name = ((details.model.Brand and (details.model.Brand .. ' ')) or '') .. tostring(details.model.Name or '')
    end
  end
  if (not name or name == '') and veh then
    local ok, model = pcall(function() return veh.JBeam end)
    if ok and model then name = tostring(model) end
  end
  return (name and name ~= '') and name or ('Vehicle ' .. tostring(id or '?'))
end

local function vehicleNumber(veh, method, fallback, minimum, maximum)
  if not veh or not veh[method] then return fallback end
  local ok, value = pcall(veh[method], veh)
  if not ok or type(value) ~= 'number' or value <= 0 then return fallback end
  return math.max(minimum, math.min(maximum, value))
end

-- Prefer the real OOBB center over the JBeam reference node. This keeps long
-- front/rear overhangs centered inside the generated corridor.
local function vehiclePosition(veh, id)
  if be and be.getObjectOOBBCenterXYZ and id then
    local ok, x, y, z = pcall(be.getObjectOOBBCenterXYZ, be, id)
    if ok and type(x) == 'number' and type(y) == 'number' and type(z) == 'number' then
      return vec3(x, y, z)
    end
  end
  if veh and veh.getPosition then
    local ok, pos = pcall(veh.getPosition, veh)
    if ok then return pos end
  end
  return nil
end

local function vehicleFootprint(veh, id, fx, fy)
  local halfLength = vehicleNumber(veh, 'getInitialLength', 4.8, 1.0, 20.0) * 0.5
  local halfWidth = vehicleNumber(veh, 'getInitialWidth', 2.0, 0.6, 6.0) * 0.5
  if not be or not id or not be.getObjectOOBBHalfAxisXYZ then return halfLength, halfWidth end

  local initialized = true
  if be.getObjectOOBBIsInitialized then
    local ok, value = pcall(be.getObjectOOBBIsInitialized, be, id)
    initialized = ok and not (value == false or value == nil or value == 0)
  end
  if not initialized then return halfLength, halfWidth end

  -- Project all three real OOBB half axes onto the planar vehicle basis.
  -- This includes accessories such as a rear wing without guessing axis order.
  local axes = {}
  for axis = 0, 2 do
    local ok, x, y, z = pcall(be.getObjectOOBBHalfAxisXYZ, be, id, axis)
    if not ok or type(x) ~= 'number' or type(y) ~= 'number' or type(z) ~= 'number' then
      return halfLength, halfWidth
    end
    axes[#axes + 1] = {x=x, y=y}
  end
  local rightX, rightY = -fy, fx
  local obbLength, obbWidth = 0, 0
  for _, axis in ipairs(axes) do
    obbLength = obbLength + math.abs(axis.x * fx + axis.y * fy)
    obbWidth = obbWidth + math.abs(axis.x * rightX + axis.y * rightY)
  end
  if obbLength > 0.1 and obbWidth > 0.1 then
    halfLength = math.max(halfLength, math.max(0.5, math.min(10.0, obbLength)))
    halfWidth = math.max(halfWidth, math.max(0.3, math.min(3.0, obbWidth)))
  end
  return halfLength, halfWidth
end

local function vehiclePathPoint(veh, pos, id)
  local fx, fy = 1, 0
  if veh and veh.getDirectionVector then
    local ok, forward = pcall(veh.getDirectionVector, veh)
    if ok and forward then
      local length = math.sqrt(forward.x * forward.x + forward.y * forward.y)
      if length > 0.001 then fx, fy = forward.x / length, forward.y / length end
    end
  end
  local halfLength, halfWidth = vehicleFootprint(veh, id, fx, fy)
  return {
    x=pos.x, y=pos.y, z=pos.z, fx=fx, fy=fy,
    carHalfLength=halfLength, carHalfWidth=halfWidth
  }
end


-- Rig (attached vehicles) tracking. Nothing here runs outside a recording, and
-- only vehicles near the player are inspected: no map-wide scan, no FPS cost.
local RIG_MAX_DIST = 12.0        -- metres from the car
local RIG_STABLE_POS = 1.50      -- a rigid trailer may still be detected this way
local RIG_STABLE_DOT = 0.85      -- ~32 degrees of relative heading drift
local RIG_MIN_STREAK = 3         -- consecutive samples before trusting a vehicle
-- Node Grabber joints are soft: the trailer can swing metres and rotate tens of
-- degrees while STILL travelling with the player. A parked car / a car passing
-- by does not share the player's displacement, so co-motion is the robust test.
local RIG_COMOVE_MIN_DOT = -0.10   -- allow a swinging rig to move sideways
local RIG_COMOVE_MIN_RATIO = 0.15  -- the rig must actually travel, not jiggle
local RIG_COMOVE_STREAK = 3
local RIG_SWING_ANGLE = 0.35       -- ~20 degrees each side of the measured heading
local RIG_SWING_GROW = 0.35        -- extra metres on the synthesized rectangle
local RIG_MAX_VEHICLES = 3
local RIG_LAG_SAMPLES = 6        -- a trailer sits behind the car (~4.5 m)
local RIG_REACH = 10.0           -- metres of path to scan for trailer centres
local lastRigPoseCount = 0       -- diagnostic: stations with a trailer centreline
local rigCandidates = {}
local rigMotion = {carX = nil, carY = nil, prev = {}}
local rigAttached = {}
local rigManual = {}
local rigCoupler = {}
local rigHints = {}  -- vehicles selected in World Editor when FILLO was pressed
local RIG_OBSERVE_INTERVAL = 0.30   -- seconds; replay/idle detection, never per frame
local RIG_OBSERVE_BUDGET = 90.0     -- stop polling after 90 s with no detection
local RIG_OBSERVE_MIN_MOVE = 0.35   -- car must move for a stable pose to mean anything
local rigObserver = {lastAt = 0, startedAt = 0, samples = {}, prev = {},
  lastX = nil, lastY = nil, done = false}

-- Rig detection accepts EITHER a stable relative pose (a rigid/coupler trailer)
-- OR co-motion (a Node Grabber trailer that swings). A parked car or a car
-- driving past satisfies neither, so it is never adopted as part of the rig.
local function normalizeObjectId(id)
  local value = tonumber(id)
  if not value or value < 0 or value ~= math.floor(value) then return nil end
  return value
end

local function getObjectById(id)
  if not be or not be.getObjectByID then return nil end
  local ok, object = pcall(be.getObjectByID, be, id)
  return ok and object or nil
end

local function tryObjectMethod(object, method, ...)
  if not object then return nil end
  local ok, fn = pcall(function() return object[method] end)
  if not ok or type(fn) ~= 'function' then return nil end
  local called, a, b, c = pcall(fn, object, ...)
  if not called then return nil end
  return a, b, c
end

local function objectClassName(object)
  local name = tryObjectMethod(object, 'getClassName')
  if type(name) ~= 'string' or name == '' then return nil end
  return name
end

local function isVehicleObject(object)
  if not object then return false end
  local class = objectClassName(object)
  if class then return class:lower():find('vehicle', 1, true) ~= nil end
  local ok, model = pcall(function() return object.JBeam end)
  if not ok or type(model) ~= 'string' or model == '' then
    model = tryObjectMethod(object, 'getField', 'JBeam', '')
  end
  if type(model) ~= 'string' or model == '' then return false end
  local okFields, hasGeometry = pcall(function()
    return type(object.getInitialLength) == 'function'
      and type(object.getDirectionVector) == 'function'
      and type(object.getPosition) == 'function'
  end)
  return okFields and hasGeometry == true
end

local function objectDisplayName(object)
  local name = tryObjectMethod(object, 'getName')
  if type(name) ~= 'string' or name == '' then
    name = tryObjectMethod(object, 'getField', 'name', '')
  end
  if type(name) ~= 'string' then return '' end
  return name
end

local function objectVehicleId(object, fallbackId)
  local id = normalizeObjectId(tryObjectMethod(object, 'getID'))
  if not id then id = normalizeObjectId(tryObjectMethod(object, 'getId')) end
  if not id then id = normalizeObjectId(tryObjectMethod(object, 'getField', 'vid', 0)) end
  if not id then id = normalizeObjectId(fallbackId) end
  return id
end

local function findSceneObjectById(id)
  if not id or not scenetree or not scenetree.findObjectById then return nil end
  local ok, found = pcall(scenetree.findObjectById, id)
  if ok and found then return found end
  local okSelf, foundSelf = pcall(scenetree.findObjectById, scenetree, id)
  if okSelf and foundSelf then return foundSelf end
  return nil
end

-- editor.selection.object is an array of numeric scene-object IDs in BeamNG.
local function editorSelectionEntries()
  local out = {}
  if not editor or type(editor) ~= 'table' then return out end
  local selection = editor.selection
  if type(selection) ~= 'table' then return out end
  local raw = selection.object
  if raw == nil or (type(raw) == 'table' and #raw == 0 and next(raw) == nil) then
    raw = selection.objects
  end
  if type(raw) == 'table' then
    for _, entry in ipairs(raw) do out[#out + 1] = entry end
    if #out == 0 then
      if isVehicleObject(raw) or objectClassName(raw) then
        out[1] = raw
      else
        for key, entry in pairs(raw) do
          out[#out + 1] = tonumber(key) and key or entry
        end
      end
    end
  elseif raw ~= nil then
    out[1] = raw
  end
  return out
end

local function sceneObjectFromSelection(entry)
  if type(entry) == 'table' or type(entry) == 'userdata' then
    local ok, embeddedId = pcall(function() return entry.id end)
    local fallbackId = normalizeObjectId(ok and embeddedId or nil)
    if not fallbackId then fallbackId = normalizeObjectId(tryObjectMethod(entry, 'getID')) end
    return entry, fallbackId
  end
  local id = normalizeObjectId(entry)
  if not id then return nil, nil end
  local object = findSceneObjectById(id)
  if not object then object = getObjectById(id) end
  return object, id
end

local function objectCenter(id, obj)
  if be and id and be.getObjectOOBBCenterXYZ then
    local ok, x, y, z = pcall(be.getObjectOOBBCenterXYZ, be, id)
    if ok and type(x) == 'number' and type(y) == 'number' and type(z) == 'number' then
      return x, y, z
    end
  end
  local pos = tryObjectMethod(obj, 'getPosition')
  if pos and type(pos.x) == 'number' and type(pos.y) == 'number' then
    return pos.x, pos.y, tonumber(pos.z) or 0
  end
  return nil
end

local function objectHalfExtents(id, obj, fx, fy)
  if be and id and be.getObjectOOBBHalfAxisXYZ then
    local halfLong, halfLat = 0, 0
    local okAll = true
    for axis = 0, 2 do
      local ok, x, y = pcall(be.getObjectOOBBHalfAxisXYZ, be, id, axis)
      if not ok or type(x) ~= 'number' or type(y) ~= 'number' then okAll = false break end
      halfLong = halfLong + math.abs(x * fx + y * fy)
      halfLat = halfLat + math.abs(-x * fy + y * fx)
    end
    if okAll and halfLong > 0.1 and halfLat > 0.1 then
      return math.max(0.3, math.min(10.0, halfLong)), math.max(0.3, math.min(6.0, halfLat))
    end
  end
  local halfLong = vehicleNumber(obj, 'getInitialLength', 4.8, 1.0, 20.0) * 0.5
  local halfLat = vehicleNumber(obj, 'getInitialWidth', 2.0, 0.6, 6.0) * 0.5
  return halfLong, halfLat
end

-- Pose of one attached vehicle expressed in the player car's planar frame.
local function rigPose(id, obj, name, carPos, fx, fy)
  local x, y = objectCenter(id, obj)
  if not x then return nil end
  local dx, dy = x - carPos.x, y - carPos.y
  local long, lat = dx * fx + dy * fy, -dx * fy + dy * fx
  local forward = tryObjectMethod(obj, 'getDirectionVector')
  local fx2, fy2 = fx, fy
  if forward and type(forward.x) == 'number' and type(forward.y) == 'number' then
    local size = math.sqrt(forward.x * forward.x + forward.y * forward.y)
    if size > 0.001 then fx2, fy2 = forward.x / size, forward.y / size end
  end
  local halfLong, halfLat = objectHalfExtents(id, obj, fx, fy)
  return {
    id = id, name = name, x = x, y = y,
    dist = math.sqrt(dx * dx + dy * dy),
    long = long, lat = lat, sin = -fx2 * fy + fy2 * fx, cos = fx2 * fx + fy2 * fy,
    ofx = fx2, ofy = fy2, halfLong = halfLong, halfLat = halfLat
  }
end

-- Candidate IDs are cached: the map-wide vehicle list is read at most once per
-- 1.5 s and capped, never once per recorded point / per frame. Positions are
-- still measured fresh on every pose query.
local rigCandidatesCache = {at = -1e9, list = nil}
local RIG_CANDIDATE_TTL = 1.5
local RIG_CANDIDATE_MAX = 32

local function nearbyVehicles(playerId)
  if rigCandidatesCache.list and clockTotal - rigCandidatesCache.at < RIG_CANDIDATE_TTL then
    return rigCandidatesCache.list
  end
  local out, seen = {}, {}
  local function addCandidate(id, obj)
    if id and id ~= playerId and not seen[id] and #out < RIG_CANDIDATE_MAX then
      seen[id] = true
      out[#out + 1] = {id = id, object = obj,
        name = (objectDisplayName(obj) ~= '' and objectDisplayName(obj)) or ('Vehicle ' .. id)}
    end
  end
  if be and be.getObjectCount and be.getObject then
    local ok, total = pcall(be.getObjectCount, be)
    if ok and type(total) == 'number' then
      for i = 0, total - 1 do
        local got, obj = pcall(be.getObject, be, i)
        if got and obj and isVehicleObject(obj) then
          addCandidate(normalizeObjectId(tryObjectMethod(obj, 'getID')), obj)
        end
      end
      rigCandidatesCache.at, rigCandidatesCache.list = clockTotal, out
      return out
    end
  end
  if scenetree and scenetree.findClassObjects and scenetree.findObject then
    local ok, names = pcall(scenetree.findClassObjects, 'BeamNGVehicle')
    if ok and type(names) == 'table' then
      for _, n in ipairs(names) do
        local got, obj = pcall(scenetree.findObject, n)
        if got and obj and isVehicleObject(obj) then
          addCandidate(normalizeObjectId(tryObjectMethod(obj, 'getID')), obj)
        end
      end
    end
  end
  rigCandidatesCache.at, rigCandidatesCache.list = clockTotal, out
  return out
end

local function rigEntryCount()
  local n = 0
  for _ in pairs(rigAttached) do n = n + 1 end
  return n
end

local function activeRigEntries()
  local out, seen = {}, {}
  local function add(id, entry)
    if not id or seen[id] or id == activeVehicleId then return end
    seen[id] = true
    out[#out + 1] = {id = id, name = entry.name, source = entry.source,
      object = entry.object, simId = entry.simId}
  end
  for id, entry in pairs(rigManual) do add(id, entry) end
  for id, entry in pairs(rigAttached) do add(id, entry) end
  for id in pairs(rigCoupler) do
    add(id, {name = 'Coupler ' .. id, source = 'Coupler', object = getObjectById(id)})
  end
  return out
end

local function rigPoseFor(entry, carPos, fx, fy)
  local obj = getObjectById(entry.id) or entry.object
  if not obj and entry.simId then obj = findSceneObjectById(entry.simId) end
  if not obj then return nil end
  -- Vehicles AND World Editor props are valid rig members.
  return rigPose(entry.id or entry.simId, obj, entry.name, carPos, fx, fy)
end

-- Called once per recorded path point (every >= 0.75 m), never per frame.
-- Current player pose in the planar frame used by the corridor maths.
local function playerFrame()
  local veh, id = currentVehicle()
  if not veh or not id then return nil end
  local pos = vehiclePosition(veh, id)
  if not pos then return nil end
  local dir = tryObjectMethod(veh, 'getDirectionVector')
  local fx, fy = 1, 0
  if dir and type(dir.x) == 'number' and type(dir.y) == 'number' then
    local size = math.sqrt(dir.x * dir.x + dir.y * dir.y)
    if size > 0.001 then fx, fy = dir.x / size, dir.y / size end
  end
  local halfWidth = vehicleNumber(veh, 'getInitialWidth', 2.0, 0.6, 6.0) * 0.5
  return {veh = veh, id = id, pos = pos, fx = fx, fy = fy, halfWidth = halfWidth}
end

-- How much EXTRA half-width the corridor needs so this object never touches a
-- cone. Works for a BeamNGVehicle OR a World Editor prop (TSStatic trailer).
local function rigPadFor(object, id, frame)
  if not frame then return nil end
  local x, y = objectCenter(id, object)
  if not x then return nil end
  local dx, dy = x - frame.pos.x, y - frame.pos.y
  local lat = -dx * frame.fy + dy * frame.fx
  local _, halfLat = objectHalfExtents(id, object, frame.fx, frame.fy)
  local need = math.abs(lat) + halfLat + (tonumber(SETTINGS.rigMargin) or 0)
    - frame.halfWidth
  return clamp(need, 0.0, 4.0)
end

-- Our own cones/gates/rings must never be mistaken for a trailer.
local function isGeneratedMarker(object)
  local name = objectDisplayName(object):lower()
  return name:find('driftsketch', 1, true) ~= nil
end

-- Co-motion score: does this object travel WITH the player car? A swinging
-- Node Grabber trailer fails a fixed-pose test but passes this one reliably.
local function motionFollow(track, store, id, pose, cmx, cmy)
  local carMoved = math.sqrt(cmx * cmx + cmy * cmy)
  local good = 0
  local prev = store[id]
  if prev and carMoved > 0.30 then
    local vx, vy = pose.x - prev.x, pose.y - prev.y
    local vmag = math.sqrt(vx * vx + vy * vy)
    if vmag > 0.05 then
      local dot = (cmx * vx + cmy * vy) / (carMoved * vmag)
      if dot >= RIG_COMOVE_MIN_DOT and (vmag / carMoved) >= RIG_COMOVE_MIN_RATIO then
        good = 1
      end
    end
  end
  store[id] = {x = pose.x, y = pose.y}
  -- Leaky integrator: a swinging joint can produce one bad sample without
  -- losing the whole evidence. A parked car never accumulates anything.
  track.follow = good > 0
    and math.min(6, (track.follow or 0) + 1)
    or math.max(0, (track.follow or 0) - 1)
  return track.follow
end

local function resetRigObserver()
  rigCandidatesCache.at, rigCandidatesCache.list = -1e9, nil
  rigObserver.lastAt = 0
  rigObserver.startedAt = 0
  rigObserver.samples = {}
  rigObserver.prev = {}
  rigMotion.carX, rigMotion.carY, rigMotion.prev = nil, nil, {}
  rigObserver.lastX, rigObserver.lastY = nil, nil
  rigObserver.done = false
end

-- Replay / idle detection: a saved drive can contain no rig data at all (it was
-- recorded with 0.9.4). While the car moves through the replay, a Node Grabber
-- trailer travels WITH it even while swinging. 3 co-motion samples are enough.
-- This is a 3 Hz check for at most 90 s, not a per-frame or per-cone scan.
local function observeRig()
  if rigObserver.startedAt == 0 then rigObserver.startedAt = clockTotal end
  if clockTotal - rigObserver.startedAt > RIG_OBSERVE_BUDGET then
    rigObserver.done = true
    return
  end
  local frame = playerFrame()
  if not frame then return end
  local cmx, cmy = 0, 0
  if rigObserver.lastX then
    cmx = frame.pos.x - rigObserver.lastX
    cmy = frame.pos.y - rigObserver.lastY
  end
  local moved = math.sqrt(cmx * cmx + cmy * cmy)
  rigObserver.lastX, rigObserver.lastY = frame.pos.x, frame.pos.y
  if moved < RIG_OBSERVE_MIN_MOVE then return end
  for _, cand in ipairs(nearbyVehicles(frame.id)) do
    local pose = rigPose(cand.id, cand.object, cand.name, frame.pos, frame.fx, frame.fy)
    if pose and pose.dist <= RIG_MAX_DIST then
      local track = rigObserver.samples[cand.id]
      if not track then
        rigObserver.samples[cand.id] = {long = pose.long, lat = pose.lat,
          sin = pose.sin, cos = pose.cos, streak = 1, follow = 0}
        motionFollow(rigObserver.samples[cand.id], rigObserver.prev, cand.id, pose, cmx, cmy)
      else
        local dx, dy = pose.long - track.long, pose.lat - track.lat
        local dot = pose.sin * track.sin + pose.cos * track.cos
        if dx * dx + dy * dy <= RIG_STABLE_POS * RIG_STABLE_POS
            and dot >= RIG_STABLE_DOT then
          track.streak = track.streak + 1
        else
          track.streak = 1
          track.long, track.lat, track.sin, track.cos = pose.long, pose.lat, pose.sin, pose.cos
        end
        motionFollow(track, rigObserver.prev, cand.id, pose, cmx, cmy)
        if track.follow >= RIG_COMOVE_STREAK then
          rigAttached[cand.id] = {name = cand.name, source = 'Auto', object = cand.object}
          local pad = rigPadFor(cand.object, cand.id, frame)
          if pad and pad > (tonumber(SETTINGS.rigPad) or 0) then SETTINGS.rigPad = pad end
          rigObserver.done = true
          M.rebuild()
          statusError = false
          status = 'Rimorkio u zbulua vetë: ' .. tostring(cand.name)
            .. '. Konet u rindërtuan për kerrin + rimorkion bashk.'
          return M.uiState()
        end
      end
    end
  end
end

-- Manual World Editor registrations and couplers still count when automatic
-- detection is switched off.
local function rigEnabled()
  if SETTINGS.rigAware then return true end
  if next(rigManual) then return true end
  if next(rigCoupler) then return true end
  return false
end

local function sampleRig(id, carPos, p)
  if not rigEnabled() then
    p.rigHalfWidth = 0
    return
  end
  local fx, fy = p.fx, p.fy
  local seen = {}
  -- Player displacement since the previous recorded station. Co-motion needs it.
  local cmx, cmy = 0, 0
  if rigMotion.carX then
    cmx, cmy = carPos.x - rigMotion.carX, carPos.y - rigMotion.carY
  end
  rigMotion.carX, rigMotion.carY = carPos.x, carPos.y

  local candidates = SETTINGS.rigAware and nearbyVehicles(id) or {}
  -- A World Editor selection at FILLO remains an optional hint, but it is NOT
  -- required: Node Grabber attachments are found purely by co-motion.
  if SETTINGS.rigAware and next(rigHints) then
    local present = {}
    for _, cand in ipairs(candidates) do present[cand.id] = true end
    for vid in pairs(rigHints) do
      if not present[vid] then
        local object = getObjectById(vid)
        if object and isVehicleObject(object) then
          candidates[#candidates + 1] = {id = vid, object = object,
            name = objectDisplayName(object)}
        end
      end
    end
  end
  for _, cand in ipairs(candidates) do
    local pose = rigPose(cand.id, cand.object, cand.name, carPos, fx, fy)
    if pose and pose.dist <= RIG_MAX_DIST then
      seen[cand.id] = true
      local track = rigCandidates[cand.id]
      if not track then
        track = {long = pose.long, lat = pose.lat, sin = pose.sin, cos = pose.cos,
          streak = 1, follow = 0, name = cand.name}
        rigCandidates[cand.id] = track
      else
        local dx = pose.long - track.long
        local dy = pose.lat - track.lat
        local dot = pose.sin * track.sin + pose.cos * track.cos
        if dx * dx + dy * dy <= RIG_STABLE_POS * RIG_STABLE_POS and dot >= RIG_STABLE_DOT then
          track.streak = track.streak + 1
        else
          track.streak = 1
          track.long, track.lat, track.sin, track.cos = pose.long, pose.lat, pose.sin, pose.cos
        end
      end
      -- The decisive test for a Node Grabber / collision-glued trailer.
      motionFollow(track, rigMotion.prev, cand.id, pose, cmx, cmy)
      local need = rigHints[cand.id] and (RIG_COMOVE_STREAK - 1) or RIG_COMOVE_STREAK
      if track.follow >= need
          and not rigAttached[cand.id]
          and rigEntryCount() < RIG_MAX_VEHICLES then
        rigAttached[cand.id] = {name = cand.name, source = 'Auto', object = cand.object}
      end
    end
  end
  for cid, entry in pairs(rigAttached) do
    if not seen[cid] then
      entry.missing = (entry.missing or 0) + 1
      -- Keep the registration for the whole session: a swinging Node Grabber
      -- trailer can momentarily fail the pose test at speed without detaching.
      if entry.missing > 60 then entry.missing = 60 end
    else
      entry.missing = 0
    end
  end

  local width, poses = 0, {}
  for _, entry in ipairs(activeRigEntries()) do
    local pose = rigPoseFor(entry, carPos, fx, fy)
    if pose and pose.dist <= RIG_MAX_DIST then
      width = math.max(width, math.abs(pose.lat) + pose.halfLat)
      poses[#poses + 1] = {x = pose.x, y = pose.y,
        fx = pose.ofx or fx, fy = pose.ofy or fy,
        hl = pose.halfLong, hw = pose.halfLat}
    end
  end
  p.rigPoses = #poses > 0 and poses or nil
  p.rigHalfWidth = width > 0 and (width + SETTINGS.rigMargin) or 0
end

local function applyRigLag(points)
  -- Detection needs a few samples. Copy the nearest real trailer centre into the
  -- short lead-in/tail so the first and last metres are not left narrow.
  local first, last
  for i, q in ipairs(points) do
    if q.rigPoses and #q.rigPoses > 0 then
      if not first then first = i end
      last = i
    end
  end
  if not first then return end
  for i = 1, first - 1 do points[i].rigPoses = copyRigPoses(points[first].rigPoses) end
  for i = last + 1, #points do points[i].rigPoses = copyRigPoses(points[last].rigPoses) end
end

local function rigListForPanel()
  local list = {}
  for _, entry in ipairs(activeRigEntries()) do
    list[#list + 1] = {id = entry.id, name = entry.name, source = entry.source}
  end
  table.sort(list, function(a, b) return a.id < b.id end)
  return list
end

local function publicState()
  local out = {
    recording = recording,
    pointCount = #points,
    pathLength = pathLength(points),
    buildCount = #savedPaths,
    coneCount = #spawned,
    ringsBuilt = #ringObjects,
    ringSetCount = #ringSets,
    meshCount = #spawned + #ringObjects,
    vehicleName = activeVehicleName,
    rigVehicles = rigListForPanel(),
    rigCount = #rigListForPanel(),
    rigPoseCount = lastRigPoseCount,
    status = status,
    statusError = statusError,
    version = M.version,
    settings = {}
  }
  for k, v in pairs(SETTINGS) do out.settings[k] = v end
  return out
end

local function sendState()
  if guihooks and guihooks.trigger then guihooks.trigger('driftSketch.state', publicState()) end
  return publicState()
end

local function deleteList(list)
  for _, obj in ipairs(list) do
    if obj and obj.delete then pcall(function() obj:delete() end) end
  end
end

local function removeMarkers()
  if markersSolid then collisionDirty = true end
  markersSolid = false
  deleteList(spawned)
  spawned = {}
end

local function removeRings()
  if ringsSolid then collisionDirty = true end
  ringsSolid = false
  deleteList(ringObjects)
  ringObjects = {}
end

local function removeObjects()
  removeMarkers()
  removeRings()
end

local function reloadCollision()
  if not collisionDirty then return end
  if be and be.reloadCollision then pcall(be.reloadCollision, be) end
  collisionDirty = false
end

-- All generated objects live in one SimGroup. After a Lua reload the previous VM's
-- objects are still in the scene; the group lets the new VM find and remove them.
local function findGroup()
  if not scenetree or not scenetree.findObject then return nil end
  local ok, group = pcall(scenetree.findObject, GROUP_NAME)
  if ok and group then return group end
  return nil
end

local function objectGroup()
  local group = findGroup()
  if group or not createObject then return group end
  local ok, created = pcall(createObject, 'SimGroup')
  if not ok or not created then return nil end
  ok = pcall(function()
    created.canSave = false
    created:registerObject(GROUP_NAME)
    local mission = scenetree and scenetree.MissionGroup
    if mission then
      if mission.addObject then mission:addObject(created) else mission:add(created) end
    end
  end)
  return ok and created or nil
end

local function sweepGroup()
  local group = findGroup()
  if not group then return 0 end
  local count = 0
  pcall(function() count = group:getCount() end)
  if count > 0 then
    pcall(function() group:deleteAllObjects() end)
    collisionDirty = true
  end
  return count
end

local function clearAll()
  recording = false
  points = {}
  savedPaths = {}
  ringSets = {}
  ringRebuildAt = nil
  pathRebuildAt = nil
  pendingRestore = false
  removeObjects()
  sweepGroup()
  reloadCollision()
end

local function markerRadius()
  local dimensions = MESH_DIMENSIONS[SETTINGS.mesh] or MESH_DIMENSIONS.cone
  return dimensions.radius * SETTINGS.scale
end

local function markerHeight()
  local dimensions = MESH_DIMENSIONS[SETTINGS.mesh] or MESH_DIMENSIONS.cone
  return dimensions.height * SETTINGS.scale
end

-- Path shaping (0.9.1) -------------------------------------------------------------
-- The recorded centre line is resampled every PATH_STEP metres and, with Smooth path
-- ON, Gaussian-filtered over a few metres: steering corrections and drift wobble no
-- longer reach the marker lines. The corridor is the real car width plus Gap on each
-- side; drift width comes from the rotated car footprint and eases only locally.

local PATH_STEP = 0.25
local PATH_MAX_SAMPLES = 24000
local SMOOTH_SIGMA = 2.0       -- metres along the path (Smooth path ON)
local WIDTH_SIGMA = 0.55       -- metres: local width changes, without long wide tails
local DRIFT_EXTRA_MAX = 2.0    -- Drift widen adds at most this per side

local function median(values, fallback)
  if #values == 0 then return fallback end
  local sorted = {}
  for i, value in ipairs(values) do sorted[i] = value end
  table.sort(sorted)
  return sorted[math.floor((#sorted + 1) / 2)]
end

-- Real car size of one drive: the median of all samples, so a single OOBB spike
-- (a crash, a door) cannot make one stretch of the corridor wider.
local function driveCarSize(source)
  local widths, lengths = {}, {}
  for _, p in ipairs(source) do
    if type(p.carHalfWidth) == 'number' then widths[#widths + 1] = p.carHalfWidth end
    if type(p.carHalfLength) == 'number' then lengths[#lengths + 1] = p.carHalfLength end
  end
  return median(widths, 1.0), median(lengths, 2.4)
end

-- Samples every <= PATH_STEP metres along the recorded drive. Every recorded point
-- is kept as a sample, so the corridor sees the real extremes of the driven line.
local function resampleCenter(source)
  local out = {}
  local total = pathLength(source)
  if #source < 2 or total < 0.05 then
    for i, p in ipairs(source) do
      out[i] = {x = p.x, y = p.y, z = p.z, fx = p.fx, fy = p.fy,
        rigHalfWidth = tonumber(p.rigHalfWidth) or 0,
        rigPoses = copyRigPoses(p.rigPoses)}
    end
    return out, PATH_STEP
  end
  local step = math.max(PATH_STEP, total / PATH_MAX_SAMPLES)
  local function sample(a, b, t)
    local q = {x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t, z = a.z + (b.z - a.z) * t}
    if a.fx and a.fy and b.fx and b.fy then
      local fx, fy = a.fx + (b.fx - a.fx) * t, a.fy + (b.fy - a.fy) * t
      local size = math.sqrt(fx * fx + fy * fy)
      if size > 0.001 then q.fx, q.fy = fx / size, fy / size else q.fx, q.fy = b.fx, b.fy end
    end
    local aw, bw = tonumber(a.rigHalfWidth) or 0, tonumber(b.rigHalfWidth) or 0
    q.rigHalfWidth = aw + (bw - aw) * t
    q.rigPoses = interpRigPoses(a.rigPoses, b.rigPoses, t)
    return q
  end
  out[1] = sample(source[1], source[1], 0)
  for i = 1, #source - 1 do
    local a, b = source[i], source[i + 1]
    local dx, dy = b.x - a.x, b.y - a.y
    local length = math.sqrt(dx * dx + dy * dy)
    if length > 0.000001 then
      local parts = math.max(1, math.ceil(length / step - 0.0001))
      for k = 1, parts do out[#out + 1] = sample(a, b, k / parts) end
    end
  end
  if #out < 2 then return out, PATH_STEP end
  return out, total / (#out - 1)
end

-- Value at sample `from` of the least-squares line through `count` samples going
-- in direction `dir` (+1 from the start, -1 from the end).
local function fittedEnd(values, from, dir, count)
  local sx, sy, sxx, sxy = 0, 0, 0, 0
  for k = 0, count - 1 do
    local v = values[from + dir * k]
    sx, sy, sxx, sxy = sx + k, sy + v, sxx + k * k, sxy + k * v
  end
  local den = count * sxx - sx * sx
  if math.abs(den) < 1e-9 then return values[from] end
  return (sy * sxx - sx * sxy) / den
end

-- Gaussian filter. anchored = true (positions): the ends are mirrored through a
-- straight fit of the first and last few metres, so the line keeps its end heading,
-- starts and finishes where the car was (minus the wobble) and is filtered right up
-- to the ends. anchored = false (corridor widths): the window shrinks near the
-- ends, so the result never drops below what the running maximum asked for.
local function smoothValues(values, sigma, step, anchored)
  local n = #values
  if sigma <= 0 or n < 3 then return values end
  -- Never wider than the drive itself: a mirror must not run past the other end.
  local radius = math.min(n - 1, math.max(1, math.floor(3 * sigma / step + 0.5)))
  local weights = {}
  for k = 0, radius do weights[k] = math.exp(-0.5 * (k * step / sigma) ^ 2) end
  local first, last = values[1], values[n]
  if anchored then
    local count = math.max(2, math.min(n, math.floor(1.5 * sigma / step + 0.5) + 1))
    first, last = fittedEnd(values, 1, 1, count), fittedEnd(values, n, -1, count)
  end
  local function at(index)
    if index < 1 then return 2 * first - values[math.min(n, 2 - index)] end
    if index > n then return 2 * last - values[math.max(1, 2 * n - index)] end
    return values[index]
  end
  local out = {}
  for i = 1, n do
    local reach = anchored and radius or math.min(radius, i - 1, n - i)
    local sum, weight = values[i] * weights[0], weights[0]
    for k = 1, reach do
      sum = sum + (at(i - k) + at(i + k)) * weights[k]
      weight = weight + 2 * weights[k]
    end
    out[i] = sum / weight
  end
  return out
end

-- Smoothed centre line. rx/ry keep where the car really was at that sample.
local function smoothPath(source)
  local path, step = resampleCenter(source)
  local xs, ys, zs = {}, {}, {}
  for i, p in ipairs(path) do xs[i], ys[i], zs[i] = p.x, p.y, p.z end
  if SETTINGS.smooth then
    xs = smoothValues(xs, SMOOTH_SIGMA, step, true)
    ys = smoothValues(ys, SMOOTH_SIGMA, step, true)
    zs = smoothValues(zs, SMOOTH_SIGMA, step, true)
  end
  for i, p in ipairs(path) do
    p.rx, p.ry = p.x, p.y
    p.x, p.y, p.z = xs[i], ys[i], zs[i]
  end
  -- Tangents over +-1 m of the (already smooth) line.
  local reach = math.max(1, math.floor(1.0 / step + 0.5))
  for i, p in ipairs(path) do
    local a, b = path[math.max(1, i - reach)], path[math.min(#path, i + reach)]
    local dx, dy = b.x - a.x, b.y - a.y
    local size = math.sqrt(dx * dx + dy * dy)
    if size > 0.0001 then
      p.tx, p.ty = dx / size, dy / size
    elseif i > 1 then
      p.tx, p.ty = path[i - 1].tx, path[i - 1].ty
    else
      p.tx, p.ty = p.fx or 1, p.fy or 0
    end
  end
  return path, step
end

-- Distance from the smoothed line to the marker centres on each side. The base is
-- Car half width + Gap + marker radius. Every real car position nearby stays at
-- least that far from the marker. When Drift widen is enabled, each actual vehicle
-- pose contributes its rotated rectangle only where it overlaps this path station.
-- Drives recorded before 0.9.25 (or restored from 0.9.4/0.9.24) have no
-- trailer centreline. Rebuild one from the CURRENT live relative pose of the
-- attached rig, projected onto each station's own heading. Because the car
-- heading differs from the path tangent during a drift, this reproduces the
-- trailer swinging out to one side -- without widening the other side.
local function buildRigProfile(path)
  local hasRecorded = false
  for _, q in ipairs(path) do
    if q.rigPoses and #q.rigPoses > 0 then hasRecorded = true break end
  end
  if hasRecorded then return end
  local frame = playerFrame()
  local entries = activeRigEntries()
  -- One-time fallback: honour whatever the user has selected in the World
  -- Editor even before auto-detection has registered anything.
  if #entries == 0 then
    for _, sel in ipairs(editorSelectionEntries()) do
      local obj, sid = sceneObjectFromSelection(sel)
      if obj and not isGeneratedMarker(obj) and (not frame or obj ~= frame.veh) then
        local vid = objectVehicleId(obj, sid)
        if vid then
          entries[#entries + 1] = {id = vid, name = objectDisplayName(obj),
            source = 'World Editor', object = obj, simId = sid}
        end
      end
    end
  end
  if not frame or #entries == 0 then return end
  local offsets = {}
  for _, entry in ipairs(entries) do
    local pose = rigPoseFor(entry, frame.pos, frame.fx, frame.fy)
    if pose and pose.dist <= RIG_MAX_DIST then
      -- A collision-glued trailer articulates a little; add a small allowance
      -- to the synthesized rectangle (a fresh recording stores exact poses).
      offsets[#offsets + 1] = {long = pose.long, lat = pose.lat,
        sin = pose.sin or 0, cos = pose.cos or 1,
        hl = pose.halfLong + RIG_SWING_GROW,
        hw = pose.halfLat + RIG_SWING_GROW}
    end
  end
  if #offsets == 0 then return end
  for _, q in ipairs(path) do
    local fx, fy = q.fx or q.tx or 1, q.fy or q.ty or 0
    local size = math.sqrt(fx * fx + fy * fy)
    if size > 0.001 then fx, fy = fx / size, fy / size else fx, fy = 1, 0 end
    local poses = {}
    for _, o in ipairs(offsets) do
      -- d = long*forward + lat*leftNormal. The trailer keeps its own measured
      -- rotation relative to the car, so an articulated / glued rig is rotated
      -- correctly at every station instead of being treated as car-aligned.
      local ofx = o.cos * fx - o.sin * fy
      local ofy = o.cos * fy + o.sin * fx
      local px = q.x + o.long * fx - o.lat * fy
      local py = q.y + o.long * fy + o.lat * fx
      -- Old drives have only ONE live pose. A Node Grabber joint swings, so
      -- emit a small envelope of headings instead of one exact rectangle.
      -- Still localised to the trailer side; the opposite line stays tight.
      for k = -1, 1 do
        local a = k * RIG_SWING_ANGLE
        local ca, sa = math.cos(a), math.sin(a)
        poses[#poses + 1] = {x = px, y = py,
          fx = ofx * ca - ofy * sa, fy = ofx * sa + ofy * ca,
          hl = o.hl, hw = o.hw}
      end
    end
    q.rigPoses = poses
  end
end

local function corridorNeeds(path, step, halfWidth, halfLength)
  local margin = SETTINGS.gap + markerRadius()
  -- Applied when the cones are BUILT, so Rebuild / restored old drives widen too.
  -- Recorded per-station rig widths can still make individual stations wider.
  local pad = math.max(0, tonumber(SETTINGS.rigPad) or 0)
  local base = halfWidth + margin + pad
  local drift = SETTINGS.driftWidth
  -- BOTH vehicles together: an attached trailer can need a wider corridor than
  -- the car alone. Per-station clearance is the rig envelope at that station.
  local maxBase = base
  local hasRigPoses = false
  for _, c in ipairs(path) do
    if c.rigPoses and #c.rigPoses > 0 then hasRigPoses = true break end
  end
  local reachClear = math.floor((maxBase + 1.0) / step + 0.5)
  local reachDrift = drift and math.floor((halfLength + halfWidth + margin + 0.5) / step + 0.5) or 0
  -- A trailer centre can be ~5 m BEHIND the car station that recorded it, so the
  -- scan must reach far enough along the line to see it at the right station.
  local reachRig = hasRigPoses and math.ceil(RIG_REACH / step) or 0
  local reach = math.max(reachClear, reachDrift, reachRig)
  local left, right = {}, {}
  for i, c in ipairs(path) do
    local tx, ty = c.tx, c.ty
    local nx, ny = -ty, tx
    -- NO symmetric scalar widening any more: the cones move out only on the
    -- side(s) where a trailer centre actually passes.
    local stationBase = base
    local needLeft, needRight = stationBase, stationBase
    for j = math.max(1, i - reach), math.min(#path, i + reach) do
      local q = path[j]
      local dx, dy = q.rx - c.x, q.ry - c.y
      local lateral = dx * nx + dy * ny
      local along = dx * tx + dy * ty
      if math.abs(along) < stationBase then
        -- Preserve clearance around the actual driven centre line.
        local half = math.sqrt(stationBase * stationBase - along * along)
        needLeft = math.max(needLeft, lateral + half)
        needRight = math.max(needRight, half - lateral)
      end
      -- Clear every attached trailer rectangle. This is the second centreline:
      -- asymmetric, localised, and correct even when the trailer swings wide.
      local poses = q.rigPoses
      if poses then
        for _, r in ipairs(poses) do
          local rdx, rdy = r.x - c.x, r.y - c.y
          local rlat = rdx * nx + rdy * ny
          local ralong = rdx * tx + rdy * ty
          local rfx, rfy = r.fx or tx, r.fy or ty
          local rrx, rry = -rfy, rfx
          local hl, hw = tonumber(r.hl) or 2.4, tonumber(r.hw) or 1.0
          local extra = margin + (tonumber(SETTINGS.rigMargin) or 0)
          local alongExtent = hl * math.abs(rfx * tx + rfy * ty)
            + hw * math.abs(rrx * tx + rry * ty) + extra
          if math.abs(ralong) <= alongExtent then
            local extent = hl * math.abs(rfx * nx + rfy * ny)
              + hw * math.abs(rrx * nx + rry * ny) + extra
            needLeft = math.max(needLeft, rlat + extent)
            needRight = math.max(needRight, extent - rlat)
          end
        end
      end
      if drift and math.abs(i - j) <= reachDrift then
        local fx, fy = q.fx or tx, q.fy or ty
        local rightX, rightY = -fy, fx
        -- Project the real car rectangle onto this station's tangent/normal.
        -- A straight car contributes its body width only; sideways yaw brings its
        -- length across the corridor, but affects only the locally overlapping path.
        local alongExtent = halfLength * math.abs(fx * tx + fy * ty)
          + halfWidth * math.abs(rightX * tx + rightY * ty) + margin
        if math.abs(along) <= alongExtent then
          local extent = halfLength * math.abs(fx * nx + fy * ny)
            + halfWidth * math.abs(rightX * nx + rightY * ny) + margin
          extent = math.min(math.max(extent, stationBase), stationBase + DRIFT_EXTRA_MAX)
          needLeft = math.max(needLeft, lateral + extent)
          needRight = math.max(needRight, extent - lateral)
        end
      end
    end
    left[i], right[i] = needLeft, needRight
  end
  return left, right, base
end

-- Running maximum, then a Gaussian no wider than that window: the eased width is
-- never below what any sample needs, and it changes gently.
local function easeNeeds(values, step)
  local radius = math.max(1, math.floor(3 * WIDTH_SIGMA / step + 0.5))
  local maxed = {}
  for i = 1, #values do
    local high = values[i]
    for j = math.max(1, i - radius), math.min(#values, i + radius) do
      if values[j] > high then high = values[j] end
    end
    maxed[i] = high
  end
  return smoothValues(maxed, radius * step / 3, step, false)
end

-- On the inside of a turn tighter than the corridor the offset line folds back over
-- itself. A point that lies inside the corridor of any other sample is dropped.
-- Smooth path OFF follows the raw line, whose small wobble may come a little closer
-- to a neighbouring sample: there only a deep intrusion (a real fold) is dropped.
local function markFolds(line, path, offsetsLeft, offsetsRight)
  local depth = SETTINGS.smooth and 1.0 or 0.8
  local largest = 0
  for i = 1, #path do largest = math.max(largest, offsetsLeft[i], offsetsRight[i]) end
  local cell = math.max(2.0, largest)
  local grid = {}
  for index, c in ipairs(path) do
    local key = math.floor(c.x / cell) * 1000000 + math.floor(c.y / cell)
    local bucket = grid[key]
    if not bucket then bucket = {}; grid[key] = bucket end
    bucket[#bucket + 1] = index
  end
  for _, q in ipairs(line) do
    local gx, gy = math.floor(q.x / cell), math.floor(q.y / cell)
    local blocked = false
    for ox = -1, 1 do
      for oy = -1, 1 do
        local bucket = grid[(gx + ox) * 1000000 + gy + oy]
        if bucket then
          for _, index in ipairs(bucket) do
            local c = path[index]
            local dx, dy = q.x - c.x, q.y - c.y
            local side = (dx * -c.ty + dy * c.tx) >= 0 and offsetsLeft[index] or offsetsRight[index]
            local limit = math.min(q.offset, side) * depth - 0.03
            if dx * dx + dy * dy < limit * limit then blocked = true; break end
          end
        end
        if blocked then break end
      end
      if blocked then break end
    end
    q.blocked = blocked
  end
end

-- Resample one offset polyline by its own arc length. Inner and outer curves have
-- different lengths, so each gets independent physical spacing.
local function resampleLine(path, spacing)
  if #path < 2 then return {} end
  local total = pathLength(path)
  if total < 0.05 then return {} end
  local count = math.floor(total / spacing + 0.0001) + 1
  local samples = {}
  local segment, segmentStart, segmentLength = 1, 0, 0
  local function updateSegment()
    local a, b = path[segment], path[segment + 1]
    local dx, dy = b.x - a.x, b.y - a.y
    segmentLength = math.sqrt(dx * dx + dy * dy)
  end
  updateSegment()
  for index = 0, count - 1 do
    local distance = math.min(total, index * spacing)
    while segment < #path - 1 and distance > segmentStart + segmentLength do
      segmentStart = segmentStart + segmentLength
      segment = segment + 1
      updateSegment()
    end
    local a, b = path[segment], path[segment + 1]
    local t = 0
    if segmentLength > 0.0001 then t = math.max(0, math.min(1, (distance - segmentStart) / segmentLength)) end
    local nx, ny = a.nx + (b.nx - a.nx) * t, a.ny + (b.ny - a.ny) * t
    local size = math.sqrt(nx * nx + ny * ny)
    if size > 0.001 then nx, ny = nx / size, ny / size else nx, ny = a.nx, a.ny end
    samples[#samples + 1] = {
      x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t, z = a.z + (b.z - a.z) * t, nx = nx, ny = ny
    }
  end
  return samples
end

-- Markers every `spacing` metres along the kept runs of one line (a folded stretch
-- is a break, never a chord across the corridor), within the object cap.
local function placeAlong(line, spacing, maxSamples)
  local runs, run = {}, nil
  for _, q in ipairs(line) do
    if q.blocked then
      run = nil
    else
      if not run then run = {}; runs[#runs + 1] = run end
      run[#run + 1] = q
    end
  end
  local total = 0
  for _, part in ipairs(runs) do total = total + pathLength(part) end
  local step = spacing
  if total / step + #runs > maxSamples then step = total / math.max(1, maxSamples - #runs) end
  local out = {}
  for _, part in ipairs(runs) do
    for _, q in ipairs(resampleLine(part, step)) do
      if #out >= maxSamples then return out end
      out[#out + 1] = q
    end
  end
  return out
end

-- The end row is dense enough that the selected mesh closes the corridor visually,
-- even when the side-line spacing is set wide. Reserve its objects in the drive cap.
local function finishRowPitch()
  return math.max(0.3, math.min(SETTINGS.spacing, markerRadius() * 2.0))
end

local function finishRowCount(span)
  return math.max(2, math.ceil(math.max(0, span) / finishRowPitch()) + 1)
end

-- Two clean marker lines (right, left), the corridor half width, and the finish row.
local function buildOffsetLines(source, spacing, reserveObjects, includeFinishRow)
  local path, step = smoothPath(source)
  if #path < 2 then return {{}, {}}, 0, nil end
  buildRigProfile(path)
  lastRigPoseCount = 0
  for _, q in ipairs(path) do
    if q.rigPoses and #q.rigPoses > 0 then lastRigPoseCount = lastRigPoseCount + 1 end
  end
  local halfWidth, halfLength = driveCarSize(source)
  local needLeft, needRight, base = corridorNeeds(path, step, halfWidth, halfLength)
  local offsetsLeft, offsetsRight = easeNeeds(needLeft, step), easeNeeds(needRight, step)
  local right, left = {}, {}
  for i, c in ipairs(path) do
    local nx, ny = -c.ty, c.tx
    left[i] = {x = c.x + nx * offsetsLeft[i], y = c.y + ny * offsetsLeft[i], z = c.z,
      nx = nx, ny = ny, offset = offsetsLeft[i]}
    right[i] = {x = c.x - nx * offsetsRight[i], y = c.y - ny * offsetsRight[i], z = c.z,
      nx = -nx, ny = -ny, offset = offsetsRight[i]}
  end
  markFolds(left, path, offsetsLeft, offsetsRight)
  markFolds(right, path, offsetsLeft, offsetsRight)
  local finishRow, rowReserve = nil, 0
  if includeFinishRow then
    local c = path[#path]
    local sourceEnd = source[#source] or {}
    local fx, fy = sourceEnd.fx or c.tx, sourceEnd.fy or c.ty
    local facingLength = math.sqrt(fx * fx + fy * fy)
    if facingLength > 0.001 then fx, fy = fx / facingLength, fy / facingLength else fx, fy = c.tx, c.ty end
    local rightX, rightY = -fy, fx
    local endHalfLength = tonumber(sourceEnd.carHalfLength) or halfLength
    local endHalfWidth = tonumber(sourceEnd.carHalfWidth) or halfWidth
    local alongHalf = endHalfLength * math.abs(fx * c.tx + fy * c.ty)
      + endHalfWidth * math.abs(rightX * c.tx + rightY * c.ty)
    -- Put the finish line just beyond the last car footprint, not through the car.
    local rigRear = 0
    for _, r in ipairs(path[#path].rigPoses or {}) do
      local dx, dy = r.x - c.x, r.y - c.y
      local behind = -(dx * c.tx + dy * c.ty) + (tonumber(r.hl) or 2.4)
      if behind > rigRear then rigRear = behind end
    end
    local extension = math.max(1.5, alongHalf + SETTINGS.gap + markerRadius() + 0.4,
      rigRear + SETTINGS.gap + markerRadius() + 0.4)
    local zSlope = 0
    if #path > 1 then
      local prev = path[#path - 1]
      local segment = math.sqrt((c.x - prev.x) ^ 2 + (c.y - prev.y) ^ 2)
      if segment > 0.001 then zSlope = clamp((c.z - prev.z) / segment, -0.36, 0.36) end
    end
    local span = offsetsLeft[#path] + offsetsRight[#path]
    finishRow = {
      baseP = c,
      p = {x = c.x + c.tx * extension, y = c.y + c.ty * extension, z = c.z + zSlope * extension},
      extension = extension, zSlope = zSlope,
      tx = c.tx, ty = c.ty, nx = -c.ty, ny = c.tx,
      left = offsetsLeft[#path], right = offsetsRight[#path], count = finishRowCount(span)
    }
    -- Reserve the dense cross-row and both short side extensions in the drive cap.
    local sideStep = math.max(0.5, spacing)
    rowReserve = finishRow.count + 2 * (math.ceil(extension / sideStep) + 1)
  end
  local maxSamples = math.max(2, math.floor((SETTINGS.maxCones - (reserveObjects or 0) - rowReserve) / 2))
  return {placeAlong(right, spacing, maxSamples), placeAlong(left, spacing, maxSamples)}, base, finishRow
end

local function castDown(x, y, fromZ, maxLength)
  if not castRayStatic then return nil end
  local ok, distance = pcall(castRayStatic, vec3(x, y, fromZ), vec3(0, 0, -1), maxLength)
  if ok and type(distance) == 'number' and distance >= 0 and distance < maxLength then
    return fromZ - distance
  end
  return nil
end

-- Ground under a recorded path point. The short ray stays below bridges and trees.
local function groundZ(x, y, recordedZ)
  return castDown(x, y, recordedZ + 4, 12) or (recordedZ + SETTINGS.groundOffset)
end

-- Ground away from the recorded line (gate towers, rings ahead of the car): short ray
-- first, then a long one for hills. The second value reports whether a ray hit.
local function groundAt(x, y, zHint)
  local z = castDown(x, y, zHint + 4, 14)
  if z then return z, true end
  z = castDown(x, y, zHint + 60, 140)
  if z then return z, true end
  return zHint + SETTINGS.groundOffset, false
end

local materialsLoaded = false

-- Runtime-created TSStatic shapes do not reliably cause a mod-root material
-- library to be loaded. Load it explicitly once, before the first shape is
-- created; retry on the next build if the VFS was not ready on the first try.
local function ensureMaterials()
  if materialsLoaded then return true end
  if type(loadJsonMaterialsFile) ~= 'function' then return false end
  if FS and FS.fileExists then
    local ok, exists = pcall(FS.fileExists, FS, MATERIAL_FILE)
    if not ok or not exists then return false end
  end
  local ok, err = pcall(loadJsonMaterialsFile, MATERIAL_FILE)
  if not ok then
    if log then log('E', 'driftSketch', 'Cannot load materials: ' .. tostring(err)) end
    return false
  end
  materialsLoaded = true
  if log then log('I', 'driftSketch', 'Loaded ' .. MATERIAL_FILE) end
  return true
end

-- BeamNG convention: local +Y is forward. quatFromDir maps +Y onto dir (and keeps
-- +Z up), which is exactly what TSStatic setPosRot expects.
local function rotationFromDir(dx, dy, dz)
  if not quatFromDir then return nil end
  local ok, q = pcall(quatFromDir, vec3(dx, dy, dz or 0))
  if ok and q then return q end
  return nil
end

local function addToScene(obj, group)
  if group then
    local ok = pcall(function() group:addObject(obj) end)
    if ok then return true end
  end
  local mission = scenetree and scenetree.MissionGroup
  if mission then
    return pcall(function()
      if mission.addObject then mission:addObject(obj) else mission:add(obj) end
    end)
  end
  return false
end

local function spawnMesh(x, y, z, options)
  if not createObject then return nil end
  local ok, obj = pcall(createObject, 'TSStatic')
  if not ok or not obj then return nil end
  objectSerial = objectSerial + 1
  obj.shapeName = options.shapeName
  obj.canSave = false
  obj.useInstanceRenderData = true
  if obj.setField then
    obj:setField('collisionType', 0, SETTINGS.collision and 'Visible Mesh Final' or 'None')
    obj:setField('decalType', 0, 'None')
  end
  local rotation = options.rotation
  if rotation and obj.setPosRot then
    obj:setPosRot(x, y, z, rotation.x, rotation.y, rotation.z, rotation.w)
  else
    obj:setPosition(vec3(x, y, z))
  end
  local scale = options.scale or SETTINGS.scale
  if type(scale) == 'number' then scale = vec3(scale, scale, scale) end
  obj:setScale(scale)
  obj:registerObject(string.format('%s%s_%d', options.prefix or 'driftSketch_', session, objectSerial))
  addToScene(obj, options.group)
  local list = options.list or spawned
  list[#list + 1] = obj
  if SETTINGS.collision then
    collisionDirty = true
    if list == ringObjects then ringsSolid = true else markersSolid = true end
  end
  return obj
end

local function objectNoun()
  if SETTINGS.gates or SETTINGS.rings or #ringSets > 0 then return 'objects' end
  local nouns = {
    cone = 'cones', tireStack = 'tire stacks', raceCurb = 'racing kerbs',
    apexBump = 'apex markers', checkeredFlag = 'checkered flags',
    brake100 = '100 m boards', brake50 = '50 m boards'
  }
  return nouns[SETTINGS.mesh] or 'markers'
end

-- Path markers ------------------------------------------------------------------

local GOLDEN_ANGLE = 2.399963229728653

local function markerShape(index)
  if SETTINGS.mesh == 'tireStack' then
    local pattern = TIRE_PATTERNS[SETTINGS.tireColors] or TIRE_PATTERNS.rw
    return ASSET_DIR .. 'tire_stack_' .. pattern[((index - 1) % #pattern) + 1] .. '.dae'
  end
  return ASSET_DIR .. (MESH_FILES[SETTINGS.mesh] or MESH_FILES.cone)
end

local function markerRotation(q, index, faceDirection)
  if SETTINGS.mesh == 'tireStack' then
    -- Tyre stacks are round: a golden-angle yaw breaks up the repeated tread.
    local angle = index * GOLDEN_ANGLE
    return rotationFromDir(math.cos(angle), math.sin(angle), 0)
  end
  if SETTINGS.mesh == 'apexBump' or SETTINGS.mesh == 'raceCurb' then
    -- Both pads have a longitudinal axis in local X; +Y follows the boundary normal.
    if q.nx and q.ny then return rotationFromDir(q.nx, q.ny, 0) end
    return nil
  end
  -- Faces on flags and brake boards point into the course; the finish row faces
  -- the approaching car. Cones and checker flags remain readable from both sides.
  local dx, dy
  if faceDirection then
    dx, dy = faceDirection.x, faceDirection.y
  elseif q.nx and q.ny then
    dx, dy = -q.nx, -q.ny
  end
  if dx and dy and (dx * dx + dy * dy) > 0.000001 then
    return rotationFromDir(dx, dy, 0)
  end
  return nil
end

-- Gates -------------------------------------------------------------------------

local function pathTangent(source, index)
  local a = source[math.max(1, index - 1)]
  local b = source[math.min(#source, index + 1)]
  local dx, dy = b.x - a.x, b.y - a.y
  local length = math.sqrt(dx * dx + dy * dy)
  if length > 0.001 then return dx / length, dy / length end
  local p = source[index]
  if p and p.fx and p.fy then return p.fx, p.fy end
  return 1, 0
end

-- A gate is scaled uniformly (no stretched banner) so its tower base plates stay at
-- least ~1 m outside the marker lines next to it. Only markers close to the gate
-- count: another leg of the track tens of metres away must not inflate the gate.
local function gateScale(p, tx, ty, lines, base)
  local nx, ny = -ty, tx
  local need = base + 1.0
  local limit = base + 4.0
  for _, line in ipairs(lines or {}) do
    for _, q in ipairs(line) do
      local dx, dy = q.x - p.x, q.y - p.y
      if math.abs(dx * tx + dy * ty) <= 3.0 then
        local lateral = math.abs(dx * nx + dy * ny)
        if lateral <= limit then need = math.max(need, lateral + 0.9) end
      end
    end
  end
  return clamp(need / GATE_CLEAR_HALF, GATE_MIN_SCALE, GATE_MAX_SCALE)
end

-- Markers can never stand inside a tower footprint (wide drift corridors at the
-- maximum gate scale, or a second leg passing next to a tower).
local function trimGateFootprint(lines, p, tx, ty, scale)
  local nx, ny = -ty, tx
  local inner = GATE_CLEAR_HALF * scale - markerRadius() - 0.15
  local outer = GATE_FOOT_OUTER * scale + markerRadius() + 0.25
  local along = GATE_FOOT_ALONG * scale + markerRadius() + 0.25
  for index, line in ipairs(lines) do
    local kept = {}
    for _, q in ipairs(line) do
      local dx, dy = q.x - p.x, q.y - p.y
      local lateral = math.abs(dx * nx + dy * ny)
      if not (math.abs(dx * tx + dy * ty) <= along and lateral >= inner and lateral <= outer) then
        kept[#kept + 1] = q
      end
    end
    lines[index] = kept
  end
end

local function spawnGate(gate, group)
  local p, tx, ty, scale = gate.p, gate.tx, gate.ty, gate.scale
  local nx, ny = -ty, tx
  -- Stand on the lowest of centre and both towers: no tower floats on a slope.
  local z = groundZ(p.x, p.y, p.z)
  local reach = GATE_TOWER_CENTER * scale
  for _, side in ipairs({-1, 1}) do
    local towerZ = groundAt(p.x + nx * reach * side, p.y + ny * reach * side, p.z)
    if towerZ < z then z = towerZ end
  end
  return spawnMesh(p.x, p.y, z, {
    shapeName = ASSET_DIR .. (gate.kind == 'finish' and 'gate_finish.dae' or 'gate_start.dae'),
    scale = scale,
    rotation = rotationFromDir(tx, ty, 0),
    list = spawned,
    group = group,
    prefix = 'driftSketch_gate_'
  })
end

-- Rings -------------------------------------------------------------------------

local function pointAtDistance(path, distance)
  local walked = 0
  for i = 2, #path do
    local a, b = path[i - 1], path[i]
    local dx, dy = b.x - a.x, b.y - a.y
    local segment = math.sqrt(dx * dx + dy * dy)
    if segment > 0.0001 and walked + segment >= distance then
      local t = math.max(0, math.min(1, (distance - walked) / segment))
      return a.x + dx * t, a.y + dy * t, a.z + (b.z - a.z) * t
    end
    walked = walked + segment
  end
  local last = path[#path]
  return last.x, last.y, last.z
end

-- Rings on a recorded drive: centred on the line, every Ring gap metres, up to
-- Ring count. Optional truss gates reserve 8 m; without them, keep the finish row clear.
local function pathRingFrames(path)
  local frames = {}
  local line = smoothPath(path)
  if #line < 2 then return frames end
  local total = pathLength(line)
  local startMargin = SETTINGS.gates and 8.0 or 1.0
  local closedLoop = isClosedLoop(path)
  local ringDepth = RING_TUBE * (SETTINGS.ringSize / RING_OPENING) + markerRadius() + 0.25
  local finishMargin = SETTINGS.gates and 8.0 or (closedLoop and 1.0 or math.max(1.0, ringDepth + 0.5))
  local gap = SETTINGS.ringGap
  local distance = math.max(gap, startMargin)
  while #frames < SETTINGS.ringCount and distance <= total - finishMargin + 0.001 do
    local x, y, z = pointAtDistance(line, distance)
    local ax, ay, az = pointAtDistance(line, math.max(0, distance - 2.0))
    local bx, by, bz = pointAtDistance(line, math.min(total, distance + 2.0))
    local tx, ty = bx - ax, by - ay
    local size = math.sqrt(tx * tx + ty * ty)
    if size > 0.001 then
      frames[#frames + 1] = {x = x, y = y, z = z, tx = tx / size, ty = ty / size, slope = (bz - az) / size}
    end
    distance = distance + gap
  end
  return frames
end

-- A straight line of rings in front of where the car stood when it was placed.
local function aheadRingFrames(set)
  local frames = {}
  local lead = (set.halfLength or 2.4) + SETTINGS.ringGap
  for k = 0, SETTINGS.ringCount - 1 do
    local distance = lead + k * SETTINGS.ringGap
    frames[#frames + 1] = {
      x = set.x + set.fx * distance, y = set.y + set.fy * distance, z = set.z, tx = set.fx, ty = set.fy
    }
  end
  return frames
end

-- The ring origin is the lower edge of its clear opening. When the recorded point
-- is clearly airborne, follow its height (minus the vehicle's centre-to-lower-body
-- offset); otherwise keep the familiar ground-level placement.
local function ringBaseHeight(frame)
  local ground, hit = groundAt(frame.x, frame.y, frame.z)
  if SETTINGS.ringFollowAir and hit and frame.z - ground > RING_AIRBORNE_THRESHOLD then
    return math.max(ground, frame.z - RING_VEHICLE_DATUM), ground, true
  end
  return ground, ground, false
end

-- Markers whose footprint meets a low ring are left out, so its bottom tube never
-- cuts through a cone or tyre stack. Airborne or lifted rings do not need a ground gap.
local function trimRingCrossings(lines, frames)
  local scale = SETTINGS.ringSize / RING_OPENING
  local tubeBottom = 2 * RING_TUBE * scale
  for _, frame in ipairs(frames) do
    local baseZ, ground = ringBaseHeight(frame)
    if baseZ - ground + SETTINGS.ringLift - tubeBottom > markerHeight() + 0.1 then
      frame.clearsMarkers = true
    end
  end
  local halfSpan = (RING_OPENING * 0.5 + 2 * RING_TUBE) * scale + markerRadius() + 0.3
  local halfDepth = RING_TUBE * scale + markerRadius() + 0.25
  for index, line in ipairs(lines) do
    local kept = {}
    for _, q in ipairs(line) do
      local blocked = false
      for _, frame in ipairs(frames) do
        if not frame.clearsMarkers then
          local dx, dy = q.x - frame.x, q.y - frame.y
          if math.abs(dx * frame.tx + dy * frame.ty) <= halfDepth
            and math.abs(dy * frame.tx - dx * frame.ty) <= halfSpan then
            blocked = true
            break
          end
        end
      end
      if not blocked then kept[#kept + 1] = q end
    end
    lines[index] = kept
  end
  return lines
end

-- The ring origin is the lower edge of its clear opening. Grounded rings use the
-- terrain slope; when Follow airborne path detects a jump, rings follow the recorded
-- path pitch and height. Lift is added after either base height is chosen.
local function spawnRing(frame, group)
  if #ringObjects >= RING_MAX_TOTAL then return nil end
  local scale = SETTINGS.ringSize / RING_OPENING
  local z, ground, airborne = ringBaseHeight(frame)
  local probe = math.max(1.5, SETTINGS.ringSize * 0.2)
  local zf, hitF = groundAt(frame.x + frame.tx * probe, frame.y + frame.ty * probe, ground)
  local zb, hitB = groundAt(frame.x - frame.tx * probe, frame.y - frame.ty * probe, ground)
  local slope = 0
  if airborne then
    slope = clamp(tonumber(frame.slope) or 0, -0.36, 0.36)
  elseif hitF and hitB then
    slope = clamp((zf - zb) / (2 * probe), -0.36, 0.36)
  end
  return spawnMesh(frame.x, frame.y, z + SETTINGS.ringLift, {
    shapeName = ASSET_DIR .. 'ring.dae',
    scale = scale,
    rotation = rotationFromDir(frame.tx, frame.ty, slope),
    list = ringObjects,
    group = group,
    prefix = 'driftSketch_ring_'
  })
end

local function buildRingSets(group)
  for _, set in ipairs(ringSets) do
    for _, frame in ipairs(aheadRingFrames(set)) do spawnRing(frame, group) end
  end
end

-- Finish-only cross-row made from the currently selected mesh. The start remains
-- open. Both side lines continue beyond the final car and meet the cross-row.
local function prepareFinishRow(row, lines)
  if not row or not row.p or not row.baseP or not row.tx or not row.ty then return nil end
  local p, baseP = row.p, row.baseP
  local tx, ty, nx, ny = row.tx, row.ty, row.nx, row.ny
  local backset = markerRadius() * 1.8
  local tieThreshold = markerRadius() * 2.0
  local sideStep = math.max(0.5, SETTINGS.spacing)
  local tieDistance = math.max(0, row.extension - backset)
  local pending = {}
  local function queueMarker(x, y, distance, q, faceDirection, prefix)
    local zHint = baseP.z + row.zSlope * distance
    pending[#pending + 1] = {
      x = x, y = y, z = groundZ(x, y, zHint),
      q = q, faceDirection = faceDirection, prefix = prefix
    }
  end
  local function alreadyNear(x, y, line)
    for _, q in ipairs(line or {}) do
      local dx, dy = q.x - x, q.y - y
      if dx * dx + dy * dy <= tieThreshold * tieThreshold then return true end
    end
    for _, q in ipairs(pending) do
      local dx, dy = q.x - x, q.y - y
      if dx * dx + dy * dy <= tieThreshold * tieThreshold then return true end
    end
    return false
  end

  -- Extend both side lines past the last recorded car position so the finish row
  -- joins them beyond the bumper instead of forming a wall through the stopped car.
  for side, lateral in ipairs({-row.right, row.left}) do
    local outwardX, outwardY = side == 1 and -nx or nx, side == 1 and -ny or ny
    local distance = 0
    while distance < tieDistance - 0.001 do
      local x = baseP.x + tx * distance + nx * lateral
      local y = baseP.y + ty * distance + ny * lateral
      if not alreadyNear(x, y, lines[side]) then
        local q = {x = x, y = y, nx = outwardX, ny = outwardY}
        queueMarker(x, y, distance, q, nil, 'driftSketch_finishExtension_')
      end
      distance = distance + sideStep
    end
    local x = baseP.x + tx * tieDistance + nx * lateral
    local y = baseP.y + ty * tieDistance + ny * lateral
    if not alreadyNear(x, y, lines[side]) then
      local q = {x = x, y = y, nx = outwardX, ny = outwardY}
      queueMarker(x, y, tieDistance, q, nil, 'driftSketch_finishTie_')
    end
  end

  local count = math.max(2, row.count or finishRowCount(row.left + row.right))
  local faceDirection = {x = -tx, y = -ty}
  for i = 0, count - 1 do
    local t = i / (count - 1)
    local lateral = -row.right + (row.left + row.right) * t
    local x, y = p.x + nx * lateral, p.y + ny * lateral
    local q = {x = x, y = y, nx = nx, ny = ny}
    queueMarker(x, y, row.extension, q, faceDirection, 'driftSketch_finish_')
  end
  return pending
end

local function spawnFinishRow(pending, group)
  -- Ground rays were resolved before this path's side markers were added, so a
  -- solid cone/curb cannot become the false ground surface for a neighbouring one.
  for _, item in ipairs(pending or {}) do
    local index = #spawned + 1
    spawnMesh(item.x, item.y, item.z, {
      shapeName = markerShape(index),
      rotation = markerRotation(item.q, index, item.faceDirection),
      list = spawned, group = group, prefix = item.prefix
    })
  end
end

-- Builds ------------------------------------------------------------------------

local function buildPath(path, group)
  -- A closed loop has no distinct finish end to cap.
  local closedLoop = isClosedLoop(path)
  local b = path[#path]
  local includeFinishRow = #path >= 2 and not closedLoop
  local gateReserve = SETTINGS.gates and (#path >= 2 and (closedLoop and 1 or 2) or 0) or 0
  local lines, base, finishRow = buildOffsetLines(path, math.max(0.5, SETTINGS.spacing), gateReserve, includeFinishRow)
  local before = #spawned
  local gates = {}
  if SETTINGS.gates and #path >= 2 then
    local sx, sy = pathTangent(path, 1)
    gates[1] = {kind = 'start', p = path[1], tx = sx, ty = sy}
    -- A closed loop ending near its start keeps one gate instead of two overlapping.
    if not closedLoop then
      local ex, ey = pathTangent(path, #path)
      gates[2] = {kind = 'finish', p = b, tx = ex, ty = ey}
    end
    for _, gate in ipairs(gates) do
      gate.scale = gateScale(gate.p, gate.tx, gate.ty, lines, base)
      trimGateFootprint(lines, gate.p, gate.tx, gate.ty, gate.scale)
    end
  end
  local rings = SETTINGS.rings and pathRingFrames(path) or {}
  if #rings > 0 then trimRingCrossings(lines, rings) end
  -- Resolve the finish row's terrain before this path creates any solid markers.
  local finishObjects = finishRow and prepareFinishRow(finishRow, lines) or nil
  local count = math.max(#lines[1], #lines[2])
  for index = 1, count do
    for _, line in ipairs(lines) do
      local q = line[index]
      if q then
        spawnMesh(q.x, q.y, groundZ(q.x, q.y, q.z), {
          shapeName = markerShape(index),
          rotation = markerRotation(q, index),
          list = spawned,
          group = group,
          prefix = 'driftSketch_'
        })
      end
    end
  end
  -- Build optional overhead gates before the finish row so collision raycasts cannot
  -- accidentally use a finish marker as the gate's ground surface.
  for _, gate in ipairs(gates) do spawnGate(gate, group) end
  if finishObjects then spawnFinishRow(finishObjects, group) end
  for _, frame in ipairs(rings) do spawnRing(frame, group) end
  return #spawned - before
end

local function rebuildEverything()
  removeObjects()
  -- Old solid shapes must leave the physics world before the new ground rays.
  reloadCollision()
  ensureMaterials()
  local group = objectGroup()
  for _, path in ipairs(savedPaths) do buildPath(path, group) end
  buildRingSets(group)
  reloadCollision()
end

local function rebuildRingsOnly()
  removeRings()
  reloadCollision()
  ensureMaterials()
  buildRingSets(objectGroup())
  reloadCollision()
end

local function ringSummary()
  return string.format('%d rings · %.1f m opening · %.0f m apart', #ringObjects, SETTINGS.ringSize, SETTINGS.ringGap)
end

-- Ring sliders rebuild only the rings (a short debounce keeps dragging smooth).
-- Rings on a drive also open gaps in its marker lines, so those need a full rebuild.
local function applyRingSettings()
  if recording then return end
  if SETTINGS.rings and #savedPaths > 0 then rebuildEverything() else rebuildRingsOnly() end
  statusError = false
  status = 'Rings updated: ' .. ringSummary() .. '.'
end

local function scheduleRings()
  if recording then return end
  if #ringSets > 0 or (SETTINGS.rings and #savedPaths > 0) then
    ringRebuildAt = clockTotal + 0.35
  end
end

-- Public API ----------------------------------------------------------------------

function M.start()
  if recording then return sendState() end
  if not SETTINGS.keepBuilds then
    savedPaths = {}
    removeObjects()
    reloadCollision()
    if #ringSets > 0 then
      ensureMaterials()
      buildRingSets(objectGroup())
      reloadCollision()
    end
  end
  -- Fresh detection for each drive. Manually registered vehicles (World Editor)
  -- stay registered for the whole session.
  rigCandidates = {}
  rigAttached = {}
  rigHints = {}
  rigMotion.carX, rigMotion.carY, rigMotion.prev = nil, nil, {}
  resetRigObserver()
  -- If the trailer is selected in World Editor when recording starts, use that
  -- as a hint (the pose test below still decides whether it is really attached).
  for _, entry in ipairs(editorSelectionEntries()) do
    local object, selectionId = sceneObjectFromSelection(entry)
    if object and isVehicleObject(object) then
      local vid = objectVehicleId(object, selectionId)
      if vid then rigHints[vid] = true end
    end
  end
  local veh, id = currentVehicle()
  activeVehicleId = id
  activeVehicleName = vehicleName(veh, id)
  points = {}
  recording = true
  statusError = false
  status = id and ('Recording ' .. activeVehicleName .. '…') or 'Recording armed. Enter a vehicle.'
  return sendState()
end

function M.stop()
  if not recording then return sendState() end
  recording = false
  if #points < 2 or pathLength(points) < 1.0 then
    statusError = true
    status = 'Drive at least 1 metre before Stop & Build.'
    return sendState()
  end
  applyRigLag(points)
  savedPaths[#savedPaths + 1] = copyPoints(points)
  ensureMaterials()
  local ringsBefore = #ringObjects
  local created = buildPath(points, objectGroup())
  reloadCollision()
  local rings = #ringObjects - ringsBefore
  statusError = created == 0
  if created > 0 then
    status = 'Built ' .. tostring(created) .. ' ' .. objectNoun()
      .. (rings > 0 and (' + ' .. tostring(rings) .. ' rings') or '')
      .. '. Open BeamNG replay — they stay in the scene.'
  else
    status = 'No objects could be created.'
  end
  return sendState()
end

function M.rebuild()
  if recording then
    statusError = true
    status = 'Stop recording before Rebuild.'
    return sendState()
  end
  ringRebuildAt = nil
  pathRebuildAt = nil
  if #savedPaths == 0 and #ringSets == 0 then
    removeObjects()
    reloadCollision()
    statusError = false
    status = 'No saved drive yet. Press Start first.'
    return sendState()
  end
  rebuildEverything()
  statusError = false
  status = 'Rebuilt ' .. tostring(#spawned + #ringObjects) .. ' ' .. objectNoun() .. ' with current settings.'
  return sendState()
end

function M.clear()
  clearAll()
  rigCandidates = {}
  rigAttached = {}
  rigHints = {}
  statusError = false
  status = 'Generated objects, rings and saved drives cleared.'
  return sendState()
end

function M.placeRings()
  local veh, id = currentVehicle()
  local pos = veh and vehiclePosition(veh, id)
  if not pos then
    statusError = true
    status = 'Enter a vehicle to place rings ahead of it.'
    return sendState()
  end
  local p = vehiclePathPoint(veh, pos, id)
  if #ringObjects >= RING_MAX_TOTAL then
    statusError = true
    status = 'Ring limit reached (' .. tostring(RING_MAX_TOTAL) .. '). Clear rings first.'
    return sendState()
  end
  local set = {x = p.x, y = p.y, z = p.z, fx = p.fx, fy = p.fy, halfLength = p.carHalfLength}
  ringSets[#ringSets + 1] = set
  ensureMaterials()
  local group = objectGroup()
  local before = #ringObjects
  for _, frame in ipairs(aheadRingFrames(set)) do spawnRing(frame, group) end
  reloadCollision()
  local created = #ringObjects - before
  statusError = created == 0
  status = created > 0 and string.format('Placed %d rings ahead: %.1f m opening, %.0f m apart.',
    created, SETTINGS.ringSize, SETTINGS.ringGap) or 'No rings could be created.'
  return sendState()
end

function M.clearRings()
  ringRebuildAt = nil
  local hadPathRings = SETTINGS.rings
  ringSets = {}
  SETTINGS.rings = false
  if hadPathRings and #savedPaths > 0 and not recording then
    rebuildEverything()   -- gives the marker gaps back to the lines
  else
    removeRings()
    reloadCollision()
  end
  statusError = false
  status = 'All rings removed. Track markers and gates stay.'
  return sendState()
end

-- Panel actions: automatic detection is the default; a World Editor selection
-- can be registered explicitly as a fallback (or to force a stubborn trailer).
function M.useSelectedVehicle()
  local entries = editorSelectionEntries()
  if #entries == 0 then
    statusError = true
    status = 'No object selected. Select the trailer in World Editor, then press "Use selected trailer".'
    return sendState()
  end
  local frame = playerFrame()
  local added, rejected, already = 0, 0, 0
  for _, entry in ipairs(entries) do
    local object, selectionId = sceneObjectFromSelection(entry)
    -- A World Editor-glued trailer can be a vehicle OR a prop; accept either,
    -- but never one of our own cones and never the player car itself.
    if not object or isGeneratedMarker(object) or (frame and object == frame.veh) then
      rejected = rejected + 1
    else
      local id = objectVehicleId(object, selectionId)
      if not id then
        rejected = rejected + 1
      else
        local name = objectDisplayName(object)
        if rigManual[id] then already = already + 1 else added = added + 1 end
        rigManual[id] = {name = name ~= '' and name or ('Trailer ' .. id),
          source = 'World Editor', object = object, simId = selectionId}
        -- Size the corridor from the ACTUAL selected object right now and apply
        -- it to existing saved drives too, without recording anything again.
        local pad = rigPadFor(object, id, frame)
        if pad and pad > (tonumber(SETTINGS.rigPad) or 0) then SETTINGS.rigPad = pad end
      end
    end
  end
  if added + already == 0 then
    statusError = true
    status = string.format('Asnjë objekt i përshtatshëm (%d refuzuar). Selekto rimorkion, jo një kon të këtij mod-i.', rejected)
    return sendState()
  end
  resetRigObserver()
  rigObserver.done = true   -- manual sizing already rebuilt; no duplicate rebuild
  M.rebuild()
  statusError = false
  status = string.format('Rimorkio u regjistrua (%d shtuar, %d tashmë, %d refuzuar). Korridori u rindërtua: %.2f m shtesë për secilën anë.',
    added, already, rejected, tonumber(SETTINGS.rigPad) or 0)
  return sendState()
end

function M.unregisterSelectedVehicle()
  local entries = editorSelectionEntries()
  if #entries == 0 then
    statusError = true
    status = 'No object selected in World Editor. Use the list x or "Remove all".'
    return sendState()
  end
  local removed = 0
  for _, entry in ipairs(entries) do
    local object, selectionId = sceneObjectFromSelection(entry)
    local id = objectVehicleId(object, selectionId)
    for _, candidate in ipairs({id, selectionId}) do
      if candidate and rigManual[candidate] then
        rigManual[candidate] = nil
        removed = removed + 1
        break
      end
    end
  end
  statusError = removed == 0
  status = removed > 0
    and string.format('Unregistered %d vehicle(s). Only the car is computed now.', removed)
    or 'No registered vehicle matches the selection. Use the list x or "Remove all".'
  return sendState()
end

function M.unregisterVehicle(id)
  local normalized = normalizeObjectId(id)
  if not normalized then return sendState() end
  local removed = false
  if rigManual[normalized] then rigManual[normalized] = nil; removed = true end
  if rigAttached[normalized] then rigAttached[normalized] = nil; removed = true end
  if rigCoupler[normalized] then rigCoupler[normalized] = nil; removed = true end
  if removed then
    statusError = false
    status = 'Vehicle removed from the rig. Only the car is computed now.'
    resetRigObserver()
  end
  return sendState()
end

function M.clearSelectedVehicles()
  local count = 0
  for _ in pairs(rigManual) do count = count + 1 end
  for _ in pairs(rigAttached) do count = count + 1 end
  for _ in pairs(rigCoupler) do count = count + 1 end
  rigManual, rigAttached, rigCoupler, rigCandidates = {}, {}, {}, {}
  resetRigObserver()
  statusError = false
  status = count > 0
    and string.format('Removed %d attached vehicle(s). Only the car is computed now.', count)
    or 'No attached vehicles registered.'
  return sendState()
end

-- A normal coupler/hitch still counts, without needing an L key or a hook event
-- for World Editor-parented trailers (those are detected by their fixed pose).
function M.onCouplerAttached(objId1, objId2)
  local a, b = normalizeObjectId(objId1), normalizeObjectId(objId2)
  if a then rigCoupler[a] = true end
  if b then rigCoupler[b] = true end
end

function M.onCouplerDetached(objId1, objId2)
  local a, b = normalizeObjectId(objId1), normalizeObjectId(objId2)
  if a then rigCoupler[a] = nil end
  if b then rigCoupler[b] = nil end
end

local function normalizeSetting(key, value)
  local number = tonumber(value)
  if key == 'mesh' then
    if value == 'tire' or value == 'tireStack' then return 'tireStack' end
    -- Removed v0.9.2 road-work props safely fall back to the retained traffic cone.
    if value == 'barrel' or value == 'bollard' or value == 'barrier'
      or value == 'arrowBoard' or value == 'beacon' then return 'cone' end
    return MESH_DIMENSIONS[value] and value or 'cone'
  end
  if key == 'tireColors' then return value == 'rwb' and 'rwb' or 'rw' end
  if key == 'spacing' then return clamp(number or SETTINGS.spacing, 0.5, 10.0) end
  if key == 'gap' then return clamp(number or SETTINGS.gap, 0.0, 3.0) end
  if key == 'scale' then return clamp(number or SETTINGS.scale, 0.5, 2.0) end
  if key == 'groundOffset' then return clamp(number or SETTINGS.groundOffset, -2.0, 1.0) end
  if key == 'maxCones' then return math.floor(clamp(number or SETTINGS.maxCones, 100, 4000)) end
  if key == 'ringCount' then return math.floor(clamp(number or SETTINGS.ringCount, 1, 50) + 0.5) end
  if key == 'ringSize' then return clamp(number or SETTINGS.ringSize, 3.0, 30.0) end
  if key == 'ringGap' then return clamp(number or SETTINGS.ringGap, 2.0, 100.0) end
  if key == 'ringLift' then return clamp(number or SETTINGS.ringLift, 0.0, 10.0) end
  if key == 'rigMargin' then return clamp(number or SETTINGS.rigMargin, 0.0, 2.0) end
  if key == 'rigPad' then return clamp(number or SETTINGS.rigPad, 0.0, 4.0) end
  if key == 'smooth' or key == 'keepBuilds' or key == 'collision' or key == 'driftWidth'
    or key == 'gates' or key == 'rings' or key == 'ringFollowAir' or key == 'rigAware' then
    return truthy(value)
  end
  return nil
end

function M.setSetting(key, value)
  local normalized = normalizeSetting(key, value)
  if normalized == nil then return sendState() end
  local changed = SETTINGS[key] ~= normalized
  SETTINGS[key] = normalized
  local idle = not recording
  if key == 'mesh' or key == 'tireColors' then
    -- One click on a mesh / colour button updates saved drives right away.
    if changed and idle and #savedPaths > 0 and (key == 'mesh' or SETTINGS.mesh == 'tireStack') then
      return M.rebuild()
    end
  elseif key == 'collision' then
    if idle and (#savedPaths > 0 or #ringSets > 0) then return M.rebuild() end
  elseif key == 'driftWidth' or key == 'smooth' or key == 'gates' or key == 'rings' or key == 'rigAware' then
    if idle and #savedPaths > 0 then return M.rebuild() end
    if key == 'rings' and normalized then
      statusError = false
      status = 'Rings ON: they follow your next drive and can float with airborne sections.'
    end
  elseif key == 'ringCount' or key == 'ringSize' or key == 'ringGap' or key == 'ringLift'
    or key == 'ringFollowAir' then
    if changed then scheduleRings() end
  elseif key == 'gap' or key == 'spacing' or key == 'rigMargin' or key == 'rigPad' then
    -- Dragging Gap / Spacing reshapes saved drives once the slider rests.
    if changed and idle and #savedPaths > 0 then pathRebuildAt = clockTotal + 0.35 end
  end
  return sendState()
end

function M.uiState() return sendState() end

-- Manual re-scan for a Node Grabber attachment. No World Editor, no hitch, no L.
-- Keeps existing registrations (so the corridor never gets narrower), resets the
-- motion trackers and re-measures the current live rig pose.
function M.redetectRig()
  rigCandidates = {}
  resetRigObserver()
  rigCandidatesCache.at, rigCandidatesCache.list = -1e9, nil
  if rigEntryCount() > 0 and (#savedPaths > 0 or #ringSets > 0) and not recording then
    rebuildEverything()
    statusError = false
    status = 'Rimorkio u ri-mat nga pozita aktuale (Node Grabber); vija u rindërtua.'
  else
    statusError = false
    status = 'Po kërkoj rimorkion që lëviz bashkë me makinën — lëvize 1–2 sekonda.'
  end
  return sendState()
end

function M.onUpdate(dtReal)
  local dt = tonumber(dtReal) or 0
  uiClock = uiClock + dt
  clockTotal = clockTotal + dt
  if pendingRestore then
    pendingRestore = false
    if not recording and (#savedPaths > 0 or #ringSets > 0) then
      rebuildEverything()
      statusError = false
      status = 'Restored ' .. tostring(#savedPaths) .. ' saved drive(s) after a Lua reload.'
      sendState()
    end
  end
  if ringRebuildAt and clockTotal >= ringRebuildAt then
    ringRebuildAt = nil
    applyRingSettings()
    sendState()
  end
  if pathRebuildAt and clockTotal >= pathRebuildAt then
    pathRebuildAt = nil
    if not recording and #savedPaths > 0 then
      M.rebuild()
      status = string.format('Rebuilt: gap %.2f m, spacing %.1f m.', SETTINGS.gap, SETTINGS.spacing)
      sendState()
    end
  end
  if recording then
    local veh, id = currentVehicle()
    if veh and id then
      if activeVehicleId ~= id then
        activeVehicleId = id
        activeVehicleName = vehicleName(veh, id)
        points = {}
        status = 'Vehicle changed. Recording restarted for ' .. activeVehicleName .. '.'
      end
      local pos = vehiclePosition(veh, id)
      if pos then
        local p = vehiclePathPoint(veh, pos, id)
        local last = points[#points]
        local record = not last
        if last then
          local dx, dy = p.x - last.x, p.y - last.y
          record = dx * dx + dy * dy >= 0.75 * 0.75
        end
        -- Rig detection runs ONLY when a path point is actually recorded, never
        -- on idle frames: no per-frame vehicle or cone enumeration.
        if record then
          sampleRig(id, pos, p)
          points[#points + 1] = p
        end
      end
    end
  end
  -- Replay/idle: old drives have no rig data. Detect the attached trailer while
  -- the replay moves both vehicles, then rebuild once. Never runs per frame.
  if SETTINGS.rigAware and not recording and not rigObserver.done
      and rigEntryCount() == 0 and #savedPaths > 0
      and clockTotal - rigObserver.lastAt >= RIG_OBSERVE_INTERVAL then
    rigObserver.lastAt = clockTotal
    observeRig()
  end
  if uiClock >= 0.25 then
    uiClock = 0
    sendState()
  end
end

-- Lua reload support: keep settings, saved drives and ring sets; the objects of the
-- old VM are swept from the group and rebuilt on the next update.
local function validPoint(p)
  return type(p) == 'table' and type(p.x) == 'number' and type(p.y) == 'number' and type(p.z) == 'number'
end

local function restoreState(data)
  if restored or type(data) ~= 'table' then return end
  restored = true
  if type(data.settings) == 'table' then
    for key, value in pairs(data.settings) do
      if SETTINGS[key] ~= nil then
        local normalized = normalizeSetting(key, value)
        if normalized ~= nil then SETTINGS[key] = normalized end
      end
    end
  end
  savedPaths = {}
  for _, path in ipairs(type(data.savedPaths) == 'table' and data.savedPaths or {}) do
    if type(path) == 'table' and #path >= 2 then
      local ok = true
      for _, p in ipairs(path) do if not validPoint(p) then ok = false break end end
      if ok then savedPaths[#savedPaths + 1] = copyPoints(path) end
    end
  end
  ringSets = {}
  for _, set in ipairs(type(data.ringSets) == 'table' and data.ringSets or {}) do
    if validPoint(set) and type(set.fx) == 'number' and type(set.fy) == 'number' then
      ringSets[#ringSets + 1] = {x = set.x, y = set.y, z = set.z, fx = set.fx, fy = set.fy,
        halfLength = tonumber(set.halfLength) or 2.4}
    end
  end
  pendingRestore = #savedPaths > 0 or #ringSets > 0
end

function M.onSerialize()
  local settings = {}
  for k, v in pairs(SETTINGS) do settings[k] = v end
  return {settings = settings, savedPaths = savedPaths, ringSets = ringSets}
end

function M.onDeserialized(data)
  restoreState(data)
end

function M.onExtensionLoaded(data)
  -- Session-scoped: never restore stale vehicle IDs from an earlier mission.
  rigCandidates, rigAttached, rigManual, rigCoupler, rigHints = {}, {}, {}, {}, {}
  resetRigObserver()
  sweepGroup()
  reloadCollision()
  status = 'Ready. Press Start and drive.'
  restoreState(data)
  sendState()
  return true
end

function M.onClientEndMission()
  materialsLoaded = false
  rigCandidates, rigAttached, rigManual, rigCoupler = {}, {}, {}, {}
  resetRigObserver()
  clearAll()
end

function M.onExtensionUnloaded()
  rigCandidates, rigAttached, rigManual, rigCoupler = {}, {}, {}, {}
  resetRigObserver()
  clearAll()
end

return M
