DRIFTSKETCH 0.9.26 — NODE GRABBER (CTRL + LMB → MMB)
=====================================================
Bazuar te 0.9.4. S'ka rrëzim, s'ka numra/counter, s'ka HUD, s'ka tingull, s'ka
automjet JBeam për kon. Konet janë TSStatic të lehta; "Solid / car damage" OFF.

SI E LIDH TI RIMORKION (DHE PSE KJO KA RËNDËSI)
-----------------------------------------------
Ti e ngjit me **CTRL + klik majtë** mbi një nyje → e tërheq mbi nyjen e makinës
→ **mesi i mausit** (Node Grabber). Kjo bashkon dy nyje me **fizikë të butë**:

  * NUK është coupler/hitch → eventi `onCouplerAttached` NUK ndizet, tastin `L`
    nuk e përdor.
  * NUK është objekt i World Editor → selektimi atje nuk të nevojitet.
  * Pozita relative **lëkundet me metra** dhe rimorkioja **rrotullohet me kokën
    e vet**, sidomos në drift me 80–100 km/h.

BeamNG nuk ofron asnjë API publike që t'i listojë këto lidhje nyje-në-nyjë
(`be.nodeGrabber` ka vetëm `fixCurrentNode()` / `clearVehicleFixedNodes()`).
I vetmi sinjal i besueshëm është që rimorkioja **udhëton bashkë me makinën**.

ÇFARË ISHTE GABIM DERI TANI
---------------------------
0.9.24: një numër gjerësie te stacioni i MAKINËS, i shtuar simetrikisht nga
të dyja anët → rrugë shumë e gjerë, e megjithatë konet nën rimorkio.

0.9.25: vija e qendrës së rimorkios + pastrim vetëm nga ana e saj — gjeometria u
rregullua, POR zbulimi kërkonte ende **pozitë relative të qëndrueshme**
(1.5 m / ~32°). Me Node Grabber ajo pozitë nuk ekziston: rimorkioja lëkundet,
prandaj mod-i ose s'e zbulonte fare, ose e humbiste gjatë drift-it. Në testin
tonë, i njëjti skenar Node Grabber me 0.9.25 lë **17 konë brenda rimorkios**.

ÇFARË NDRYSHOI TE 0.9.26
-------------------------
1. **Zbulim me co-motion, jo me pozitë të fiksuar.** Për çdo objekt pranë,
   mod-i krahason zhvendosjen e makinës me zhvendosjen e objektit: nëse ai
   udhëton me makinën (drejtim përafërsisht i njëjtë, distancë e krahasueshme),
   është pjesë e rig-ut — edhe kur lëkundet 2–3 m dhe rrotullohet. Një makinë e
   parkuar a një makinë që kalon pranë nuk e kalon testin. Asnjë kuk, asnjë `L`,
   asnjë World Editor.
2. **Pa humbje gjatë drift-it.** Regjistrimi i gjetur mbahet për gjithë sesionin
   dhe një mostër e keqe nuk e fshin (integrator me rrjedhje).
3. **Zarf lëkundjeje për drive-t e vjetra.** Kur një drive i ruajtur nga
   0.9.4 / 0.9.23 / 0.9.24 / 0.9.25 nuk ka vijë rimorkioje, `buildRigProfile`
   e sintetizon nga pozita AKTUALE e rimorkios, por në vend të një drejtkëndëshi
   të vetëm vendos **3 drejtkëndësha të rrotulluar** (±20°) pak më të mëdhenj.
   Kështu mbulohet edhe lëkundja e lidhjes — gjithmonë VETËM në anën e
   rimorkios, ana tjetër mbetet e ngushtë.
4. **↻ RIPROVË ZBULIMIN / RE-MAT RIMORKION** — buton i ri në krye të seksionit.
   Ri-mat pozitën aktuale dhe rindërton pa pasur nevojë të zgjedhësh asgjë në
   World Editor. Butoni i World Editor mbeti, por tani është shënuar **Opsionale**
   dhe i duhet vetëm prop-ave TSStatic.
5. Vija e qendrës së rimorkios (qendra në botë, përmasat, koka e saj), pastrimi
   i njëanshëm, rreshti i finish-it prapa pjesës së pasme, `Hapësira minimale`
   1.0 m (dysheme, vendos 0 për vija sa më të ngushta) dhe treguesi
   **"✓ N pika të vijës së rimorkios"** mbeten si te 0.9.25.

SI TA PËRDORËSH
----------------
1. Çaktivizo çdo ZIP tjetër DriftSketch → vendos vetëm këtë te Mods, pa e nxjerrë
   → **rindis BeamNG.drive**.
2. Ngjite rimorkion si zakonisht: **CTRL + klik majtë → mesi i mausit**. Mos hap
   World Editor, mos shtyp `L`.
3. Me drive-n e vjetër: shtyp **↻ RIPROVË ZBULIMIN** ose **REBUILD WITH CURRENT
   SETTINGS** (ose thjesht lëvize makinën 1–2 s në replay). Duhet të shfaqet
   "✓ N pika të vijës së rimorkios" dhe `rimorkio #... · Auto`.
4. Konet do të jenë të ngushta nga ana pa rimorkio dhe të hapura vetëm aty ku
   ajo kalon. Nëse ende prek: rrit **Margjinë sigurie** (vetëm rreth rimorkios)
   ose **Hapësira minimale** (të dyja anët). Nëse vijat duken larg: ul të dyja.
5. Për matjen më të saktë, regjistro një run të ri me FILLO → vozit → NDALO &
   NDËRTO: çdo pikë ruan pozitën e vërtetë të rimorkios, jo një zarf.

SHËNIM PËR CILËSIMET E TUA
---------------------------
Ke Gap 0 m, Spacing 0.5 m, Drift widen ON, Performance cap 2000. Me vijën e re
ana pa rimorkio mbetet ~1.2–1.5 m nga qendra (si te 0.9.4), ana e rimorkios
hapet vetëm në kthesat ku ajo pret. Rreshti i finish-it merr disa objekte më
shumë; nëse vijat anësore duken më të rralla, rrit pak Performance cap
(p.sh. 2500). Asnjë fizikë apo animacion shtesë.

PERFORMANCA DHE SIGURIA
-----------------------
- Llogaritja bëhet një herë në ndërtim: për çdo stacion skanohen stacionet
  brenda 10 m dhe drejtkëndëshet e rimorkios. Aritmetikë e thjeshtë, pa objekte
  të reja, pa fizikë, pa punë për kornizë.
- Lista e kandidatëve memorizohet **1.5 s** dhe kufizohet në **32 objekte**:
  një run me 41 pika e lexon 2 herë, jo në çdo pikë. Zbulimi në replay është
  3 herë/sek, vetëm brenda 12 m, vetëm derisa të gjejë rimorkion (maks. 90 s),
  vetëm kur makina lëviz. Gjatë FILLO: vetëm në pikat e rrugës. Konet nuk
  skanohen kurrë.
- Konet TSStatic me instance rendering, collision=None kur "Solid" është OFF.
  As rrëzim, as numërues/HUD, as WAV/tingull, as JBeam-per-kon nuk kthehet.

MIGRIMI
-------
Cilësimet, drive-t e ruajtura dhe rrathët nga 0.9.4 / 0.9.23 / 0.9.24 /
0.9.25 ruhen. Drive-t pa `rigPoses` marrin vijën e sintetizuar me zarf
lëkundjeje. Çelësat e hequr (topple, coneCollision, hud*, sound*) injorohen.

HISTORIA
--------
0.9.4  i pastër, konet TSStatic, pa rrëzim/numra.
0.9.5  konet si automjete JBeam → rënie FPS (NUK rikthehet).
0.9.8  counter/numrat. 0.9.17 collision fizik (FPS 2–3).
0.9.22 kthim i pastër. 0.9.23 zbulim vetëm gjatë regjistrimit.
0.9.24 gjerësi simetrike në ndërtim (rrugë e gjerë, prap prek).
0.9.25 vija e qendrës + pastrim njëanësor, por zbulim me pozitë të fiksuar.
0.9.26 zbulim me co-motion për Node Grabber + zarf lëkundjeje.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
