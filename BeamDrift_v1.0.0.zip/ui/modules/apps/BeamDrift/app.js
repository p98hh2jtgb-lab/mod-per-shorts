angular.module('beamng.apps')
.directive('beamDriftPanel', ['$window', '$timeout', function($window, $timeout) {
  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/BeamDrift/app.html',
    link: function(scope) {
      scope.version = '1.0.0';
      scope.state = {
        enabled: false, hasVehicle: false, preset: 'formula', presetLabel: 'FORMULA', status: 'Loading BeamDrift…',
        settings: {targetAngle:45,maxAngle:62,assistStrength:1.0,antiSpinStrength:3.0,
          transitionStrength:2.2,engageAngle:32,minSpeedKmh:22,responseCap:3.5},
        presets: [
          {key:'street',label:'STREET'}, {key:'formula',label:'FORMULA'},
          {key:'tandem',label:'TANDEM'}, {key:'highAngle',label:'HIGH ANGLE'}
        ]
      };
      scope.advancedOpen = false;
      var timers = {};
      var NUMERIC = ['targetAngle','maxAngle','assistStrength','antiSpinStrength',
        'transitionStrength','engageAngle','minSpeedKmh','responseCap'];

      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      scope.toggle = function() { lua('extensions.beamDrift.toggle()'); };
      scope.applyPreset = function(key) {
        if (['street','formula','tandem','highAngle'].indexOf(key) < 0) return;
        lua('extensions.beamDrift.setPreset(' + JSON.stringify(key) + ')');
      };
      scope.reset = function() { lua('extensions.beamDrift.reset()'); };
      scope.pushSetting = function(key) {
        if (NUMERIC.indexOf(key) < 0) return;
        var value = Number(scope.state.settings[key]);
        if (!isFinite(value)) return;
        if (timers[key]) $timeout.cancel(timers[key]);
        timers[key] = $timeout(function() {
          lua('extensions.beamDrift.setSetting(' + JSON.stringify(key) + ',' + JSON.stringify(value) + ')');
          timers[key] = null;
        }, 90);
      };
      scope.number = function(value, decimals) {
        var n = Number(value);
        return (isFinite(n) ? n : 0).toFixed(decimals || 0);
      };
      scope.strengthWord = function(value) {
        var n = Number(value) || 0;
        return n < 0.7 ? 'SOFT' : (n < 1.35 ? 'BALANCED' : 'STRONG');
      };
      scope.isPreset = function(key) { return scope.state.preset === key; };

      var offState = scope.$on('beamDrift.state', function(_event, data) {
        if (!data) return;
        scope.$applyAsync(function() {
          scope.state.enabled = !!data.enabled;
          scope.state.hasVehicle = !!data.hasVehicle;
          scope.state.preset = data.preset || 'custom';
          scope.state.presetLabel = data.presetLabel || (scope.state.preset === 'custom' ? 'CUSTOM' : String(scope.state.preset).toUpperCase());
          scope.state.status = data.status || 'Ready when you are.';
          if (data.settings) scope.state.settings = data.settings;
          if (data.presets) scope.state.presets = data.presets;
        });
      });
      scope.$on('$destroy', function() {
        if (offState) offState();
        Object.keys(timers).forEach(function(key) { if (timers[key]) $timeout.cancel(timers[key]); });
      });
      lua('extensions.beamDrift.uiState()');
    }
  };
}]);
