-- BeamDrift 1.0.0 - configurable vehicle-side drift assist.
-- Applies a bounded yaw torque across the vehicle nodes; it does not edit JBeam.
local M = {}

local DEFAULTS = {
  targetAngle = 45,
  maxAngle = 62,
  assistStrength = 1.0,
  antiSpinStrength = 3.0,
  transitionStrength = 2.2,
  engageAngle = 32,
  minSpeedKmh = 22,
  responseCap = 3.5
}
local LIMITS = {
  targetAngle = {20, 68},
  maxAngle = {35, 78},
  assistStrength = {0, 2.5},
  antiSpinStrength = {0, 6},
  transitionStrength = {0, 4},
  engageAngle = {8, 48},
  minSpeedKmh = {5, 80},
  responseCap = {0.5, 6}
}
local PHYS_HZ = 2000
local config = {}
for key, value in pairs(DEFAULTS) do config[key] = value end
local enabled = false
local previousForward = nil
local alphaSmooth = 0
local latch, holdAngle, transition = 0, 45, 0
local transitionTime, oppositeSteerTime, noThrottleTime = 0, 0, 0

local function clamp(value, low, high)
  return math.max(low, math.min(high, value))
end

local function atan2(y, x)
  if math.atan2 then return math.atan2(y, x) end
  if x > 0 then return math.atan(y / x) end
  if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
  if x < 0 and y < 0 then return math.atan(y / x) - math.pi end
  if x == 0 and y > 0 then return math.pi * 0.5 end
  if x == 0 and y < 0 then return -math.pi * 0.5 end
  return 0
end

local function normalized(values)
  local out = {}
  for key, bounds in pairs(LIMITS) do
    local value = tonumber(values and values[key])
    if not value or value ~= value or value == math.huge or value == -math.huge then value = DEFAULTS[key] end
    out[key] = clamp(value, bounds[1], bounds[2])
  end
  out.maxAngle = math.max(out.maxAngle, out.targetAngle + 4)
  if out.maxAngle > LIMITS.maxAngle[2] then
    out.maxAngle = LIMITS.maxAngle[2]
    out.targetAngle = math.min(out.targetAngle, out.maxAngle - 4)
  end
  out.engageAngle = math.max(LIMITS.engageAngle[1], math.min(out.engageAngle, out.targetAngle - 3))
  return out
end

local function resetControl()
  previousForward = nil
  alphaSmooth = 0
  latch, holdAngle, transition = 0, config.targetAngle, 0
  transitionTime, oppositeSteerTime, noThrottleTime = 0, 0, 0
end

function M.setConfig(values)
  config = normalized(values)
  if latch ~= 0 then holdAngle = config.targetAngle end
end

function M.setEnabled(value)
  enabled = value == true or value == 1 or value == 'true'
  resetControl()
end

function M.getState()
  return {enabled = enabled, config = config}
end

local function applyYaw(alphaRight, dt)
  if not obj or not v or not v.data or not v.data.nodes then return end
  local up = obj:getDirectionVectorUp()
  local alphaCCW = -alphaRight
  local compensation = clamp(dt * PHYS_HZ, 1, 20)
  local sx, sy, sz, totalMass = 0, 0, 0, 0
  for cid, node in pairs(v.data.nodes) do
    local mass = node.nodeWeight or 0
    if mass > 0 then
      local point = obj:getNodePosition(cid)
      sx = sx + point.x * mass
      sy = sy + point.y * mass
      sz = sz + point.z * mass
      totalMass = totalMass + mass
    end
  end
  if totalMass <= 0 then return end
  local center = vec3(sx / totalMass, sy / totalMass, sz / totalMass)
  for cid, node in pairs(v.data.nodes) do
    local mass = node.nodeWeight or 0
    if mass > 0 then
      local offset = obj:getNodePosition(cid) - center
      local force = up:cross(offset) * (mass * alphaCCW * compensation)
      obj:applyForceVector(cid, force)
    end
  end
end

function M.updateGFX(dt)
  if not enabled or not dt or dt <= 0 or not obj then return end
  local velocity = obj:getVelocity()
  local forward = obj:getDirectionVector()
  local up = obj:getDirectionVectorUp()
  local right = forward:cross(up)
  local speed = velocity:length()
  local speedKmh = speed * 3.6

  local yawRate = 0
  if previousForward then yawRate = -(previousForward:cross(forward)):dot(up) / dt end
  previousForward = vec3(forward.x, forward.y, forward.z)

  local target = 0
  local minimumAssistSpeed = math.max(6, config.minSpeedKmh * 0.42)
  if speedKmh >= minimumAssistSpeed then
    local forwardSpeed = velocity:dot(forward)
    local lateralSpeed = velocity:dot(right)
    local angle = math.deg(atan2(lateralSpeed, forwardSpeed))
    local absoluteAngle = math.abs(angle)
    local angleSign = angle >= 0 and 1 or -1
    local throttle = electrics and electrics.values and electrics.values.throttle or 0
    local handbrake = electrics and electrics.values and electrics.values.parkingbrake or 0
    local steering = (electrics and electrics.values and electrics.values.steering_input or 0)
    local yawDirection, strength = 0, 0
    local spinning = (yawRate * angleSign) < -0.8 and absoluteAngle > 35
    local releaseSpeed = config.minSpeedKmh * 0.7

    if latch ~= 0 then
      if angleSign ~= latch or absoluteAngle < 12 or speedKmh < releaseSpeed or forwardSpeed <= 0 then
        latch = 0
      else
        -- Keep the requested angle live so the panel remains useful while driving.
        holdAngle = clamp(config.targetAngle, config.engageAngle + 2, config.maxAngle - 2)
        noThrottleTime = throttle < 0.1 and noThrottleTime + dt or 0
        if noThrottleTime > 0.8 then latch = 0 end
        oppositeSteerTime = steering * latch > 0.4 and oppositeSteerTime + dt or 0
        if oppositeSteerTime > 0.12 and latch ~= 0 then
          transition = steering > 0 and 1 or -1
          transitionTime, oppositeSteerTime, latch = 0, 0, 0
        end
      end
    elseif transition == 0 and absoluteAngle >= config.engageAngle and forwardSpeed > 0
      and speedKmh >= config.minSpeedKmh and throttle > 0.2 then
      latch = angleSign
      holdAngle = clamp(config.targetAngle, config.engageAngle + 2, config.maxAngle - 2)
      noThrottleTime, oppositeSteerTime = 0, 0
    end

    if absoluteAngle > config.maxAngle or (spinning and absoluteAngle > 35) then
      -- Anti-spin takes priority when the body is rotating away from the existing slide.
      transition = 0
      yawDirection = angleSign
      local overAngle = math.max(absoluteAngle - config.maxAngle, 0) / 20
      local rotationRate = clamp(math.abs(yawRate) / 3, 0, 1)
      strength = config.antiSpinStrength * clamp(0.4 + overAngle + rotationRate, 0.4, 1.5)
    elseif transition ~= 0 then
      transitionTime = transitionTime + dt
      if (angleSign == -transition and absoluteAngle > 25) or transitionTime > 1.5 or forwardSpeed <= 0 then
        transition = 0
      else
        yawDirection = transition
        strength = config.transitionStrength * (0.6 + 0.4 * throttle)
      end
    elseif latch ~= 0 then
      local errorRatio = (holdAngle - absoluteAngle) / math.max(holdAngle, 1)
      yawDirection = -angleSign * (errorRatio > 0 and 1 or -1)
      strength = 1.2 * config.assistStrength * math.abs(errorRatio) * (0.6 + throttle)
    elseif speedKmh >= config.minSpeedKmh and forwardSpeed > 0
      and (handbrake > 0.3 or throttle > 0.3) and math.abs(steering) > 0.2
      and absoluteAngle < config.engageAngle then
      yawDirection = steering > 0 and 1 or -1
      strength = config.assistStrength * math.abs(steering) * (handbrake > 0.3 and 1.3 or 1)
    end
    target = clamp(yawDirection * strength * 0.8, -config.responseCap, config.responseCap)
  end

  -- Smooth the torque so switching the assist or changing a slider does not jolt the car.
  alphaSmooth = alphaSmooth + (target - alphaSmooth) * clamp(dt * 8, 0, 1)
  if math.abs(alphaSmooth) < 0.02 then return end
  applyYaw(alphaSmooth, dt)
end

function M.onVehicleReset()
  resetControl()
end

return M
