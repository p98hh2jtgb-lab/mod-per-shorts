DRIFTSKETCH 0.9.22 — KTHIM TE VERSIONI I PASTËR
=================================================
PA RRËZIM · PA NUMRA NË MES · PA FIZIKË · PA TINGULL · VETËM KONE

Ky version e kthen DriftSketch te sjellja që punonte më mirë: regjistron vijën
ku vozit, vendos vetëm traffic cones përgjatë saj dhe i lë aty për replay.
Konat janë statike, nuk rrëzohen, nuk kanë collision fizik dhe nuk ka asnjë
numërues/HUD/tekst në mes të ekranit. Asgjë nuk skanohet gjatë lojës, prandaj
FPS-i nuk bie kur u afrohesh konave.

PSE U BË KTHIMI
---------------
Me versionet 0.9.17–0.9.21, "Kontakt fizik me veturën" ON + "Rrëzohen kur
preken" ON ulte FPS-in në 2–3 te konat, dhe numrat/teksti në mes të ekranit nuk
dilnin mirë. Prandaj u hoqën KREJT:

  * rrëzimi/animacioni i konave (çfarëdo lloji: vizual apo fizik),
  * app-i "DriftSketch Counter" dhe numrat/etiketat HUD në mes,
  * NEON BADGE, OUTLINE, "Kartela si në foto", ngjyrat/outline/glow/hije,
  * tingulli WAV dhe përforcimi audio,
  * kontakti fizik / collision-i i mesh-it (nuk ka më as çelës për ta ndezur),
  * njohja e rimorkiove me coupler / World Editor (nuk nevojitet më, se s'ka rrëzim).

HISTORIA — KU FILLUAN KËTO
--------------------------
  0.9.4  Versioni i fundit "i pastër": as rrëzim, as numra, as counter. Kishte
         edhe goma, rrathë, porta, kerb dhe flamuj; konet ishin TSStatic pa
         collision. Ky ishte versioni që punonte perfekt.
  0.9.5  U hoqën të gjitha props-at, mbetën vetëm konet — por secili kon u bë
         automjet JBeam i veçantë. Shkaktoi kone të padukshme dhe rënie të FPS-it
         rreth 10. KJO MËNYRË NUK RIKTHET KURRË.
  0.9.6  Konet u kthyen në TSStatic pa collision, por u shtua rrëzimi vizual.
  0.9.8  U shtua counter live + app-i "DriftSketch Counter" (numrat në mes).
  0.9.17 U shtua kontakti fizik opsional (shkaku i FPS 2–3 me shumë kone).
  0.9.22 Kthim te sjellja e 0.9.4: vetëm kone statike TSStatic, pa rrëzim,
         pa numra, pa fizikë, pa tingull, pa JBeam për kon.

0.9.22 mban motorin e pistës së 0.9.4/0.9.7 (vija e lëmuar, korridori sipas
gjerësisë së makinës, zgjerimi lokal në drift, rreshti i finish-it, kufiri i
konave) dhe rregullimin e lehtë të 0.9.6: konet janë TSStatic me instance
rendering dhe collisionType=None. Pra: pamja dhe pistat si më parë, por zero
kosto shtesë.

Nëse do versionin e vjetër EKZAKT (0.9.4, me goma/rrathë/porta), ai ZIP është
në repo:
https://github.com/p98hh2jtgb-lab/mod-per-shorts/raw/c3c4c4570691de331143d240c996c598f55acf57/DriftSketch_v0.9.4.zip

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, ÇAKTIVIZOJI/FSHIJI të gjitha
   ZIP-at e vjetër të DriftSketch (0.9.1–0.9.21). Mos i mbaj dy aktive bashkë.
2. Kopjo DriftSketch_v0.9.22.zip aty PA E NXJERRË nga ZIP-i.
3. Nëse e ke shtuar app-in "DriftSketch Counter" në UI, HIQE nga UI Apps/Edit
   mode. Ky version nuk e përmban fare atë app; nuk ka më numra në ekran.
4. Aktivizo DriftSketch te Mod Manager dhe RINISE BeamNG.drive (që materialet
   dhe app-et e vjetra të mos mbeten në cache).
5. Shto panelin DriftSketch te App menu > Add App.

PËRDORIMI
---------
1. Rregullo Hapësira, Hapësira nga kerri, Lartësia rezervë dhe Kufirin total.
2. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
3. Hap replay-in normal të BeamNG; konat mbeten në skenë.
4. RINDËRTO PISTAT E RUAJTURA i rindërton drive-t me cilësimet aktuale.
   PASTRO KONAT & PISTAT heq konet dhe drive-t e krijuara nga DriftSketch.

CILËSIMET NË PANEL (vetëm këto)
-------------------------------
Hapësira (0.5–10 m), Hapësira nga kerri (0–3 m), Lartësia rezervë (-2–1 m),
Kufiri total i konave (100–4000, parazgjedhje 2000), Vijë e lëmuar, Ruaj
pistat, Zgjero në drift. Nuk ka asnjë çelës rrëzimi, fizike, HUD-i apo tingulli.

PERFORMANCA
-----------
Konat janë TSStatic me instance rendering, collision=None, pa automjet JBeam
për kon, pa raycast/scan gjatë lojës, pa audio, pa app shtesë counter-i.
Regjistrimi merr vetëm pozitën e makinës; ndërtimi i konave bëhet vetëm te
"Ndalo & Ndërto" / "Rindërto". Clear rifreskon edhe collision-world-in, që të
mos mbetet ndonjë kontakt i padukshëm nga një version i vjetër. Me shumë kone
FPS-i mund të ndryshojë nga vetë renderimi: provoje fillimisht me kufi më të
ulët dhe rrite gradualisht.

MIGRIMI I CILËSIMEVE
--------------------
Cilësimet e pistës nga 0.9.20/0.9.21 (hapësira, gap, lartësia, kufiri, vija e
lëmuar, ruaj pistat, drift width) dhe drive-t e ruajtura ruhen. Çelësat që u
hoqën (topple, coneCollision, hud*, sound*, ...) injorohen — nuk mund ta
rikthejnë rrëzimin apo numrat. Kufiri i konave nga versionet 0.9.6+ ruhet siç
ishte; vetëm save-et e 0.9.5-e-mëparshme me kufi <= 500 rivendosen te 2000.
Regjistrimet e rimorkiove nuk ekzistojnë më (s'ka rrëzim për t'i përdorur).

ÇFARË KA NDRYSHUAR NË 0.9.22
----------------------------
- U hoq plotësisht rrëzimi/animacioni i konave dhe çdo test kontakti me makinën,
  rimorkiot me coupler apo ato të zgjedhura në World Editor.
- U hoq app-i "DriftSketch Counter", numrat/etiketat në mes të ekranit, HUD-i,
  NEON BADGE/OUTLINE, "Kartela si në foto", tingulli dhe përforcimi audio.
- U hoq çelësi i kontaktit fizik dhe i gjithë kodi i collision-it të konave;
  konat janë gjithmonë collisionType=None.
- Nuk ka më skanim konash në onUpdate: zero punë për kornizë, FPS i qëndrueshëm.
- Path recording/build/rebuild/clear, kufiri 2000/4000, vija e lëmuar, drift
  width dhe ruajtja e pistave mbeten si te 0.9.4/0.9.7.
- Cilësimet dhe pistat e ruajtura migrohen nga 0.9.20/0.9.21; Clear rifreskon
  collision-world-in. Nuk ka JBeam për asnjë kon.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
