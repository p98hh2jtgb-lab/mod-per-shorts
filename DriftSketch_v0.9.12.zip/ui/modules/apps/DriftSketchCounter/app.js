angular.module('beamng.apps')
.directive('driftSketchCounter', ['$window', function($window) {
  var SOUND_URL = '/ui/modules/apps/DriftSketchCounter/cone-hit.wav';

  function localAudioPool() {
    if ($window.__driftSketchAudioPool) return $window.__driftSketchAudioPool;
    var AudioCtor = $window.Audio;
    if (!AudioCtor) return null;
    try {
      var pool = [];
      for (var i = 0; i < 6; i++) {
        var audio = new AudioCtor(SOUND_URL);
        audio.preload = 'auto';
        pool.push(audio);
      }
      $window.__driftSketchAudioPool = pool;
      $window.__driftSketchAudioIndex = 0;
      return pool;
    } catch (_err) { return null; }
  }

  function localAudioGain(audio) {
    var context = $window.__driftSketchAudioContext;
    if (!context || context.state !== 'running' || !context.createMediaElementSource || !context.createGain) return null;
    if (audio.__driftSketchGainNode) return audio.__driftSketchGainNode;
    var source = null;
    try {
      source = context.createMediaElementSource(audio);
      var gain = context.createGain();
      var compressor = context.createDynamicsCompressor ? context.createDynamicsCompressor() : null;
      source.connect(gain);
      if (compressor) {
        compressor.threshold.value = -3;
        compressor.knee.value = 4;
        compressor.ratio.value = 8;
        compressor.attack.value = 0.003;
        compressor.release.value = 0.08;
        gain.connect(compressor);
        compressor.connect(context.destination);
        audio.__driftSketchCompressor = compressor;
      } else gain.connect(context.destination);
      audio.__driftSketchGainNode = gain;
      audio.__driftSketchMediaSource = source;
      return gain;
    } catch (_err) {
      if (source) { try { source.connect(context.destination); } catch (_ignored) {} }
      return null;
    }
  }

  function playConeSound(data) {
    if (!data || !data.soundEnabled) return;
    if ($window.__driftSketchPlayHitSound) {
      $window.__driftSketchPlayHitSound(data);
      return;
    }
    var key = String(data.eventSession || '') + ':' + String(data.eventSerial || '');
    var seen = $window.__driftSketchPlayedHits || ($window.__driftSketchPlayedHits = {});
    if (seen[key]) return;
    seen[key] = true;
    var volume = Number(data.soundVolume);
    if (!isFinite(volume)) volume = 3;
    volume = Math.max(0, Math.min(5, volume));
    if (volume <= 0) return;
    var pool = localAudioPool();
    if (!pool || !pool.length) return;
    try {
      var index = $window.__driftSketchAudioIndex % pool.length;
      $window.__driftSketchAudioIndex = index + 1;
      var audio = pool[index];
      var gainNode = localAudioGain(audio);
      audio.volume = gainNode ? 1 : Math.min(1, volume);
      if (gainNode) gainNode.gain.value = volume;
      audio.muted = false;
      try { audio.currentTime = 0; } catch (_ignored) {}
      var playing = audio.play();
      if (playing && playing.catch) playing.catch(function() {});
    } catch (_err) {}
  }

  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/DriftSketchCounter/app.html',
    link: function(scope) {
      scope.state = {
        toppledCount: 0,
        displayTotal: 0,
        settings: {hudLabel:'CONES DOWN', hudSize:1.3, soundEnabled:true, soundVolume:3.0}
      };
      scope.pulse = false;
      scope.formatCount = function(value) {
        var number = Number(value);
        return isFinite(number) ? String(Math.max(0, Math.round(number))) : '0';
      };
      scope.numberStyle = function() {
        var size = Math.max(0.5, Math.min(3.0, Number(scope.state.settings.hudSize) || 1.3));
        return {fontSize:(104 * size) + 'px'};
      };
      scope.labelStyle = function() {
        var size = Math.max(0.5, Math.min(3.0, Number(scope.state.settings.hudSize) || 1.3));
        return {fontSize:(16 * size) + 'px'};
      };
      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      function pulse() {
        scope.$applyAsync(function() { scope.pulse = true; });
        $window.setTimeout(function() {
          scope.$applyAsync(function() { scope.pulse = false; });
        }, 140);
      }
      function playSerialRange(data, first, last) {
        if (!data || !data.settings) return;
        for (var serial = first; serial <= last; serial++) {
          playConeSound({eventSession:data.eventSession, eventSerial:serial,
            soundEnabled:!!data.settings.soundEnabled, soundVolume:data.settings.soundVolume});
        }
      }

      var lastEventSession = null;
      var lastEventSerial = null;
      var offState = scope.$on('driftSketch.state', function(_event, data) {
        if (!data) return;
        var eventSession = String(data.eventSession || '');
        var eventSerial = Number(data.toppleEventSerial) || 0;
        if (lastEventSession !== eventSession || lastEventSerial === null) {
          lastEventSession = eventSession;
          lastEventSerial = eventSerial;
        } else {
          if (eventSerial > lastEventSerial) {
            playSerialRange(data, lastEventSerial + 1, eventSerial);
            pulse();
          }
          lastEventSerial = eventSerial;
        }
        scope.$applyAsync(function() { scope.state = data; });
      });
      var offHit = scope.$on('driftSketch.hit', function(_event, data) {
        if (!data) return;
        playConeSound(data);
        pulse();
      });
      scope.$on('$destroy', function() {
        if (offState) offState();
        if (offHit) offHit();
      });
      lua('extensions.driftSketch.uiState()');
    }
  };
}]);
