-- BeamDrift 1.4.0 - game-engine controller and settings bridge.
-- The vehicle-side controller is kept separate so the UI never touches physics directly.
local M = {}

local VERSION = '1.4.0'
local SETTINGS_FILE = 'settings/beamDrift.json'
local DEFAULTS = {
  targetAngle = 45,
  maxAngle = 62,
  assistStrength = 1.0,
  antiSpinStrength = 3.0,
  transitionStrength = 2.2,
  engageAngle = 32,
  minSpeedKmh = 22,
  responseCap = 3.5,
  slideForce = 2.5,
  directionPunch = 5.0
}
local LIMITS = {
  targetAngle = {20, 68},
  maxAngle = {35, 78},
  assistStrength = {0, 2.5},
  antiSpinStrength = {0, 6},
  transitionStrength = {0, 4},
  engageAngle = {8, 48},
  minSpeedKmh = {5, 80},
  responseCap = {0.5, 6},
  slideForce = {0, 8},
  directionPunch = {0, 10}
}
local CONFIG_ORDER = {
  'targetAngle', 'maxAngle', 'assistStrength', 'antiSpinStrength',
  'transitionStrength', 'engageAngle', 'minSpeedKmh', 'responseCap',
  'slideForce', 'directionPunch'
}

local PRESETS = {
  street = {
    label = 'STREET',
    values = {targetAngle=34, maxAngle=54, assistStrength=0.72, antiSpinStrength=3.8,
      transitionStrength=1.25, engageAngle=24, minSpeedKmh=18, responseCap=2.6}
  },
  formula = {
    label = 'FORMULA',
    values = {targetAngle=45, maxAngle=62, assistStrength=1.0, antiSpinStrength=3.0,
      transitionStrength=2.2, engageAngle=32, minSpeedKmh=22, responseCap=3.5}
  },
  tandem = {
    label = 'TANDEM',
    values = {targetAngle=40, maxAngle=58, assistStrength=0.82, antiSpinStrength=2.8,
      transitionStrength=1.55, engageAngle=27, minSpeedKmh=20, responseCap=3.0}
  },
  highAngle = {
    label = 'HIGH ANGLE',
    values = {targetAngle=56, maxAngle=72, assistStrength=1.12, antiSpinStrength=3.2,
      transitionStrength=2.55, engageAngle=36, minSpeedKmh=27, responseCap=4.25}
  }
}

local settings = {}
for key, value in pairs(DEFAULTS) do settings[key] = value end
local enabled = false
local quickShiftEnabled = false
local iceSlideEnabled = false
local preset = 'formula'
local status = 'Ready when you are.'
local uiClock = 0
local activeVehicleId = nil

local function clamp(value, low, high)
  return math.max(low, math.min(high, value))
end

local function copyValues(source)
  local out = {}
  for key, value in pairs(source or {}) do out[key] = value end
  return out
end

local function normalized(values)
  local out = {}
  for key, bounds in pairs(LIMITS) do
    local value = tonumber(values and values[key])
    if not value or value ~= value or value == math.huge or value == -math.huge then
      value = DEFAULTS[key]
    end
    out[key] = clamp(value, bounds[1], bounds[2])
  end
  -- Keep controls coherent even when sliders are moved in either order.
  out.maxAngle = math.max(out.maxAngle, out.targetAngle + 4)
  if out.maxAngle > LIMITS.maxAngle[2] then
    out.maxAngle = LIMITS.maxAngle[2]
    out.targetAngle = math.min(out.targetAngle, out.maxAngle - 4)
  end
  out.engageAngle = math.min(out.engageAngle, out.targetAngle - 3)
  out.engageAngle = math.max(LIMITS.engageAngle[1], out.engageAngle)
  return out
end

local function persist()
  if not jsonWriteFile then return false end
  local data = {version = VERSION, settings = settings, preset = preset, quickShiftEnabled = quickShiftEnabled, iceSlideEnabled = iceSlideEnabled}
  local ok = pcall(jsonWriteFile, SETTINGS_FILE, data, true)
  return ok
end

local function loadSaved()
  if not jsonReadFile then return end
  local ok, data = pcall(jsonReadFile, SETTINGS_FILE)
  if not ok or type(data) ~= 'table' then return end
  settings = normalized(data.settings or data)
  if type(data.preset) == 'string' and PRESETS[data.preset] then preset = data.preset else preset = 'custom' end
  if type(data.quickShiftEnabled) == 'boolean' then quickShiftEnabled = data.quickShiftEnabled end
  if type(data.iceSlideEnabled) == 'boolean' then iceSlideEnabled = data.iceSlideEnabled end
end

local function hasPlayerVehicle()
  if not be or not be.getPlayerVehicleID then return false end
  local ok, id = pcall(be.getPlayerVehicleID, be, 0)
  return ok and id ~= nil and id ~= 0
end

local function vehicleCommand(shouldEnable, shouldQuickShift, shouldIceSlide)
  local fields = {}
  for _, key in ipairs(CONFIG_ORDER) do
    fields[#fields + 1] = key .. '=' .. string.format('%.4f', settings[key])
  end
  local config = '{' .. table.concat(fields, ',') .. '}'
  return "extensions.load('beamDriftAssist'); beamDriftAssist.setConfig(" .. config .. "); beamDriftAssist.setEnabled(" .. tostring(shouldEnable == true) .. "); beamDriftAssist.setQuickShift(" .. tostring(shouldQuickShift == true) .. "); beamDriftAssist.setIceSlide(" .. tostring(shouldIceSlide == true) .. ")"
end

local function apply(vehicle, shouldEnable, shouldQuickShift, shouldIceSlide)
  if not vehicle or not vehicle.queueLuaCommand then return false end
  local command = vehicleCommand(shouldEnable, shouldQuickShift, shouldIceSlide)
  local ok = pcall(function() vehicle:queueLuaCommand(command) end)
  return ok
end

local function playerVehicleId()
  if not be or not be.getPlayerVehicleID then return nil end
  local ok, id = pcall(be.getPlayerVehicleID, be, 0)
  if ok and id ~= 0 then return id end
  return nil
end

local function applyPlayer()
  if not be then return false end
  local currentId = playerVehicleId()
  if activeVehicleId and activeVehicleId ~= currentId and be.getObjectByID then
    local ok, oldVehicle = pcall(be.getObjectByID, be, activeVehicleId)
    if ok and oldVehicle then apply(oldVehicle, false, false, false) end
  end
  activeVehicleId = currentId
  local vehicle
  if currentId and be.getPlayerVehicle then
    local ok, value = pcall(be.getPlayerVehicle, be, 0)
    if ok then vehicle = value end
  end
  return apply(vehicle, enabled, quickShiftEnabled, iceSlideEnabled)
end

local function state()
  return {
    version = VERSION,
    enabled = enabled,
    quickShiftEnabled = quickShiftEnabled,
    iceSlideEnabled = iceSlideEnabled,
    hasVehicle = hasPlayerVehicle(),
    preset = preset,
    presetLabel = PRESETS[preset] and PRESETS[preset].label or 'CUSTOM',
    presets = {
      {key='street', label='STREET'},
      {key='formula', label='FORMULA'},
      {key='tandem', label='TANDEM'},
      {key='highAngle', label='HIGH ANGLE'}
    },
    settings = copyValues(settings),
    status = status
  }
end

local function sendState()
  local value = state()
  if guihooks and guihooks.trigger then guihooks.trigger('beamDrift.state', value) end
  return value
end

local function applyPreset(key)
  local selected = PRESETS[key]
  if not selected then return false end
  settings = normalized(selected.values)
  preset = key
  status = selected.label .. ' setup loaded.'
  persist()
  applyPlayer()
  return true
end

function M.uiState()
  return sendState()
end

function M.toggle()
  enabled = not enabled
  status = enabled and (hasPlayerVehicle() and 'Assist armed — build angle with throttle and steering.' or 'Assist armed — enter a vehicle to use it.') or 'Assist is off.'
  applyPlayer()
  if guihooks and guihooks.message then
    pcall(guihooks.message, {txt = enabled and 'BeamDrift: ON' or 'BeamDrift: OFF'}, 2.5, 'beamdrift')
  end
  sendState()
  return enabled
end

function M.setEnabled(value)
  enabled = value == true or value == 1 or value == 'true'
  status = enabled and (hasPlayerVehicle() and 'Assist armed — build angle with throttle and steering.' or 'Assist armed — enter a vehicle to use it.') or 'Assist is off.'
  applyPlayer()
  return sendState()
end

function M.setQuickShift(value)
  quickShiftEnabled = value == true or value == 1 or value == 'true'
  persist()
  applyPlayer()
  return sendState()
end

function M.setIceSlide(value)
  iceSlideEnabled = value == true or value == 1 or value == 'true'
  persist()
  applyPlayer()
  return sendState()
end

function M.quickDirection()
  local currentId = playerVehicleId()
  if not currentId or not be or not be.getPlayerVehicle then
    status = 'Enter a vehicle before using Quick R↔D.'
    return sendState()
  end
  local ok, vehicle = pcall(be.getPlayerVehicle, be, 0)
  if not ok or not vehicle or not vehicle.queueLuaCommand then
    status = 'Quick R↔D could not reach the active vehicle.'
    return sendState()
  end
  quickShiftEnabled = true
  iceSlideEnabled = true
  persist()
  applyPlayer()
  local queued = pcall(function() vehicle:queueLuaCommand("extensions.load('beamDriftAssist'); beamDriftAssist.quickShiftDirection()") end)
  status = queued and 'Quick R↔D request sent — check the selected gear.' or 'Quick R↔D command failed.'
  return sendState()
end

function M.setSetting(key, value)
  if not LIMITS[key] then return sendState() end
  local nextSettings = copyValues(settings)
  nextSettings[key] = tonumber(value)
  settings = normalized(nextSettings)
  preset = 'custom'
  status = 'Custom setup saved.'
  persist()
  applyPlayer()
  return sendState()
end

function M.setPreset(key)
  if not applyPreset(key) then return sendState() end
  return sendState()
end

function M.reset()
  settings = normalized(DEFAULTS)
  preset = 'formula'
  status = 'Formula defaults restored.'
  persist()
  applyPlayer()
  return sendState()
end

function M.onVehicleSwitched()
  applyPlayer()
  status = hasPlayerVehicle() and (enabled and 'Assist armed on current vehicle.' or 'Vehicle ready — assist is off.') or 'Enter a vehicle to use BeamDrift.'
  sendState()
end

function M.onVehicleSpawned(id)
  -- Never enable the player assist on AI or traffic vehicles.
  local currentId = playerVehicleId()
  if currentId and id == currentId and be and be.getObjectByID then
    local ok, vehicle = pcall(be.getObjectByID, be, id)
    if ok then
      activeVehicleId = id
      apply(vehicle, enabled, quickShiftEnabled, iceSlideEnabled)
    end
  end
  sendState()
end

function M.onExtensionLoaded(data)
  if type(data) == 'table' and type(data.settings) == 'table' then
    settings = normalized(data.settings)
    preset = data.preset or 'custom'
    if type(data.quickShiftEnabled) == 'boolean' then quickShiftEnabled = data.quickShiftEnabled end
    if type(data.iceSlideEnabled) == 'boolean' then iceSlideEnabled = data.iceSlideEnabled end
  else
    loadSaved()
  end
  applyPlayer()
  sendState()
end

function M.onSerialize()
  return {settings = copyValues(settings), preset = preset, enabled = enabled, quickShiftEnabled = quickShiftEnabled, iceSlideEnabled = iceSlideEnabled}
end

function M.onDeserialized(data)
  if type(data) ~= 'table' then return end
  if type(data.settings) == 'table' then settings = normalized(data.settings) end
  if type(data.preset) == 'string' then preset = PRESETS[data.preset] and data.preset or 'custom' end
  if data.enabled ~= nil then enabled = data.enabled == true end
  if data.quickShiftEnabled ~= nil then quickShiftEnabled = data.quickShiftEnabled == true end
  if data.iceSlideEnabled ~= nil then iceSlideEnabled = data.iceSlideEnabled == true end
  applyPlayer()
  sendState()
end

function M.onUpdate(dtReal)
  uiClock = uiClock + (tonumber(dtReal) or 0)
  if uiClock >= 0.5 then
    uiClock = 0
    sendState()
  end
end

loadSaved()
return M
