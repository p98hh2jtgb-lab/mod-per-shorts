angular.module('beamng.apps')
.directive('driftSketchPanel', ['$window', function($window) {
  function getAudioContext() {
    var AudioContext = $window.AudioContext || $window.webkitAudioContext;
    if (!AudioContext) return null;
    try {
      if (!$window.__driftSketchAudioContext) $window.__driftSketchAudioContext = new AudioContext();
      return $window.__driftSketchAudioContext;
    } catch (_err) { return null; }
  }
  function primeAudio() {
    var context = getAudioContext();
    if (context && context.state === 'suspended' && context.resume) {
      try { var resumed = context.resume(); if (resumed && resumed.catch) resumed.catch(function() {}); } catch (_err) {}
    }
  }
  function playHitSound(data) {
    if (!data || !data.soundEnabled) return;
    var key = String(data.eventSession || '') + ':' + String(data.eventSerial || '');
    var seen = $window.__driftSketchPlayedHits || ($window.__driftSketchPlayedHits = {});
    if (seen[key]) return;
    seen[key] = true;
    var keys = Object.keys(seen);
    if (keys.length > 64) { $window.__driftSketchPlayedHits = {}; $window.__driftSketchPlayedHits[key] = true; }
    var context = getAudioContext();
    if (!context) return;
    var rawVolume = Number(data.soundVolume);
    if (!isFinite(rawVolume)) rawVolume = 0.55;
    var level = Math.max(0, Math.min(0.12, rawVolume * 0.14));
    if (level <= 0) return;
    var play = function() {
      try {
        var now = context.currentTime;
        var oscillator = context.createOscillator();
        var gain = context.createGain();
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(760, now);
        oscillator.frequency.exponentialRampToValueAtTime(410, now + 0.105);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(level, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(now);
        oscillator.stop(now + 0.125);
      } catch (_err) {}
    };
    if (context.state === 'suspended' && context.resume) {
      try { var resumed = context.resume(); if (resumed && resumed.then) resumed.then(play).catch(function() {}); else play(); }
      catch (_err) { play(); }
    } else play();
  }
  $window.__driftSketchPlayHitSound = playHitSound;
  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/DriftSketch/app.html',
    link: function(scope) {
      scope.modVersion = '0.9.8';
      scope.state = {recording:false, pointCount:0, pathLength:0, buildCount:0, coneCount:0,
        toppledCount:0, displayTotal:0, vehicleName:'No vehicle', status:'Duke ngarkuar DriftSketch…', statusError:false};
      scope.settings = {spacing:1.0, gap:0.3, groundOffset:-0.55, maxCones:2000,
        smooth:true, keepBuilds:true, topple:true, driftWidth:false,
        hudTotal:0, hudLabel:'TOUCHED', hudSize:1.0, soundEnabled:true, soundVolume:0.55};

      var NUMERIC = ['spacing','gap','groundOffset','maxCones','hudTotal','hudSize','soundVolume'];
      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      scope.start = function() { primeAudio(); lua('extensions.driftSketch.start()'); };
      scope.stop = function() { primeAudio(); lua('extensions.driftSketch.stop()'); };
      scope.rebuild = function() { primeAudio(); lua('extensions.driftSketch.rebuild()'); };
      scope.clear = function() { lua('extensions.driftSketch.clear()'); };
      scope.pushSetting = function(key) {
        var value = scope.settings[key];
        if (NUMERIC.indexOf(key) >= 0) value = Number(value);
        if (key === 'soundEnabled' && value) primeAudio();
        lua('extensions.driftSketch.setSetting(' + JSON.stringify(key) + ',' + JSON.stringify(value) + ')');
      };
      scope.meters = function(value) { return (Number(value) || 0).toFixed(1) + ' m'; };
      scope.integer = function(value) { return Math.round(Number(value) || 0); };
      scope.canRebuild = function() {
        var s = scope.state || {};
        return !s.recording && (Number(s.buildCount) || 0) > 0;
      };

      var offHit = scope.$on('driftSketch.hit', function(_event, data) { playHitSound(data); });
      var offState = scope.$on('driftSketch.state', function(_event, data) {
        if (!data) return;
        scope.$applyAsync(function() {
          scope.state = data;
          if (data.settings) scope.settings = data.settings;
        });
      });
      scope.$on('$destroy', function() { if (offHit) offHit(); if (offState) offState(); });
      lua('extensions.driftSketch.uiState()');
    }
  };
}]);
