angular.module('beamng.apps')
.directive('driftSketchCounter', ['$window', function($window) {
  function getAudioContext() {
    var Context = $window.AudioContext || $window.webkitAudioContext;
    if (!Context) return null;
    try {
      if (!$window.__driftSketchAudioContext) $window.__driftSketchAudioContext = new Context();
      return $window.__driftSketchAudioContext;
    } catch (_err) { return null; }
  }

  function playConeSound(volume) {
    var context = getAudioContext();
    if (!context) return;
    var rawVolume = Number(volume);
    if (!isFinite(rawVolume)) rawVolume = 0.55;
    var level = Math.max(0, Math.min(0.12, rawVolume * 0.14));
    if (level <= 0) return;
    var play = function() {
      try {
        var now = context.currentTime;
        var oscillator = context.createOscillator();
        var gain = context.createGain();
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(760, now);
        oscillator.frequency.exponentialRampToValueAtTime(410, now + 0.105);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(level, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(now);
        oscillator.stop(now + 0.125);
      } catch (_err) {}
    };
    if (context.state === 'suspended' && context.resume) {
      try { var resumed = context.resume(); if (resumed && resumed.then) resumed.then(play).catch(function() {}); else play(); }
      catch (_err) { play(); }
    } else {
      play();
    }
  }

  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/DriftSketchCounter/app.html',
    link: function(scope) {
      scope.state = {
        toppledCount: 0,
        displayTotal: 0,
        settings: {hudLabel:'TOUCHED', hudSize:1.0, soundEnabled:true, soundVolume:0.55}
      };
      scope.pulse = false;
      scope.formatCount = function(value) {
        var number = Number(value);
        return isFinite(number) ? String(Math.max(0, Math.round(number))) : '0';
      };
      scope.numberStyle = function() {
        var size = Math.max(0.5, Math.min(2.5, Number(scope.state.settings.hudSize) || 1));
        return {fontSize:(72 * size) + 'px'};
      };
      scope.labelStyle = function() {
        var size = Math.max(0.5, Math.min(2.5, Number(scope.state.settings.hudSize) || 1));
        return {fontSize:(14 * size) + 'px'};
      };
      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      var offState = scope.$on('driftSketch.state', function(_event, data) {
        if (!data) return;
        scope.$applyAsync(function() { scope.state = data; });
      });
      var offHit = scope.$on('driftSketch.hit', function(_event, data) {
        if (!data) return;
        if (data.soundEnabled) {
          if ($window.__driftSketchPlayHitSound) $window.__driftSketchPlayHitSound(data);
          else playConeSound(data.soundVolume);
        }
        scope.$applyAsync(function() { scope.pulse = true; });
        $window.setTimeout(function() {
          scope.$applyAsync(function() { scope.pulse = false; });
        }, 140);
      });
      scope.$on('$destroy', function() {
        if (offState) offState();
        if (offHit) offHit();
      });
      lua('extensions.driftSketch.uiState()');
    }
  };
}]);
