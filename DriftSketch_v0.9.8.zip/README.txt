DRIFTSKETCH 0.9.8 — SHORTS COUNTER & TRAFFIC CONES
===================================================

DriftSketch regjistron vijën ku vozit, vendos traffic cones përgjatë pistës dhe
mund të numërojë konat që rrëzohen. Versioni 0.9.8 shton një HUD të veçantë
për video Shorts: numri i rrëzimeve përditësohet live, mund t'i caktohet një
total i personalizuar (p.sh. 5000 edhe kur pista ka më pak kone), etiketa dhe
madhësia ndryshohen nga paneli, ndërsa HUD-i zhvendoset/lidhet me madhësi
manualisht në UI Apps/Edit mode.

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, çaktivizoji/fshiji ZIP-at e
   vjetër të DriftSketch. Mos i mbaj dy versione aktive bashkë.
2. Kopjo DriftSketch_v0.9.8.zip në folderin Mods pa e nxjerrë nga ZIP-i.
3. Aktivizo DriftSketch te Mod Manager nëse duhet dhe rinise BeamNG.drive.
4. Në hartë shto panelin DriftSketch te App menu > Add App.

HUD-I PËR VIDEO
---------------
1. Te paneli DriftSketch, seksioni HUD PËR SHORTS:
   - Totali 0 = numri real i konave të krijuara.
   - Shkruaj p.sh. 5000 për të shfaqur progresin si 3/5000, pa ndryshuar
     numrin e konave në lojë.
   - Ndrysho etiketën (parazgjedhja TOUCHED), madhësinë, tingullin dhe volumin.
2. Shto app-in e veçantë "DriftSketch Counter" te App menu > Add App.
3. Hyr në UI Apps/Edit mode dhe tërhiqe HUD-in në cilëndo pozitë në ekran;
   ndrysho madhësinë e app-it derisa teksti të duket mirë në videon tënde.
4. Shtyp FILLO një herë për të regjistruar drive-in. Kur konat rrëzohen, numri
   rritet menjëherë dhe lëshohet një tingull i shkurtër nëse është aktiv.

Counter-i numëron çdo kon të veçantë vetëm një herë. Totali i rrëzimeve
rifillon kur pistat rindërtohen ose pastrohen. Totali i personalizuar në HUD
është vetëm tekst për video; nuk krijon kone shtesë.

PËRDORIMI I PISTËS
------------------
1. Rregullo hapësirën mes konave, distancën nga vetura dhe kufirin total.
2. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
3. Hap replay-in normal të BeamNG; konat e krijuara mbeten në skenë.
4. REBUILD i rindërton drive-t e ruajtura me cilësimet aktuale. CLEAR heq
   konat dhe drive-t e krijuara nga DriftSketch.

NDËRVEPRIMI DHE PERFORMANCA
---------------------------
Konat janë TSStatic me collision të fortë të çaktivizuar. Kur vëllimi i makinës
i prek, mesh-i anohet me animacion të lehtë; vetura mund të kalojë përmes tyre.
Nuk ka një automjet JBeam për çdo kon, për të shmangur rënien e madhe të FPS-it
që u pa në 0.9.5. Vetëm konat që rrëzohen zëvendësohen me mesh jo-instanced
para animimit. Kjo është sjellje vizuale, jo fizikë e vërtetë 1 kg.

Nëse po përditëson nga 0.9.5 ose 0.9.6, hiqe ZIP-in e vjetër dhe rinise
BeamNG.drive. 0.9.8 përpiqet t'i fshijë automjetet-kona JBeam të lëna nga
0.9.5 kur ngarkohet extension-i, nis regjistrimi, bëhet Rebuild ose Clear.

ÇFARË KA NDRYSHUAR NË 0.9.8
---------------------------
- U shtua counter live për numrin e konave të rrëzuara dhe event për tingull
  në çdo rrëzim.
- U shtua app-i i veçantë DriftSketch Counter, për overlay pa panelin e madh.
- Totali në ekran mund të jetë real ose vlerë e personalizuar deri në 9,999,999.
- Etiketa, madhësia e numrave, tingulli dhe volumi personalizohen në panel.
- Counter-i rifillon kur pista rindërtohet/pastrohet; numri rritet vetëm një
  herë për secilin kon.

ÇFARË KA NDRYSHUAR NË 0.9.7
---------------------------
- U kthye kufiri parazgjedhur 2000 dhe slider-i 100–4000, si te versionet para
  0.9.5; pistat e gjata mund të kenë përsëri dendësi më të madhe konash.
- Konat e prekura zëvendësohen me mesh jo-instanced para animimit, për të
  shmangur artefaktet grafike gjatë lëvizjes.
- U forcua pastrimi i JBeam konave të vjetra.

ÇFARË KA NDRYSHUAR NË 0.9.6
---------------------------
- U hoqën automjetet JBeam për çdo kon; konat u bënë TSStatic pa collision.
- U shtua animacioni vizual i rrëzimit kur vetura prek konin.

ÇFARË KA NDRYSHUAR NË 0.9.5
---------------------------
- DriftSketch u bë vetëm për traffic cones: u hoqën gomat, kerbs, apex bumps,
  flamujt, tabelat e frenimit, START/FINISH dhe rrathët.
- Versioni 0.9.5 krijonte një automjet JBeam për kon dhe shkaktoi kone të
  padukshme/të paqëndrueshme e rënie të madhe të FPS-it. Përdor 0.9.8.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
