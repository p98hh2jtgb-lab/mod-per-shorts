angular.module('beamng.apps')
.directive('driftSketchPanel', ['$window', function($window) {
  var SOUND_URL = '/ui/modules/apps/DriftSketchCounter/cone-hit.wav';

  function audioPool() {
    if ($window.__driftSketchAudioPool) return $window.__driftSketchAudioPool;
    var AudioCtor = $window.Audio;
    if (!AudioCtor) return null;
    try {
      var pool = [];
      for (var i = 0; i < 6; i++) {
        var audio = new AudioCtor(SOUND_URL);
        audio.preload = 'auto';
        audio.volume = 1;
        pool.push(audio);
      }
      $window.__driftSketchAudioPool = pool;
      $window.__driftSketchAudioIndex = 0;
      return pool;
    } catch (_err) { return null; }
  }

  function getAudioContext() {
    var AudioContext = $window.AudioContext || $window.webkitAudioContext;
    if (!AudioContext) return null;
    try {
      if (!$window.__driftSketchAudioContext) $window.__driftSketchAudioContext = new AudioContext();
      return $window.__driftSketchAudioContext;
    } catch (_err) { return null; }
  }

  function attachAudioGain(audio) {
    var context = getAudioContext();
    if (!context || context.state !== 'running' || !context.createMediaElementSource || !context.createGain) return null;
    if (audio.__driftSketchGainNode) return audio.__driftSketchGainNode;
    var source = null;
    try {
      source = context.createMediaElementSource(audio);
      var gain = context.createGain();
      var compressor = context.createDynamicsCompressor ? context.createDynamicsCompressor() : null;
      source.connect(gain);
      if (compressor) {
        compressor.threshold.value = -3;
        compressor.knee.value = 4;
        compressor.ratio.value = 8;
        compressor.attack.value = 0.003;
        compressor.release.value = 0.08;
        gain.connect(compressor);
        compressor.connect(context.destination);
        audio.__driftSketchCompressor = compressor;
      } else gain.connect(context.destination);
      audio.__driftSketchGainNode = gain;
      audio.__driftSketchMediaSource = source;
      return gain;
    } catch (_err) {
      // If CEF partially created a source, reconnect it directly so sound still works.
      if (source) { try { source.connect(context.destination); } catch (_ignored) {} }
      return null;
    }
  }

  function warmAudioGain() {
    var pool = audioPool();
    if (!pool) return;
    for (var i = 0; i < pool.length; i++) attachAudioGain(pool[i]);
  }

  function playToneFallback(volume) {
    var context = getAudioContext();
    if (!context) return;
    var level = Math.max(0, Math.min(0.9, volume * 0.18));
    if (level <= 0) return;
    var play = function() {
      try {
        var now = context.currentTime;
        var oscillator = context.createOscillator();
        var gain = context.createGain();
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(760, now);
        oscillator.frequency.exponentialRampToValueAtTime(410, now + 0.105);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(level, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(now);
        oscillator.stop(now + 0.125);
      } catch (_err) {}
    };
    if (context.state === 'suspended' && context.resume) {
      try {
        var resumed = context.resume();
        if (resumed && resumed.then) resumed.then(play).catch(function() {});
        else play();
      } catch (_err) { play(); }
    } else play();
  }

  function primeAudio() {
    var pool = audioPool();
    if (pool && pool.length) {
      // A muted play from the Start click primes CEF's media-playback permission.
      var audio = pool[0];
      try {
        audio.muted = true;
        var ready = audio.play();
        if (ready && ready.then) ready.then(function() {
          audio.pause();
          audio.currentTime = 0;
          audio.muted = false;
        }).catch(function() { audio.muted = false; });
        else { audio.pause(); audio.currentTime = 0; audio.muted = false; }
      } catch (_err) { audio.muted = false; }
    }
    var context = getAudioContext();
    if (context && context.state === 'suspended' && context.resume) {
      try {
        var resumed = context.resume();
        if (resumed && resumed.then) resumed.then(warmAudioGain).catch(function() {});
        else warmAudioGain();
      } catch (_err) {}
    } else warmAudioGain();
  }

  function playHitSound(data) {
    if (!data || !data.soundEnabled) return;
    var key = String(data.eventSession || '') + ':' + String(data.eventSerial || '');
    var seen = $window.__driftSketchPlayedHits || ($window.__driftSketchPlayedHits = {});
    if (seen[key]) return;
    seen[key] = true;
    var keys = Object.keys(seen);
    if (keys.length > 64) { $window.__driftSketchPlayedHits = {}; $window.__driftSketchPlayedHits[key] = true; }

    var rawVolume = Number(data.soundVolume);
    if (!isFinite(rawVolume)) rawVolume = 3;
    var volume = Math.max(0, Math.min(5, rawVolume));
    if (volume <= 0) return;

    var pool = audioPool();
    if (pool && pool.length) {
      try {
        var index = $window.__driftSketchAudioIndex % pool.length;
        $window.__driftSketchAudioIndex = index + 1;
        var audio = pool[index];
        var gainNode = attachAudioGain(audio);
        audio.muted = false;
        audio.volume = gainNode ? 1 : Math.min(1, volume);
        if (gainNode) {
          var context = getAudioContext();
          try {
            if (context && gainNode.gain.setValueAtTime) gainNode.gain.setValueAtTime(volume, context.currentTime);
            else gainNode.gain.value = volume;
          } catch (_err) { gainNode.gain.value = volume; }
        }
        try { audio.currentTime = 0; } catch (_ignored) {}
        var playing = audio.play();
        if (playing && playing.catch) playing.catch(function() { playToneFallback(volume); });
        return;
      } catch (_err) {}
    }
    playToneFallback(volume);
  }

  // Both the direct hit event and the state event can call this; the serial dedupes them.
  $window.__driftSketchPlayHitSound = playHitSound;

  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/DriftSketch/app.html',
    link: function(scope) {
      scope.panelHidden = false;
      scope.minimizePanel = function() { scope.panelHidden = true; };
      scope.closePanel = function() { scope.panelHidden = true; };
      scope.showPanel = function() { scope.panelHidden = false; };
      scope.modVersion = '0.9.19';
      scope.state = {recording:false, pointCount:0, pathLength:0, buildCount:0, coneCount:0,
        toppledCount:0, displayTotal:0, vehicleName:'No vehicle', status:'Duke ngarkuar DriftSketch…', statusError:false};
      scope.settings = {spacing:1.0, gap:0.3, groundOffset:-0.55, maxCones:2000,
        smooth:true, keepBuilds:true, topple:true, coneCollision:false, driftWidth:false,
        hudTotal:0, hudLabel:'CONES DOWN', hudSize:1.3, hudStyle:'outline', hudCard:false, hudOutline:true, hudGlow:false, hudShadow:true, soundEnabled:true, soundVolume:3.0};

      var NUMERIC = ['spacing','gap','groundOffset','maxCones','hudTotal','hudSize','soundVolume'];
      var lastEventSession = null;
      var lastEventSerial = null;
      function lua(command) {
        if ($window.bngApi && $window.bngApi.engineLua) $window.bngApi.engineLua(command);
      }
      function syncHitSounds(data) {
        if (!data) return;
        var session = String(data.eventSession || '');
        var serial = Number(data.toppleEventSerial) || 0;
        if (lastEventSession !== session || lastEventSerial === null) {
          lastEventSession = session;
          lastEventSerial = serial;
          return;
        }
        if (serial > lastEventSerial) {
          for (var eventSerial = lastEventSerial + 1; eventSerial <= serial; eventSerial++) {
            playHitSound({eventSession:session, eventSerial:eventSerial,
              soundEnabled:!!(data.settings && data.settings.soundEnabled),
              soundVolume:data.settings && data.settings.soundVolume});
          }
        }
        lastEventSerial = serial;
      }
      scope.start = function() { primeAudio(); lua('extensions.driftSketch.start()'); };
      scope.stop = function() { primeAudio(); lua('extensions.driftSketch.stop()'); };
      scope.rebuild = function() { primeAudio(); lua('extensions.driftSketch.rebuild()'); };
      scope.clear = function() { lua('extensions.driftSketch.clear()'); };
      scope.pushSetting = function(key) {
        var value = scope.settings[key];
        if (NUMERIC.indexOf(key) >= 0) value = Number(value);
        if (key === 'soundEnabled' && value) primeAudio();
        lua('extensions.driftSketch.setSetting(' + JSON.stringify(key) + ',' + JSON.stringify(value) + ')');
      };
      scope.setHudStyle = function(style) {
        if (style !== 'neon' && style !== 'outline') return;
        if (scope.settings.hudCard) {
          scope.settings.hudCard = false;
          scope.pushSetting('hudCard');
        }
        scope.settings.hudStyle = style;
        scope.settings.hudGlow = style === 'neon';
        scope.settings.hudShadow = style === 'outline';
        scope.pushSetting('hudStyle');
      };
      scope.meters = function(value) { return (Number(value) || 0).toFixed(1) + ' m'; };
      scope.integer = function(value) { return Math.round(Number(value) || 0); };
      scope.hudCount = function(value) {
        var number = Number(value);
        if (!isFinite(number)) number = 0;
        return String(Math.max(0, Math.round(number))).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      };
      scope.canRebuild = function() {
        var s = scope.state || {};
        return !s.recording && (Number(s.buildCount) || 0) > 0;
      };

      var offHit = scope.$on('driftSketch.hit', function(_event, data) { playHitSound(data); });
      var offState = scope.$on('driftSketch.state', function(_event, data) {
        if (!data) return;
        syncHitSounds(data);
        scope.$applyAsync(function() {
          scope.state = data;
          if (data.settings) scope.settings = data.settings;
        });
      });
      scope.$on('$destroy', function() { if (offHit) offHit(); if (offState) offState(); });
      lua('extensions.driftSketch.uiState()');
    }
  };
}]);
