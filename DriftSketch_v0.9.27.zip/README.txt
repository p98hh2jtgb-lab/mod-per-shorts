DRIFTSKETCH 0.9.27 — HAPËSIRA SHTESË SHKON TE RIMORKIOJA, JO TE ANA BOSH
===========================================================================
Bazuar te 0.9.4. S'ka rrëzim, s'ka numra/counter, s'ka HUD, s'ka tingull, s'ka
automjet JBeam për kon. Konet janë TSStatic të lehta; "Solid / car damage" OFF.

VËZHGIMI YT ISHTE GABIMI REAL
------------------------------
Në 6 screenshot-et (118 km/h, 275 pika / 408.9 m, `✓ 1788 pika të vijës së
rimorkios`, `clone #52786 · Auto`) e dragove sliderin 4 → 3.3 → 2.4 → 1 → 0 →
1.7 m. E matëm me piksel: **vija e majtë, ajo që prek rimorkion, nuk lëviz
fare**; ndryshimi duket në anën tjetër dhe në kthesën përpara. Ti e the saktë:
"po zgjonohet rruga anen ku nuk duhet ... jo mas trailerit ... veq perpara".

Shkaku (i riprodhuar në mock, shifrat e sakta):

    pad 0 m : ana e rimorkios 2.99 m  ·  ana BOSH 1.54 m
    pad 1 m : ana e rimorkios 2.99 m  ·  ana BOSH 2.54 m   <-- KËTU
    pad 2 m : ana e rimorkios 3.54 m  ·  ana BOSH 3.54 m
    pad 4 m : ana e rimorkios 5.54 m  ·  ana BOSH 5.54 m

`rigPad` futej te `base = halfWidth + margin + pad` dhe pastaj kalonte në
`math.max(needLeft, ...)`. Ana e rimorkios ishte TASHMË më e madhe se `base`,
kështu çdo metër i ri "hahej" nga ai `max` dhe përfundonte në anën bosh — pikërisht
ana që s'kishte nevojë. Vetëm kur pad-i kalonte ~1.5 m fillonte të lëvizte edhe
ana e rimorkios, por atëherë të dyja anët ishin tashmë shumë të gjera.

Gabim i dytë, i gjetur gjatë kësaj kontrolli: `useSelectedVehicle()` dhe zbulimi
automatik **e mbishkruanin vetë sliderin** me një vlerë të llogaritur
(`rigPadFor`, mbetje nga 0.9.24 kur pad ishte gjerësi simetrike). Prandaj numri
sillet çuditshëm kur e lëviz. Është hequr.

ÇFARË NDRYSHOI TE 0.9.27
-------------------------
1. **`rigPad` nuk është më dysheme globale.** `base = halfWidth + margin`
   (vijat e ngushta të 0.9.4). Hapësira shtesë shtohet **mbi** nevojën e
   llogaritur nga drejtkëndëshi i rimorkios dhe **vetëm në anën ku qendra e
   rimorkios ndodhet** për atë stacion. Nëse s'ka rimorkio aty, shtesa është 0 —
   rruga nuk zgjerohet kurrë kot.

       pad 0 m : ana e rimorkios 2.99 m  ·  ana BOSH 1.54 m
       pad 1 m : ana e rimorkios 3.99 m  ·  ana BOSH 1.54 m
       pad 2 m : ana e rimorkios 4.99 m  ·  ana BOSH 1.54 m
       pad 4 m : ana e rimorkios 6.99 m  ·  ana BOSH 1.54 m

2. **Slideri yt nuk mbishkruhet më** nga zbulimi automatik, nga butoni i World
   Editor ose nga REBUILD. Ajo që vendos ti, ajo qëndron.
3. **Përmasat e rimorkios maten në kornizën e saj**, jo në kornizën e makinës.
   `be:getObjectOOBBHalfAxisXYZ` kthen vektorë në botë që rrotullohen me
   objektin; më parë projektoheshin mbi drejtimin e makinës, kështu një
   rimorkio e rrotulluar (Node Grabber në drift) nënvlerësohej.
4. Emri i sliderit u bë **"Hapësira shtesë e rimorkios / Trailer extra room"**
   (ish "Hapësira minimale / Safety floor"), sepse nuk është më dysheme.
   Paneli shpjegon shkurt: "shtohet vetëm në anën e rimorkios · ana tjetër nuk
   lëviz · vlera jote nuk mbishkruhet më".
5. Ruhet gjithçka nga 0.9.26/0.9.25: zbulimi me **co-motion** për Node Grabber
   (CTRL + klik majtë → mesi i mausit, pa kuk / pa `L` / pa World Editor), vija
   e qendrës së rimorkios, drejtkëndëshi i rrotulluar, zarfi i lëkundjes ±20° për
   drive-t e vjetra, butoni **↻ RIPROVË ZBULIMIN**, finish-i prapa pjesës së
   pasme, treguesi **"✓ N pika të vijës së rimorkios"**, lista e kandidatëve e
   memorizuar 1.5 s / max 32 objekte.

SI TA PËRDORËSH
----------------
1. Çaktivizo çdo ZIP tjetër DriftSketch → vendos vetëm këtë te Mods, pa e nxjerrë
   → **rindis BeamNG.drive**. (Screenshot-et e tua ishin ende te **v0.9.25** —
   ky ZIP është 0.9.27.)
2. Ngjite rimorkion si zakonisht: **CTRL + klik majtë → mesi i mausit**. Mos hap
   World Editor, mos shtyp `L`.
3. Me drive-n e ruajtur: **↻ RIPROVË ZBULIMIN** ose **REBUILD**, pastaj lëvize
   **Hapësira shtesë e rimorkios** gradualisht (p.sh. 0.5 → 1.0 → 1.5 m). Tani
   do ta shohësh **vijën e majtë që lëviz** — atë që prek rimorkion — ndërsa
   vija e djathtë mbetet aty ku ishte.
4. Nëse ende prek, rrit edhe pak atë slider ose **Margjinë sigurie**. Nëse vijat
   duken larg, ul të dyja. Mos e ngatërro me 0.9.24: asnjëra nuk e zgjeron më
   të gjithë rrugën në të dyja anët.
5. Për matjen më të saktë, regjistro një run të ri me FILLO → vozit → NDALO &
   NDËRTO: çdo pikë ruan pozitën e vërtetë të rimorkios, jo një zarf.

TESTET
------
Lua 74/0 · UI 72/0 · statike 182/197/0 · `loadfile` + `node --check` · 14
asset-e identikë me 0.9.4. Testi i ri më i rëndësishëm: **sweep-i i sliderit**
(0, 1, 2, 3, 4 m) kërkon që ana bosh të mbetet 1.54 m në çdo hap dhe ana e
rimorkios të rritet me saktësisht 1 m për çdo metër shtesë. Kontrolli i koneve
tani përdor **drejtkëndëshin e rrotulluar** të rimorkios, jo një rreth rreth
qendrës (testi i vjetër ishte shumë i butë). Kontrollohet gjithashtu që as
zbulimi automatik, as regjistrimi me World Editor nua e ndryshojnë sliderin.
Me Lua-n e 0.9.26 i njëjti sweep dështon: 0→1 m e çon anën bosh 1.54→2.54 m.

PSE ZBULIMI BËHET ME LËVIZJE, JO ME EVENT
-----------------------------------------
Nuk ka asnjë API publike që t'i listojë lidhjet nyje-në-nyjë. `be.nodeGrabber:
fixCurrentNode()` lidh vetëm nyjet që janë nën kursor dhe s'ka funksion me ID;
`clearVehicleFixedNodes(vid)` fshin vetëm nyjet e fiksuara në ajër. Eventet
`onCouplerAttached` / `onCouplerDetached` janë për kukun e vërtetë dhe nuk
ndizen për këtë lidhje. Prandaj sinjali i vetëm i besueshëm është co-motion.

SHËNIM PËR CILËSIMET E TUA
---------------------------
Ke Gap 0 m, Spacing 0.5 m, Drift widen ON, Performance cap 2000. Me 0.9.27 ana
pa rimorkio mbetet ~1.2–1.5 m nga qendra (si te 0.9.4), ana e rimorkios hapet
vetëm aty ku ajo kalon. Rreshti i finish-it merr disa objekte më shumë; nëse
vijat anësore duken më të rralla, rrit pak Performance cap (p.sh. 2500).

PERFORMANCA DHE MIGRIMI
-----------------------
E njëjta si 0.9.26: llogaritje një herë në ndërtim, asnjë punë për kornizë,
konet nuk skanohen kurrë, TSStatic me instance rendering dhe collision=None.
Cilësimet, drive-t e ruajtura dhe rrathët nga 0.9.4 → 0.9.26 ruhen; çelësat e
hequr (topple, coneCollision, hud*, sound*) injorohen. Çelësi `rigPad` ruhet me
kuptimin e ri (shtesë vetëm në anën e rimorkios).

HISTORIA
--------
0.9.4  i pastër, konet TSStatic, pa rrëzim/numra.
0.9.22 kthim i pastër. 0.9.23 zbulim vetëm gjatë regjistrimit.
0.9.24 gjerësi simetrike në ndërtim (rrugë e gjerë, prap prek).
0.9.25 vija e qendrës + pastrim njëanësor; zbulim me pozitë të fiksuar.
0.9.26 zbulim me co-motion për Node Grabber + zarf lëkundjeje.
0.9.27 shtesa e sliderit shkon te rimorkioja, jo te ana bosh; slideri nuk
       mbishkruhet; përmasat maten në kornizën e rimorkios.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
