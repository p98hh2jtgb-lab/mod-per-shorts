-- BeamDrift 1.3.0 - drift assist, J-turn shift and optional all-speed slide push.
-- Applies a bounded yaw torque across the vehicle nodes; it does not edit JBeam.
local M = {}

local DEFAULTS = {
  targetAngle = 45,
  maxAngle = 62,
  assistStrength = 1.0,
  antiSpinStrength = 3.0,
  transitionStrength = 2.2,
  engageAngle = 32,
  minSpeedKmh = 22,
  responseCap = 3.5,
  slideForce = 2.5,
  directionPunch = 5.0
}
local LIMITS = {
  targetAngle = {20, 68},
  maxAngle = {35, 78},
  assistStrength = {0, 2.5},
  antiSpinStrength = {0, 6},
  transitionStrength = {0, 4},
  engageAngle = {8, 48},
  minSpeedKmh = {5, 80},
  responseCap = {0.5, 6},
  slideForce = {0, 8},
  directionPunch = {0, 10}
}
local PHYS_HZ = 2000
local config = {}
for key, value in pairs(DEFAULTS) do config[key] = value end
local enabled = false
local quickShiftEnabled = false
local iceSlideEnabled = false
local slideDirection = 1
local directionPulseTimer, directionPulseSign = 0, 1
local patchedShiftLogic = nil
local savedShiftDelays = nil
local SHIFT_DELAY_KEYS = {'neutralSelectionDelay', 'gearChangeDelay'}
local previousForward = nil
local alphaSmooth = 0
local latch, holdAngle, transition = 0, 45, 0
local transitionTime, oppositeSteerTime, noThrottleTime = 0, 0, 0

local function clamp(value, low, high)
  return math.max(low, math.min(high, value))
end

local function atan2(y, x)
  if math.atan2 then return math.atan2(y, x) end
  if x > 0 then return math.atan(y / x) end
  if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
  if x < 0 and y < 0 then return math.atan(y / x) - math.pi end
  if x == 0 and y > 0 then return math.pi * 0.5 end
  if x == 0 and y < 0 then return -math.pi * 0.5 end
  return 0
end

local function normalized(values)
  local out = {}
  for key, bounds in pairs(LIMITS) do
    local value = tonumber(values and values[key])
    if not value or value ~= value or value == math.huge or value == -math.huge then value = DEFAULTS[key] end
    out[key] = clamp(value, bounds[1], bounds[2])
  end
  out.maxAngle = math.max(out.maxAngle, out.targetAngle + 4)
  if out.maxAngle > LIMITS.maxAngle[2] then
    out.maxAngle = LIMITS.maxAngle[2]
    out.targetAngle = math.min(out.targetAngle, out.maxAngle - 4)
  end
  out.engageAngle = math.max(LIMITS.engageAngle[1], math.min(out.engageAngle, out.targetAngle - 3))
  return out
end

local function restoreQuickShift()
  if patchedShiftLogic and savedShiftDelays and type(patchedShiftLogic.timerConstants) == 'table' then
    for key, value in pairs(savedShiftDelays) do
      patchedShiftLogic.timerConstants[key] = value
    end
  end
  patchedShiftLogic = nil
  savedShiftDelays = nil
end

local function applyQuickShift()
  if not quickShiftEnabled then
    restoreQuickShift()
    return false
  end

  local shiftLogic = type(controller) == 'table' and controller.mainController or nil
  if type(shiftLogic) ~= 'table' or type(shiftLogic.timerConstants) ~= 'table' then
    restoreQuickShift()
    return false
  end

  if patchedShiftLogic ~= shiftLogic then
    restoreQuickShift()
    patchedShiftLogic = shiftLogic
    savedShiftDelays = {}
    for _, key in ipairs(SHIFT_DELAY_KEYS) do
      local value = shiftLogic.timerConstants[key]
      if type(value) == 'number' then savedShiftDelays[key] = value end
    end
  end

  local changed = false
  for _, key in ipairs(SHIFT_DELAY_KEYS) do
    if savedShiftDelays and savedShiftDelays[key] ~= nil then
      shiftLogic.timerConstants[key] = 0
      changed = true
      local timerKey = key .. 'Timer'
      if type(shiftLogic.timer) == 'table' and shiftLogic.timer[timerKey] ~= nil then
        shiftLogic.timer[timerKey] = 0
      end
    end
  end
  return changed
end

local function applyLinearAcceleration(direction, acceleration, dt)
  if acceleration <= 0 or not obj or not v or not v.data or not v.data.nodes then return end
  local compensation = clamp((tonumber(dt) or 0) * PHYS_HZ, 1, 20)
  for cid, node in pairs(v.data.nodes) do
    local mass = node.nodeWeight or 0
    if mass > 0 then
      obj:applyForceVector(cid, direction * (mass * acceleration * compensation))
    end
  end
end

local function resetControl()
  previousForward = nil
  alphaSmooth = 0
  latch, holdAngle, transition = 0, config.targetAngle, 0
  transitionTime, oppositeSteerTime, noThrottleTime = 0, 0, 0
end

function M.setConfig(values)
  config = normalized(values)
  if latch ~= 0 then holdAngle = config.targetAngle end
end

function M.setEnabled(value)
  enabled = value == true or value == 1 or value == 'true'
  resetControl()
end

function M.setQuickShift(value)
  quickShiftEnabled = value == true or value == 1 or value == 'true'
  applyQuickShift()
end

function M.setIceSlide(value)
  iceSlideEnabled = value == true or value == 1 or value == 'true'
  if not iceSlideEnabled then slideDirection = 1 end
end

-- Request the opposite direction directly through the active gearbox controller.
-- Automatic selectors use index 2 for Drive; manual gearboxes use first gear (1).
function M.quickShiftDirection()
  local main = type(controller) == 'table' and controller.mainController or nil
  if type(main) ~= 'table' or type(main.shiftToGearIndex) ~= 'function' then return false end
  local values = electrics and electrics.values or {}
  local gearName = tostring(values.gear or ''):upper()
  local gearboxMode = tostring(values.gearboxMode or ''):upper()
  local gearIndex = tonumber(values.gearIndex) or 0
  local isReverse = gearName == 'R' or gearboxMode == 'R' or gearIndex < 0
  local targetIndex = -1
  if isReverse or gearName == 'N' or gearboxMode == 'N' or gearIndex == 0 then
    targetIndex = 2
    local gearbox = powertrain and powertrain.getDevice and powertrain.getDevice('gearbox')
    if gearbox and (gearbox.type == 'manualGearbox' or gearbox.type == 'sequentialGearbox') then
      targetIndex = 1
    end
  end
  local ok = pcall(function() main.shiftToGearIndex(targetIndex) end)
  if ok then
    directionPulseSign = targetIndex < 0 and -1 or 1
    directionPulseTimer = 0.22
    if quickShiftEnabled then applyQuickShift() end
  end
  return ok, targetIndex
end

function M.getState()
  return {enabled = enabled, quickShiftEnabled = quickShiftEnabled, iceSlideEnabled = iceSlideEnabled, config = config}
end

local function applyYaw(alphaRight, dt)
  if not obj or not v or not v.data or not v.data.nodes then return end
  local up = obj:getDirectionVectorUp()
  local alphaCCW = -alphaRight
  local compensation = clamp(dt * PHYS_HZ, 1, 20)
  local sx, sy, sz, totalMass = 0, 0, 0, 0
  for cid, node in pairs(v.data.nodes) do
    local mass = node.nodeWeight or 0
    if mass > 0 then
      local point = obj:getNodePosition(cid)
      sx = sx + point.x * mass
      sy = sy + point.y * mass
      sz = sz + point.z * mass
      totalMass = totalMass + mass
    end
  end
  if totalMass <= 0 then return end
  local center = vec3(sx / totalMass, sy / totalMass, sz / totalMass)
  for cid, node in pairs(v.data.nodes) do
    local mass = node.nodeWeight or 0
    if mass > 0 then
      local offset = obj:getNodePosition(cid) - center
      local force = up:cross(offset) * (mass * alphaCCW * compensation)
      obj:applyForceVector(cid, force)
    end
  end
end

function M.updateGFX(dt)
  if quickShiftEnabled then applyQuickShift() end
  if not dt or dt <= 0 or not obj then return end
  local velocity = obj:getVelocity()
  local forward = obj:getDirectionVector()
  local up = obj:getDirectionVectorUp()
  local right = forward:cross(up)
  local speed = velocity:length()

  -- The direction key adds a short forward/reverse push at any moving speed.
  if directionPulseTimer > 0 then
    applyLinearAcceleration(forward * directionPulseSign, config.directionPunch, dt)
    directionPulseTimer = math.max(0, directionPulseTimer - dt)
  end

  -- Arcade slide force is active independently of the drift-assist latch or steering speed gate.
  if iceSlideEnabled and speed > 0.1 then
    local forwardSpeed = velocity:dot(forward)
    local lateralSpeed = velocity:dot(right)
    local steering = electrics and electrics.values and electrics.values.steering_input or 0
    if math.abs(steering) > 0.08 then
      slideDirection = steering > 0 and 1 or -1
    elseif math.abs(lateralSpeed) > 0.2 then
      slideDirection = lateralSpeed > 0 and 1 or -1
    end
    local slipAngle = math.abs(math.deg(atan2(lateralSpeed, math.max(math.abs(forwardSpeed), 0.1))))
    local forceFade = clamp((80 - slipAngle) / 35, 0, 1)
    if forceFade > 0 then
      applyLinearAcceleration(right * slideDirection, config.slideForce * forceFade, dt)
    end
  end

  if not enabled then return end
  local speedKmh = speed * 3.6

  local yawRate = 0
  if previousForward then yawRate = -(previousForward:cross(forward)):dot(up) / dt end
  previousForward = vec3(forward.x, forward.y, forward.z)

  local target = 0
  local minimumAssistSpeed = math.max(6, config.minSpeedKmh * 0.42)
  if speedKmh >= minimumAssistSpeed then
    local forwardSpeed = velocity:dot(forward)
    local lateralSpeed = velocity:dot(right)
    local angle = math.deg(atan2(lateralSpeed, forwardSpeed))
    local absoluteAngle = math.abs(angle)
    local angleSign = angle >= 0 and 1 or -1
    local throttle = electrics and electrics.values and electrics.values.throttle or 0
    local handbrake = electrics and electrics.values and electrics.values.parkingbrake or 0
    local steering = (electrics and electrics.values and electrics.values.steering_input or 0)
    local yawDirection, strength = 0, 0
    local spinning = (yawRate * angleSign) < -0.8 and absoluteAngle > 35
    local releaseSpeed = config.minSpeedKmh * 0.7

    if latch ~= 0 then
      if angleSign ~= latch or absoluteAngle < 12 or speedKmh < releaseSpeed or forwardSpeed <= 0 then
        latch = 0
      else
        -- Keep the requested angle live so the panel remains useful while driving.
        holdAngle = clamp(config.targetAngle, config.engageAngle + 2, config.maxAngle - 2)
        noThrottleTime = throttle < 0.1 and noThrottleTime + dt or 0
        if noThrottleTime > 0.8 then latch = 0 end
        oppositeSteerTime = steering * latch > 0.4 and oppositeSteerTime + dt or 0
        if oppositeSteerTime > 0.12 and latch ~= 0 then
          transition = steering > 0 and 1 or -1
          transitionTime, oppositeSteerTime, latch = 0, 0, 0
        end
      end
    elseif transition == 0 and absoluteAngle >= config.engageAngle and forwardSpeed > 0
      and speedKmh >= config.minSpeedKmh and throttle > 0.2 then
      latch = angleSign
      holdAngle = clamp(config.targetAngle, config.engageAngle + 2, config.maxAngle - 2)
      noThrottleTime, oppositeSteerTime = 0, 0
    end

    if absoluteAngle > config.maxAngle or (spinning and absoluteAngle > 35) then
      -- Anti-spin takes priority when the body is rotating away from the existing slide.
      transition = 0
      yawDirection = angleSign
      local overAngle = math.max(absoluteAngle - config.maxAngle, 0) / 20
      local rotationRate = clamp(math.abs(yawRate) / 3, 0, 1)
      strength = config.antiSpinStrength * clamp(0.4 + overAngle + rotationRate, 0.4, 1.5)
    elseif transition ~= 0 then
      transitionTime = transitionTime + dt
      if (angleSign == -transition and absoluteAngle > 25) or transitionTime > 1.5 or forwardSpeed <= 0 then
        transition = 0
      else
        yawDirection = transition
        strength = config.transitionStrength * (0.6 + 0.4 * throttle)
      end
    elseif latch ~= 0 then
      local errorRatio = (holdAngle - absoluteAngle) / math.max(holdAngle, 1)
      yawDirection = -angleSign * (errorRatio > 0 and 1 or -1)
      strength = 1.2 * config.assistStrength * math.abs(errorRatio) * (0.6 + throttle)
    elseif speedKmh >= config.minSpeedKmh and forwardSpeed > 0
      and (handbrake > 0.3 or throttle > 0.3) and math.abs(steering) > 0.2
      and absoluteAngle < config.engageAngle then
      yawDirection = steering > 0 and 1 or -1
      strength = config.assistStrength * math.abs(steering) * (handbrake > 0.3 and 1.3 or 1)
    end
    target = clamp(yawDirection * strength * 0.8, -config.responseCap, config.responseCap)
  end

  -- Smooth the torque so switching the assist or changing a slider does not jolt the car.
  alphaSmooth = alphaSmooth + (target - alphaSmooth) * clamp(dt * 8, 0, 1)
  if math.abs(alphaSmooth) < 0.02 then return end
  applyYaw(alphaSmooth, dt)
end

function M.onVehicleReset()
  resetControl()
  if quickShiftEnabled then applyQuickShift() end
end

return M
