BEAMDRIFT 1.3.0 — DRIFT / J-TURN / ICE-SLIDE PUSH
=================================================

A standalone BeamNG.drive mod with an in-game tuning panel. It includes drift
assist, an optional quick R-D direction request, a short forward/reverse punch,
and an all-moving-speeds force-based slide effect.

INSTALL
-------
1. Put BeamDrift_v1.3.0.zip in your BeamNG.drive user mods folder.
2. Disable/remove the original Formula Drift Mode v4 while using BeamDrift; do not
   run two drift-assist controllers on the same vehicle at once.
3. Restart BeamNG.drive, add BeamDrift from the in-game app menu, and enter a car.
4. For a keyboard/controller binding, open Options > Controls and search for
   "BeamDrift: Toggle Assist" or "BeamDrift: Quick R-D / J-Turn". Bind J-turn to
   a separate key/button so it does not conflict with standard gear controls.
5. Use the panel switches and open ADVANCED CONTROL to tune Slide push and
   J-turn punch. Settings save automatically.

CONTROLS
--------
- Quick Shift clears supported automatic/arcade gear-selection wait timers on
  the active player vehicle.
- Quick R-D / J-Turn requests the opposite direction through the active gearbox
  controller: R -> D (or first gear on a manual), then D -> R. It enables Quick
  Shift and Ice Slide and adds a short directional push.
- Ice Slide Mode applies a configurable lateral force at all moving speeds. It
  is a force-based arcade effect, not a real-time tire-friction change.
- Slide push and J-turn punch are bounded by panel sliders; set either to zero
  to disable that force while retaining the other mode.

TUNING / SAFETY
---------------
- Gearbox controllers may still impose vehicle-specific speed/clutch safeguards;
  a gear request cannot guarantee an actual zero-millisecond shift in every car.
- The J-turn punch and slide force are not speed-gated. At high speed they can
  create abrupt forces, loss of control, or drivetrain damage in BeamNG. Start
  with low slider values in an empty area; raise them gradually.
- The Ice Slide option does not lower the tire's actual friction coefficient.
  It pushes the vehicle laterally to imitate an ice-like slide. The feel varies
  by vehicle, game version and speed.
- For more sliding, disable BeamNG's Oversteer reduction assistant and
  Understeer reduction assistant (Options > Gameplay > Driving Assistants).
- BeamDrift operates only on the active player vehicle; traffic/AI is not changed.
  It does not edit JBeam or vehicle files. Settings live in settings/beamDrift.json.

CREDITS / COMPATIBILITY
-----------------------
BeamDrift is a standalone implementation built around behavior requested from
the user-supplied Formula Drift Mode reference. That archive contained no
author/license metadata. No third-party meshes are included; confirm rights and
attribution before publicly redistributing any derivative or reused code.

Tested with Lua syntax checks, mocked BeamNG runtime tests, and an Angular/JSDOM
UI check. A real in-game BeamNG test is still recommended before relying on the
J-turn, push force, slide force, or drift tuning.
