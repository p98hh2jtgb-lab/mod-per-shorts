BEAMDRIFT 1.1.0 — CONFIGURABLE DRIFT ASSIST
===========================================

A standalone BeamNG.drive mod with a live in-game tuning panel. BeamDrift helps
initiate and hold a controlled drift angle, assists transitions and adds a
bounded anti-spin response. Tune it from the BeamDrift app without editing Lua.

INSTALL
-------
1. Put BeamDrift_v1.1.0.zip in your BeamNG.drive user mods folder.
2. Disable/remove the original Formula Drift Mode v4 while using BeamDrift; do not
   run two drift-assist controllers on the same vehicle at once.
3. Restart BeamNG.drive after installing.
4. Open the in-game app menu, add the BeamDrift app, then enter a vehicle.
5. Use the large switch in the panel. BeamDrift settings save automatically.
6. Optional keyboard shortcut: Options > Controls, search for
   "BeamDrift: Toggle Assist", then assign a key or controller button.

PANEL
-----
- Street, Formula, Tandem and High Angle one-click presets.
- Target drift angle, assist strength, anti-spin strength, transition strength
  and minimum engage speed.
- Advanced engage angle, maximum slip angle and response cap.
- Live ON/OFF, vehicle-linked indicators and saved settings; Reset restores Formula defaults.
- Optional Quick R/N/D switch clears supported automatic/arcade gear-selection wait timers on the active player vehicle, independently of the drift assist.
- The toggle key is optional. The panel works without assigning a key.

SAFETY / TUNING
---------------
- Start with STREET or a low Assist strength. Increase gradually on a safe,
  open test area. Lower Response cap for a gentler correction.
- The assist operates on the active vehicle's physics nodes and may feel
  different between vehicles, tyres, steering setups and game versions.
- Quick R/N/D removes supported controller wait timers, not physical clutch
  engagement or every gearbox's own shift time. It may not eliminate all delay.
- Opposite-direction shifts at speed can cause abrupt wheel torque or drivetrain
  damage in BeamNG. Test carefully in an empty area; turn Quick R/N/D off for a
  more stock/realistic gearbox response.
- If drift assist pushes the wrong way, turn it off and note the vehicle and
  steps that reproduced it. Do not test near other players or traffic.
- BeamDrift does not edit JBeam files, vehicle configs, or original vehicle
  assets. Its settings are stored in settings/beamDrift.json.

CREDITS / COMPATIBILITY
-----------------------
BeamDrift is a standalone implementation built around the behavior requested
from the user-supplied Formula Drift Mode reference. That archive contained no
author/license metadata. No third-party meshes are included; confirm rights
and attribution before publicly redistributing any derivative or reused code.

Tested with Lua syntax checks, a mocked BeamNG runtime, and an Angular/JSDOM UI
check. A real in-game BeamNG test is still recommended to validate force tuning
on your vehicle and current game version.
