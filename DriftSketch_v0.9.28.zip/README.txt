DRIFTSKETCH 0.9.28 — RROTULLIMI / MBIVENDOSJA E RRUGËS
========================================================
Bazuar te 0.9.4. S'ka rrëzim, s'ka numra/counter, s'ka HUD, s'ka tingull, s'ka
automjet JBeam për kon. Konet janë TSStatic të lehta; "Solid / car damage" OFF.
Vetëm DY sliderë të rimorkios, të dy në 0 m në screenshot-et e tua.

ÇFARË TIREGON ME DY SCREENSHOT-ET (0.9.27, 3 km/h, 547 pikë / 478.4 m,
1888 mesh, ✓ 2256 pika të vijës së rimorkios)
---------------------------------------------------------------
"Tash osht ma mir" — 0.9.27 e rregulloi anën e gabuar. Por kur sillesh ngadalë
me rimorkion e përmbysur (~90° kundrejt makinës), prapa saj shfaqet një **krehër
/ rrjetë konësh** në mes të rrugës dhe konet kalojnë përmes rimorkios e makinës.

E riprodhuam në mock me një **spiral** (rruga që kthehet mbi vetvete, si donut
i ngadaltë). Me Lua-n e 0.9.27:

    spiral N=200 : 23 konë BRENDA korridorit · 212 goditje në drejtkëndëshin e rimorkios
    spiral N=320 : 38 konë BRENDA korridorit · 397 goditje
    rreth i pastër:  0 / 0   (kthesa e thjeshtë ishte në rregull)

Shkaku: `markFolds()` dhe `corridorNeeds()` krahasonin vetëm pika që janë
**ngjitur në indeks të rrugës** (±10 m gjatë vijës). Në një rrotullim, pikat e
xhiros tjetër janë **afër në hapësirë** por **larg në indeks** — kështu konet e
një xhiroje bien në korridorin e tjetrës. Pjesa tjetër e "krehrit" është
**rreshti i finish-it + dy zgjatimet anësore**, që priten tërthorazi përmes
vendit ku ndalet makina e ku rimorkioja është përmbysur. Asnjëri prej tyre nuk
kontrollohej kundër trupit të makinës / rimorkios së pikave të tjera.

ÇFARË NDRYSHOI TE 0.9.28
-------------------------
1. **Kontroll "keep-out" njëherësh në ndërtim.** Pasi llogariten të gjitha konet
   (të dy vijat, zgjatimet dhe rreshti i finish-it), një rrjet hapësinor 4 m
   indekson **çdo pikë të rrugës** (disku i trupit të makinës) dhe **çdo
   drejtkëndësh të rrotulluar të rimorkios**. Çdo kon që bie brenda ndonjërit
   **hiqet**. Kontrolli është kundër të gjitha pikave, jo vetëm atyre ngjitur —
   prandaj funksionon edhe kur rruga mbivendoset me vetveten.
2. **VETËM HEQ konë** — nuk zgjeron rrugën, nuk shtyon asgjë, nuk prek fizikën,
   nuk bën asnjë punë për kornizë. Prandaj s'kthehet problemi "rruga shum gjon".
   Një drive i drejtë nuk humb asnjë kon; një rreth i pastër mbetet identik.
3. **Tregues i ri në panel:** `✓ N konë u hoqën nga mbivendosja`. Nëse del 0,
   rruga jote s'kishte mbivendosje. Kjo është mënyra më e shpejtë për të parë
   nëse rregullimi po vepron te kthesa jote.
4. Ruhet gjithçka nga 0.9.27: **Hapësira shtesë e rimorkios** vetëm në anën e saj,
   slideri që s'mbishkruhet, përmasat në kornizën e rimorkios; dhe nga 0.9.26:
   zbulimi me **co-motion** për Node Grabber (CTRL + klik majtë → mesi, pa kuk /
   pa `L` / pa World Editor), vija e qendrës, zarfi ±20° për drive-t e vjetra,
   **↻ RIPROVË ZBULIMIN**, `✓ N pika të vijës së rimorkios`.

Rezultati në të njëjtin mock:

    spiral N=200 : 0 konë brenda korridorit · 3 goditje · 43 konë të hequra · 76 mbeten
    spiral N=320 : 0 konë brenda korridorit · 3 goditje · 45 konë të hequra · 70 mbeten
    rreth i pastër: 0 / 0 · 50 / 78 konë (të pandryshuar)
    drive i drejtë: 0 konë të hequra

PSE ZBULIMI BËHET ME LËVIZJE, JO ME EVENT
-----------------------------------------
Nuk ka asnjë API publike që t'i listojë lidhjet nyje-në-nyjë. `be.nodeGrabber:
fixCurrentNode()` lidh vetëm nyjet nën kursor dhe s'ka funksion me ID;
`clearVehicleFixedNodes(vid)` fshin vetëm nyjet e fiksuara në ajër. Eventet
`onCouplerAttached` / `onCouplerDetached` janë për kukun e vërtetë dhe nuk
ndizen këtu. Prandaj sinjali i besueshëm është co-motion.

KUFI I NATYRSHËM — KJO ËSHTË E RËNDËSISHME
------------------------------------------
Konet janë **statike** dhe ndërtohen nga **drive-i i regjistruar**. Në panel ke
"1 saved drive(s)" dhe "READY TO SKETCH" (s'je duke regjistruar): po sillesh
lirisht mbi një pistë të ndërtuar më parë. Nëse manovra e tanishme është më e
ngushtë / ndryshe nga ajo që u regjistrua, rimorkioja e përmbysur mund të shkojë
aty ku s'ka qenë kurrë gjatë regjistrimit — dhe asnjë korridor i paracaktuar
(kjo vlen për çdo mod me konë statike) nuk mund ta parashikojë atë. Për atë rast:

* **Regjistro kthesën** që do ta bësh: **START → vozit spin-in → STOP & BUILD**.
  Çdo pikë do ta ruajë pozitën e vërtetë të rimorkios së përmbysur dhe 0.9.28
  do t'i heqë konet prej saj; ose
* jep pak hapësirë: **Hapësira shtesë e rimorkios** 0.8–1.5 m dhe **Margjinë
  sigurie** 0.3–0.5 m (të dyja i ke në 0 m tani), pastaj **REBUILD**. Kjo s'e
  zgjeron anën bosh — vetëm anën ku regjistrimi thotë se kalon rimorkioja.

ÇFARË TË KONTROLLOSH NË LOJË
----------------------------
1. Vetëm ky ZIP në Mods (hiq çdo DriftSketch tjetër), pa e nxjerrë,
   **rindis BeamNG.drive**.
2. Ngjite rimorkion me **CTRL + klik majtë → mesi i mausit**. Mos hap World
   Editor, mos shtyp `L`.
3. **↻ RIPROVË ZBULIMIN** ose **REBUILD** mbi drive-in e ruajtur. Shiko nëse
   shfaqet `✓ N konë u hoqën nga mbivendosja` — po, do të thotë se krehri i
   konëve brenda rimorkios është hequr.
4. Bëj të njëjtën kthesë. Nëse prap ka konë aty ku rimorkioja shkon vetëm tani
   (jo gjatë regjistrimit), atëherë është kufi i konëve statike → regjistro
   run-in me atë kthesë, si më sipër.

TESTET
------
Lua **89/0** · UI **86/0** · statike **217/202/0** · `loadfile` + `node --check`
+ css-tree · 14 asset-e identikë me 0.9.4. Testi i ri (seksioni 7) ndërton dy
spirale dhe dy rrathë të pastër: kërkon 0 konë brenda korridorit, pothuaj 0 brenda
drejtkëndëshave, >20 konë të hequra të raportuara në panel, vijat e jashtme të
ruajtura dhe **0 konë të hequra** te një drive i drejtë. Me Lua-n e 0.9.27 ky
seksion dështon (23 konë brenda, 212 goditje). Kontrolli i koneve përdor
drejtkëndëshin e rrotulluar, jo një rreth rreth qendrës.

PERFORMANCA
-----------
Kontrolli i ri është një kalim i vetëm në ndërtim me rrjet hapësinor (qeliza
4 m, fqinjësi 3×3): O(konë + pika). Nuk ka skanim konësh në `onUpdate`, nuk ka
fizikë, nuk ka `TSStatic` shtesë — vetëm disa konë më pak. Zbulimi i rimorkios
mbetet i memorizuar 1.5 s / max 32 objekte / 3 herë/sekondë në replay.

HISTORIA
--------
0.9.4 i pastër. 0.9.23–24 gjerësi simetrike (rrugë e gjerë, prap prek).
0.9.25 vija e qendrës + njëanësore, zbulim me pozitë të fiksuar.
0.9.26 co-motion për Node Grabber + zarf lëkundjeje + butoni i ri-skanimit.
0.9.27 shtesa shkon te rimorkioja (jo ana bosh), slideri s'mbishkruhet.
0.9.28 asnjë kon brenda makinës / rimorkios as në rrugë që mbivendoset.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
