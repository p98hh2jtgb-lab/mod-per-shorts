-- DriftSketch 0.9.20 — visual topple detection includes coupler-linked trailers.
-- Static collision cleanup from 0.9.19 remains; no per-cone JBeam vehicles.
local M = {}
M.version = '0.9.20'

local ASSET_DIR = '/art/shapes/driftsketch_v09/'
local MATERIAL_FILE = ASSET_DIR .. 'main.materials.json'
local GROUP_NAME = 'DriftSketch_Objects'
local LEGACY_CONE_MODEL = 'driftsketchcone' -- clean up 0.9.5 JBeam vehicles after upgrading
local LEGACY_CONE_PREFIX = 'DriftSketchCone_'
local CONE_RADIUS = 0.24       -- includes a little clearance around the 0.41 m base
local CONE_BODY_HEIGHT = 0.66
local CONE_CONTACT_RADIUS = 0.22 -- close to the real base radius, with a small tolerance

local SETTINGS = {
  spacing = 1.0,
  gap = 0.3,
  groundOffset = -0.55,
  maxCones = 2000,             -- restored pre-0.9.5 scene cap for lightweight static cones
  smooth = true,
  keepBuilds = true,
  topple = true,               -- scripted visual knock-over
  coneCollision = false,        -- optional TSStatic visible-mesh contact; off by default
  hudTotal = 0,                 -- 0 means show the real number of generated cones
  hudLabel = 'CONES DOWN',
  hudSize = 1.3,
  hudStyle = 'outline',
  hudCard = false,             -- optional full plaque like the Shorts reference image
  hudOutline = true,
  hudGlow = false,
  hudShadow = true,
  soundEnabled = true,
  soundVolume = 3.0,
  driftWidth = false
}

local recording = false
local points = {}
local activeVehicleId = nil
local activeVehicleName = 'No vehicle'
local savedPaths = {}
local spawned = {}
local spawnedNames = {}
local spawnedPositions = {}
local removedConePositions = {}
local tumbleCones = {}
local movingCones = {}
local couplerLinks = {}
local tumbleCheckClock = 0
local toppledCount = 0
local toppleEventSerial = 0
local tallyRevision = 0
local status = 'Ready. Press Start and drive.'
local statusError = false
local uiClock = 0
local clockTotal = 0
local objectSerial = 0
local sessionTime = (os and os.time and os.time() or 0) % 1000000
local sessionClock = math.floor((os and os.clock and os.clock() or 0) * 1000000)
local sessionRandom = math.random and math.random(0, 999999) or 0
local session = tostring(sessionTime) .. '_' .. tostring(sessionClock) .. '_' .. tostring(sessionRandom)
local collisionDirty = false
local pathRebuildAt = nil
local pendingRestore = false
local restored = false
local materialsLoaded = false

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function truthy(value)
  return not (value == false or value == 'false' or value == 0 or value == nil)
end

local function copyPoints(source)
  local out = {}
  for i, p in ipairs(source) do
    out[i] = {
      x=p.x, y=p.y, z=p.z, fx=p.fx, fy=p.fy,
      carHalfLength=p.carHalfLength, carHalfWidth=p.carHalfWidth
    }
  end
  return out
end

local function pathLength(path)
  local total = 0
  for i = 2, #path do
    local a, b = path[i - 1], path[i]
    local dx, dy = b.x - a.x, b.y - a.y
    total = total + math.sqrt(dx * dx + dy * dy)
  end
  return total
end

-- A short straight drive can finish near its start without being a loop. Require
-- both a nearby endpoint and enough travelled distance before suppressing a cap.
local function isClosedLoop(path)
  if #path < 2 then return false end
  local a, b = path[1], path[#path]
  local dx, dy = b.x - a.x, b.y - a.y
  return dx * dx + dy * dy <= 6.0 * 6.0 and pathLength(path) > 6.0
end

local function currentVehicle()
  if not be or not be.getPlayerVehicleID then return nil, nil end
  local id = be:getPlayerVehicleID(0)
  if not id then return nil, nil end
  local veh
  if be.getObjectByID then
    local ok, value = pcall(be.getObjectByID, be, id)
    if ok then veh = value end
  end
  if not veh and be.getPlayerVehicle then
    local ok, value = pcall(be.getPlayerVehicle, be, 0)
    if ok then veh = value end
  end
  return veh, id
end

local function normalizeObjectId(id)
  local value = tonumber(id)
  if not value or value < 0 or value ~= math.floor(value) then return nil end
  return value
end

local function getObjectById(id)
  if not be or not be.getObjectByID then return nil end
  local ok, object = pcall(be.getObjectByID, be, id)
  return ok and object or nil
end

local function addCouplerLink(objId1, objId2)
  local a, b = normalizeObjectId(objId1), normalizeObjectId(objId2)
  if not a or not b or a == b then return end
  couplerLinks[a] = couplerLinks[a] or {}
  couplerLinks[b] = couplerLinks[b] or {}
  couplerLinks[a][b], couplerLinks[b][a] = true, true
end

local function removeCouplerLink(objId1, objId2)
  local a, b = normalizeObjectId(objId1), normalizeObjectId(objId2)
  if not a or not b then return end
  if couplerLinks[a] then
    couplerLinks[a][b] = nil
    if next(couplerLinks[a]) == nil then couplerLinks[a] = nil end
  end
  if couplerLinks[b] then
    couplerLinks[b][a] = nil
    if next(couplerLinks[b]) == nil then couplerLinks[b] = nil end
  end
end

local function getCoupledVehicleObjects(rootId)
  local root = normalizeObjectId(rootId)
  local result = {}
  if not root then return result end
  local queue, visited = {root}, {[root] = true}
  local head = 1
  while head <= #queue do
    local current = queue[head]
    head = head + 1
    for linkedId in pairs(couplerLinks[current] or {}) do
      if not visited[linkedId] then
        visited[linkedId] = true
        local object = getObjectById(linkedId)
        if object then
          result[#result + 1] = {id=linkedId, object=object}
          queue[#queue + 1] = linkedId
        end
      end
    end
  end
  return result
end

local function vehicleName(veh, id)
  local name
  if core_vehicles and core_vehicles.getCurrentVehicleDetails then
    local ok, details = pcall(core_vehicles.getCurrentVehicleDetails)
    if ok and details and details.model then
      name = ((details.model.Brand and (details.model.Brand .. ' ')) or '') .. tostring(details.model.Name or '')
    end
  end
  if (not name or name == '') and veh then
    local ok, model = pcall(function() return veh.JBeam end)
    if ok and model then name = tostring(model) end
  end
  return (name and name ~= '') and name or ('Vehicle ' .. tostring(id or '?'))
end

local function vehicleNumber(veh, method, fallback, minimum, maximum)
  if not veh or not veh[method] then return fallback end
  local ok, value = pcall(veh[method], veh)
  if not ok or type(value) ~= 'number' or value <= 0 then return fallback end
  return math.max(minimum, math.min(maximum, value))
end

-- Prefer the real OOBB center over the JBeam reference node. This keeps long
-- front/rear overhangs centered inside the generated corridor.
local function vehiclePosition(veh, id)
  if be and be.getObjectOOBBCenterXYZ and id then
    local ok, x, y, z = pcall(be.getObjectOOBBCenterXYZ, be, id)
    if ok and type(x) == 'number' and type(y) == 'number' and type(z) == 'number' then
      return vec3(x, y, z)
    end
  end
  if veh and veh.getPosition then
    local ok, pos = pcall(veh.getPosition, veh)
    if ok then return pos end
  end
  return nil
end

local function vehicleFootprint(veh, id, fx, fy)
  local halfLength = vehicleNumber(veh, 'getInitialLength', 4.8, 1.0, 20.0) * 0.5
  local halfWidth = vehicleNumber(veh, 'getInitialWidth', 2.0, 0.6, 6.0) * 0.5
  if not be or not id or not be.getObjectOOBBHalfAxisXYZ then return halfLength, halfWidth end

  local initialized = true
  if be.getObjectOOBBIsInitialized then
    local ok, value = pcall(be.getObjectOOBBIsInitialized, be, id)
    initialized = ok and not (value == false or value == nil or value == 0)
  end
  if not initialized then return halfLength, halfWidth end

  local axes = {}
  for axis = 0, 2 do
    local ok, x, y = pcall(be.getObjectOOBBHalfAxisXYZ, be, id, axis)
    if not ok or type(x) ~= 'number' or type(y) ~= 'number' then
      return halfLength, halfWidth
    end
    axes[#axes + 1] = {x=x, y=y}
  end
  local rightX, rightY = -fy, fx
  local obbLength, obbWidth = 0, 0
  for _, axis in ipairs(axes) do
    obbLength = obbLength + math.abs(axis.x * fx + axis.y * fy)
    obbWidth = obbWidth + math.abs(axis.x * rightX + axis.y * rightY)
  end
  if obbLength > 0.1 and obbWidth > 0.1 then
    halfLength = math.max(halfLength, math.max(0.5, math.min(10.0, obbLength)))
    halfWidth = math.max(halfWidth, math.max(0.3, math.min(3.0, obbWidth)))
  end
  return halfLength, halfWidth
end

local function vehiclePathPoint(veh, pos, id)
  local fx, fy = 1, 0
  if veh and veh.getDirectionVector then
    local ok, forward = pcall(veh.getDirectionVector, veh)
    if ok and forward then
      local length = math.sqrt(forward.x * forward.x + forward.y * forward.y)
      if length > 0.001 then fx, fy = forward.x / length, forward.y / length end
    end
  end
  local halfLength, halfWidth = vehicleFootprint(veh, id, fx, fy)
  return {
    x=pos.x, y=pos.y, z=pos.z, fx=fx, fy=fy,
    carHalfLength=halfLength, carHalfWidth=halfWidth
  }
end

local function publicState()
  local out = {
    recording = recording,
    pointCount = #points,
    pathLength = pathLength(points),
    buildCount = #savedPaths,
    coneCount = #spawned,
    toppledCount = toppledCount,
    displayTotal = SETTINGS.hudTotal > 0 and SETTINGS.hudTotal or #spawned,
    actualConeCount = #spawned,
    toppleEventSerial = toppleEventSerial,
    eventSession = session,
    tallyRevision = tallyRevision,
    vehicleName = activeVehicleName,
    status = status,
    statusError = statusError,
    version = M.version,
    settings = {}
  }
  for k, v in pairs(SETTINGS) do out.settings[k] = v end
  return out
end

local function sendState()
  if guihooks and guihooks.trigger then guihooks.trigger('driftSketch.state', publicState()) end
  return publicState()
end

local function notifyConeToppled()
  toppledCount = toppledCount + 1
  toppleEventSerial = toppleEventSerial + 1
  if guihooks and guihooks.trigger then
    guihooks.trigger('driftSketch.hit', {
      count = toppledCount,
      eventSerial = toppleEventSerial,
      eventSession = session,
      soundEnabled = SETTINGS.soundEnabled,
      soundVolume = SETTINGS.soundVolume
    })
  end
  sendState()
end

local function deleteList(list)
  for _, obj in ipairs(list) do
    if obj and obj.delete then pcall(function() obj:delete() end) end
  end
end

local function removeMarkers()
  -- Remove cached mesh collision before dropping the tracking tables.
  for _, cone in ipairs(tumbleCones) do
    if cone.collisionEnabled then
      if cone.object and cone.object.setField then
        pcall(cone.object.setField, cone.object, 'collisionType', 0, 'None')
      end
      collisionDirty = true
    end
  end
  deleteList(spawned)
  spawned = {}
  spawnedNames = {}
  spawnedPositions = {}
  tumbleCones = {}
  movingCones = {}
  tumbleCheckClock = 0
  toppledCount = 0
  tallyRevision = tallyRevision + 1
end

local function reloadCollision()
  if not collisionDirty then return end
  if be and be.reloadCollision then pcall(be.reloadCollision, be) end
  collisionDirty = false
end

local function findGroup()
  if not scenetree or not scenetree.findObject then return nil end
  local ok, group = pcall(scenetree.findObject, GROUP_NAME)
  if ok and group then return group end
  return nil
end

local function objectGroup()
  local group = findGroup()
  if group or not createObject then return group end
  local ok, created = pcall(createObject, 'SimGroup')
  if not ok or not created then return nil end
  ok = pcall(function()
    created.canSave = false
    created:registerObject(GROUP_NAME)
    local mission = scenetree and scenetree.MissionGroup
    if mission then
      if mission.addObject then mission:addObject(created) else mission:add(created) end
    end
  end)
  return ok and created or nil
end

local function sweepGroup()
  local group = findGroup()
  if not group then return 0 end
  local count = 0
  pcall(function() count = group:getCount() end)
  if count > 0 then
    pcall(function() group:deleteAllObjects() end)
    collisionDirty = true
  end
  return count
end

local function objectName(obj)
  if not obj or not obj.getField then return '' end
  local ok, value = pcall(obj.getField, obj, 'name', '')
  return ok and type(value) == 'string' and value or ''
end

local function sceneObjectExists(name)
  if not name or name == '' or not scenetree or not scenetree.findObject then return true end
  local ok, object = pcall(scenetree.findObject, name)
  if not ok then return true end
  return object ~= nil
end

local function isRemovedPosition(x, y)
  local toleranceSq = 0.15 * 0.15
  for _, p in ipairs(removedConePositions) do
    local dx, dy = (p.x or 0) - x, (p.y or 0) - y
    if dx * dx + dy * dy <= toleranceSq then return true end
  end
  return false
end

local function rememberRemovedPosition(position)
  if not position or type(position.x) ~= 'number' or type(position.y) ~= 'number' then return false end
  if isRemovedPosition(position.x, position.y) then return false end
  removedConePositions[#removedConePositions + 1] = {
    x=position.x, y=position.y, z=tonumber(position.z) or 0
  }
  return true
end

-- World Editor deletes the scene object, but our topple metadata remains. Snapshot
-- those holes so a replay/extension reload won't regenerate the deleted cones.
local function captureManualDeletions()
  local group = findGroup()
  if not group or not scenetree or not scenetree.findObject then return 0 end
  local groupCount = 0
  pcall(function() groupCount = group:getCount() end)
  if groupCount <= 0 then return 0 end -- scene teardown, not an editor deletion
  local added = 0
  for i = 1, #spawned do
    local name, position = spawnedNames[i], spawnedPositions[i]
    if name and position and not sceneObjectExists(name) then
      if rememberRemovedPosition(position) then added = added + 1 end
    end
  end
  return added
end

-- 0.9.5 spawned one complete JBeam vehicle per cone. Remove leftovers when
-- loading, starting, rebuilding, or clearing, even if the old model no longer loads.
local function sweepLegacySoftCones()
  if not be or not be.getObjectCount or not be.getObject then return 0 end
  local ok, total = pcall(be.getObjectCount, be)
  if not ok or type(total) ~= 'number' then return 0 end
  local count = 0
  for i = total - 1, 0, -1 do
    local got, obj = pcall(be.getObject, be, i)
    if got and obj then
      local modelOk, model = pcall(function() return obj.JBeam end)
      local name = objectName(obj)
      if (modelOk and model == LEGACY_CONE_MODEL)
          or name:sub(1, #LEGACY_CONE_PREFIX) == LEGACY_CONE_PREFIX then
        pcall(function() obj:delete() end)
        count = count + 1
        collisionDirty = true
      end
    end
  end
  if count > 0 and log then
    log('I', 'driftSketch', string.format('Removed %d legacy 0.9.5 cone vehicle(s).', count))
  end
  return count
end

local function clearAll()
  recording = false
  points = {}
  savedPaths = {}
  removedConePositions = {}
  pathRebuildAt = nil
  pendingRestore = false
  removeMarkers()
  sweepGroup()
  sweepLegacySoftCones()
  -- Clear is an explicit cleanup request: force a physics refresh even if the
  -- scene objects were already deleted and the tracking list is now empty.
  collisionDirty = true
  reloadCollision()
end

local function markerRadius()
  return CONE_RADIUS
end

-- Path shaping (0.9.1) -------------------------------------------------------------
-- The recorded centre line is resampled every PATH_STEP metres and, with Smooth path
-- ON, Gaussian-filtered over a few metres: steering corrections and drift wobble no
-- longer reach the marker lines. The corridor is the real car width plus Gap on each
-- side; drift width comes from the rotated car footprint and eases only locally.

local PATH_STEP = 0.25
local PATH_MAX_SAMPLES = 24000
local SMOOTH_SIGMA = 2.0       -- metres along the path (Smooth path ON)
local WIDTH_SIGMA = 0.55       -- metres: local width changes, without long wide tails
local DRIFT_EXTRA_MAX = 2.0    -- Drift widen adds at most this per side

local function median(values, fallback)
  if #values == 0 then return fallback end
  local sorted = {}
  for i, value in ipairs(values) do sorted[i] = value end
  table.sort(sorted)
  return sorted[math.floor((#sorted + 1) / 2)]
end

-- Real car size of one drive: the median of all samples, so a single OOBB spike
-- (a crash, a door) cannot make one stretch of the corridor wider.
local function driveCarSize(source)
  local widths, lengths = {}, {}
  for _, p in ipairs(source) do
    if type(p.carHalfWidth) == 'number' then widths[#widths + 1] = p.carHalfWidth end
    if type(p.carHalfLength) == 'number' then lengths[#lengths + 1] = p.carHalfLength end
  end
  return median(widths, 1.0), median(lengths, 2.4)
end

-- Samples every <= PATH_STEP metres along the recorded drive. Every recorded point
-- is kept as a sample, so the corridor sees the real extremes of the driven line.
local function resampleCenter(source)
  local out = {}
  local total = pathLength(source)
  if #source < 2 or total < 0.05 then
    for i, p in ipairs(source) do out[i] = {x = p.x, y = p.y, z = p.z, fx = p.fx, fy = p.fy} end
    return out, PATH_STEP
  end
  local step = math.max(PATH_STEP, total / PATH_MAX_SAMPLES)
  local function sample(a, b, t)
    local q = {x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t, z = a.z + (b.z - a.z) * t}
    if a.fx and a.fy and b.fx and b.fy then
      local fx, fy = a.fx + (b.fx - a.fx) * t, a.fy + (b.fy - a.fy) * t
      local size = math.sqrt(fx * fx + fy * fy)
      if size > 0.001 then q.fx, q.fy = fx / size, fy / size else q.fx, q.fy = b.fx, b.fy end
    end
    return q
  end
  out[1] = sample(source[1], source[1], 0)
  for i = 1, #source - 1 do
    local a, b = source[i], source[i + 1]
    local dx, dy = b.x - a.x, b.y - a.y
    local length = math.sqrt(dx * dx + dy * dy)
    if length > 0.000001 then
      local parts = math.max(1, math.ceil(length / step - 0.0001))
      for k = 1, parts do out[#out + 1] = sample(a, b, k / parts) end
    end
  end
  if #out < 2 then return out, PATH_STEP end
  return out, total / (#out - 1)
end

-- Value at sample `from` of the least-squares line through `count` samples going
-- in direction `dir` (+1 from the start, -1 from the end).
local function fittedEnd(values, from, dir, count)
  local sx, sy, sxx, sxy = 0, 0, 0, 0
  for k = 0, count - 1 do
    local v = values[from + dir * k]
    sx, sy, sxx, sxy = sx + k, sy + v, sxx + k * k, sxy + k * v
  end
  local den = count * sxx - sx * sx
  if math.abs(den) < 1e-9 then return values[from] end
  return (sy * sxx - sx * sxy) / den
end

-- Gaussian filter. anchored = true (positions): the ends are mirrored through a
-- straight fit of the first and last few metres, so the line keeps its end heading,
-- starts and finishes where the car was (minus the wobble) and is filtered right up
-- to the ends. anchored = false (corridor widths): the window shrinks near the
-- ends, so the result never drops below what the running maximum asked for.
local function smoothValues(values, sigma, step, anchored)
  local n = #values
  if sigma <= 0 or n < 3 then return values end
  -- Never wider than the drive itself: a mirror must not run past the other end.
  local radius = math.min(n - 1, math.max(1, math.floor(3 * sigma / step + 0.5)))
  local weights = {}
  for k = 0, radius do weights[k] = math.exp(-0.5 * (k * step / sigma) ^ 2) end
  local first, last = values[1], values[n]
  if anchored then
    local count = math.max(2, math.min(n, math.floor(1.5 * sigma / step + 0.5) + 1))
    first, last = fittedEnd(values, 1, 1, count), fittedEnd(values, n, -1, count)
  end
  local function at(index)
    if index < 1 then return 2 * first - values[math.min(n, 2 - index)] end
    if index > n then return 2 * last - values[math.max(1, 2 * n - index)] end
    return values[index]
  end
  local out = {}
  for i = 1, n do
    local reach = anchored and radius or math.min(radius, i - 1, n - i)
    local sum, weight = values[i] * weights[0], weights[0]
    for k = 1, reach do
      sum = sum + (at(i - k) + at(i + k)) * weights[k]
      weight = weight + 2 * weights[k]
    end
    out[i] = sum / weight
  end
  return out
end

-- Smoothed centre line. rx/ry keep where the car really was at that sample.
local function smoothPath(source)
  local path, step = resampleCenter(source)
  local xs, ys, zs = {}, {}, {}
  for i, p in ipairs(path) do xs[i], ys[i], zs[i] = p.x, p.y, p.z end
  if SETTINGS.smooth then
    xs = smoothValues(xs, SMOOTH_SIGMA, step, true)
    ys = smoothValues(ys, SMOOTH_SIGMA, step, true)
    zs = smoothValues(zs, SMOOTH_SIGMA, step, true)
  end
  for i, p in ipairs(path) do
    p.rx, p.ry = p.x, p.y
    p.x, p.y, p.z = xs[i], ys[i], zs[i]
  end
  -- Tangents over +-1 m of the (already smooth) line.
  local reach = math.max(1, math.floor(1.0 / step + 0.5))
  for i, p in ipairs(path) do
    local a, b = path[math.max(1, i - reach)], path[math.min(#path, i + reach)]
    local dx, dy = b.x - a.x, b.y - a.y
    local size = math.sqrt(dx * dx + dy * dy)
    if size > 0.0001 then
      p.tx, p.ty = dx / size, dy / size
    elseif i > 1 then
      p.tx, p.ty = path[i - 1].tx, path[i - 1].ty
    else
      p.tx, p.ty = p.fx or 1, p.fy or 0
    end
  end
  return path, step
end

-- Distance from the smoothed line to the marker centres on each side. The base is
-- Car half width + Gap + marker radius. Every real car position nearby stays at
-- least that far from the marker. When Drift widen is enabled, each actual vehicle
-- pose contributes its rotated rectangle only where it overlaps this path station.
local function corridorNeeds(path, step, halfWidth, halfLength)
  local margin = SETTINGS.gap + markerRadius()
  local base = halfWidth + margin
  local drift = SETTINGS.driftWidth
  local reachClear = math.floor((base + 1.0) / step + 0.5)
  -- Search broadly, then use each car pose's actual rotated rectangle bounds below.
  local reachDrift = drift and math.floor((halfLength + halfWidth + margin + 0.5) / step + 0.5) or 0
  local reach = math.max(reachClear, reachDrift)
  local left, right = {}, {}
  for i, c in ipairs(path) do
    local tx, ty = c.tx, c.ty
    local nx, ny = -ty, tx
    local needLeft, needRight = base, base
    for j = math.max(1, i - reach), math.min(#path, i + reach) do
      local q = path[j]
      local dx, dy = q.rx - c.x, q.ry - c.y
      local lateral = dx * nx + dy * ny
      local along = dx * tx + dy * ty
      if math.abs(along) < base then
        -- Preserve clearance around the actual driven centre line.
        local half = math.sqrt(base * base - along * along)
        needLeft = math.max(needLeft, lateral + half)
        needRight = math.max(needRight, half - lateral)
      end
      if drift and math.abs(i - j) <= reachDrift then
        local fx, fy = q.fx or tx, q.fy or ty
        local rightX, rightY = -fy, fx
        -- Project the real car rectangle onto this station's tangent/normal.
        -- A straight car contributes its body width only; sideways yaw brings its
        -- length across the corridor, but affects only the locally overlapping path.
        local alongExtent = halfLength * math.abs(fx * tx + fy * ty)
          + halfWidth * math.abs(rightX * tx + rightY * ty) + margin
        if math.abs(along) <= alongExtent then
          local extent = halfLength * math.abs(fx * nx + fy * ny)
            + halfWidth * math.abs(rightX * nx + rightY * ny) + margin
          extent = math.min(math.max(extent, base), base + DRIFT_EXTRA_MAX)
          needLeft = math.max(needLeft, lateral + extent)
          needRight = math.max(needRight, extent - lateral)
        end
      end
    end
    left[i], right[i] = needLeft, needRight
  end
  return left, right, base
end

-- Running maximum, then a Gaussian no wider than that window: the eased width is
-- never below what any sample needs, and it changes gently.
local function easeNeeds(values, step)
  local radius = math.max(1, math.floor(3 * WIDTH_SIGMA / step + 0.5))
  local maxed = {}
  for i = 1, #values do
    local high = values[i]
    for j = math.max(1, i - radius), math.min(#values, i + radius) do
      if values[j] > high then high = values[j] end
    end
    maxed[i] = high
  end
  return smoothValues(maxed, radius * step / 3, step, false)
end

-- On the inside of a turn tighter than the corridor the offset line folds back over
-- itself. A point that lies inside the corridor of any other sample is dropped.
-- Smooth path OFF follows the raw line, whose small wobble may come a little closer
-- to a neighbouring sample: there only a deep intrusion (a real fold) is dropped.
local function markFolds(line, path, offsetsLeft, offsetsRight)
  local depth = SETTINGS.smooth and 1.0 or 0.8
  local largest = 0
  for i = 1, #path do largest = math.max(largest, offsetsLeft[i], offsetsRight[i]) end
  local cell = math.max(2.0, largest)
  local grid = {}
  for index, c in ipairs(path) do
    local key = math.floor(c.x / cell) * 1000000 + math.floor(c.y / cell)
    local bucket = grid[key]
    if not bucket then bucket = {}; grid[key] = bucket end
    bucket[#bucket + 1] = index
  end
  for _, q in ipairs(line) do
    local gx, gy = math.floor(q.x / cell), math.floor(q.y / cell)
    local blocked = false
    for ox = -1, 1 do
      for oy = -1, 1 do
        local bucket = grid[(gx + ox) * 1000000 + gy + oy]
        if bucket then
          for _, index in ipairs(bucket) do
            local c = path[index]
            local dx, dy = q.x - c.x, q.y - c.y
            local side = (dx * -c.ty + dy * c.tx) >= 0 and offsetsLeft[index] or offsetsRight[index]
            local limit = math.min(q.offset, side) * depth - 0.03
            if dx * dx + dy * dy < limit * limit then blocked = true; break end
          end
        end
        if blocked then break end
      end
      if blocked then break end
    end
    q.blocked = blocked
  end
end

-- Resample one offset polyline by its own arc length. Inner and outer curves have
-- different lengths, so each gets independent physical spacing.
local function resampleLine(path, spacing)
  if #path < 2 then return {} end
  local total = pathLength(path)
  if total < 0.05 then return {} end
  local count = math.floor(total / spacing + 0.0001) + 1
  local samples = {}
  local segment, segmentStart, segmentLength = 1, 0, 0
  local function updateSegment()
    local a, b = path[segment], path[segment + 1]
    local dx, dy = b.x - a.x, b.y - a.y
    segmentLength = math.sqrt(dx * dx + dy * dy)
  end
  updateSegment()
  for index = 0, count - 1 do
    local distance = math.min(total, index * spacing)
    while segment < #path - 1 and distance > segmentStart + segmentLength do
      segmentStart = segmentStart + segmentLength
      segment = segment + 1
      updateSegment()
    end
    local a, b = path[segment], path[segment + 1]
    local t = 0
    if segmentLength > 0.0001 then t = math.max(0, math.min(1, (distance - segmentStart) / segmentLength)) end
    local nx, ny = a.nx + (b.nx - a.nx) * t, a.ny + (b.ny - a.ny) * t
    local size = math.sqrt(nx * nx + ny * ny)
    if size > 0.001 then nx, ny = nx / size, ny / size else nx, ny = a.nx, a.ny end
    samples[#samples + 1] = {
      x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t, z = a.z + (b.z - a.z) * t, nx = nx, ny = ny
    }
  end
  return samples
end

-- Markers every `spacing` metres along the kept runs of one line (a folded stretch
-- is a break, never a chord across the corridor), within the object cap.
local function placeAlong(line, spacing, maxSamples)
  local runs, run = {}, nil
  for _, q in ipairs(line) do
    if q.blocked then
      run = nil
    else
      if not run then run = {}; runs[#runs + 1] = run end
      run[#run + 1] = q
    end
  end
  local total = 0
  for _, part in ipairs(runs) do total = total + pathLength(part) end
  local step = spacing
  if total / step + #runs > maxSamples then step = total / math.max(1, maxSamples - #runs) end
  local out = {}
  for _, part in ipairs(runs) do
    for _, q in ipairs(resampleLine(part, step)) do
      if #out >= maxSamples then return out end
      out[#out + 1] = q
    end
  end
  return out
end

-- The end row is dense enough that the traffic cones close the corridor visually,
-- even when the side-line spacing is set wide. Reserve its objects in the drive cap.
local function finishRowPitch()
  return math.max(0.3, math.min(SETTINGS.spacing, markerRadius() * 2.0))
end

local function finishRowCount(span)
  return math.max(2, math.ceil(math.max(0, span) / finishRowPitch()) + 1)
end

-- Two clean marker lines (right, left), the corridor half width, and the finish row.
local function buildOffsetLines(source, spacing, reserveObjects, includeFinishRow, objectCap)
  local path, step = smoothPath(source)
  if #path < 2 then return {{}, {}}, 0, nil end
  local halfWidth, halfLength = driveCarSize(source)
  local needLeft, needRight, base = corridorNeeds(path, step, halfWidth, halfLength)
  local offsetsLeft, offsetsRight = easeNeeds(needLeft, step), easeNeeds(needRight, step)
  local right, left = {}, {}
  for i, c in ipairs(path) do
    local nx, ny = -c.ty, c.tx
    left[i] = {x = c.x + nx * offsetsLeft[i], y = c.y + ny * offsetsLeft[i], z = c.z,
      nx = nx, ny = ny, offset = offsetsLeft[i]}
    right[i] = {x = c.x - nx * offsetsRight[i], y = c.y - ny * offsetsRight[i], z = c.z,
      nx = -nx, ny = -ny, offset = offsetsRight[i]}
  end
  markFolds(left, path, offsetsLeft, offsetsRight)
  markFolds(right, path, offsetsLeft, offsetsRight)
  local finishRow, rowReserve = nil, 0
  if includeFinishRow then
    local c = path[#path]
    local sourceEnd = source[#source] or {}
    local fx, fy = sourceEnd.fx or c.tx, sourceEnd.fy or c.ty
    local facingLength = math.sqrt(fx * fx + fy * fy)
    if facingLength > 0.001 then fx, fy = fx / facingLength, fy / facingLength else fx, fy = c.tx, c.ty end
    local rightX, rightY = -fy, fx
    local endHalfLength = tonumber(sourceEnd.carHalfLength) or halfLength
    local endHalfWidth = tonumber(sourceEnd.carHalfWidth) or halfWidth
    local alongHalf = endHalfLength * math.abs(fx * c.tx + fy * c.ty)
      + endHalfWidth * math.abs(rightX * c.tx + rightY * c.ty)
    -- Put the finish line just beyond the last car footprint, not through the car.
    local extension = math.max(1.5, alongHalf + SETTINGS.gap + markerRadius() + 0.4)
    local zSlope = 0
    if #path > 1 then
      local prev = path[#path - 1]
      local segment = math.sqrt((c.x - prev.x) ^ 2 + (c.y - prev.y) ^ 2)
      if segment > 0.001 then zSlope = clamp((c.z - prev.z) / segment, -0.36, 0.36) end
    end
    local span = offsetsLeft[#path] + offsetsRight[#path]
    finishRow = {
      baseP = c,
      p = {x = c.x + c.tx * extension, y = c.y + c.ty * extension, z = c.z + zSlope * extension},
      extension = extension, zSlope = zSlope,
      tx = c.tx, ty = c.ty, nx = -c.ty, ny = c.tx,
      left = offsetsLeft[#path], right = offsetsRight[#path], count = finishRowCount(span)
    }
    -- Reserve the dense cross-row and both short side extensions in the drive cap.
    local sideStep = math.max(0.5, spacing)
    rowReserve = finishRow.count + 2 * (math.ceil(extension / sideStep) + 1)
  end
  local cap = math.max(0, math.floor(tonumber(objectCap) or SETTINGS.maxCones))
  -- If a kept finish row alone would exceed the remaining global budget, omit
  -- the row rather than exceed the cap or spawn an unbounded number of props.
  if rowReserve >= cap then finishRow, rowReserve = nil, 0 end
  local maxSamples = math.max(1, math.floor((cap - (reserveObjects or 0) - rowReserve) / 2))
  return {placeAlong(right, spacing, maxSamples), placeAlong(left, spacing, maxSamples)}, base, finishRow
end

local function castDown(x, y, fromZ, maxLength)
  if not castRayStatic then return nil end
  local ok, distance = pcall(castRayStatic, vec3(x, y, fromZ), vec3(0, 0, -1), maxLength)
  if ok and type(distance) == 'number' and distance >= 0 and distance < maxLength then
    return fromZ - distance
  end
  return nil
end

local function groundZ(x, y, recordedZ)
  return castDown(x, y, recordedZ + 4, 12) or (recordedZ + SETTINGS.groundOffset)
end

local function ensureMaterials()
  if materialsLoaded then return true end
  if type(loadJsonMaterialsFile) ~= 'function' then return false end
  local loaded = true
  local path = MATERIAL_FILE
  if FS and FS.fileExists then
    local existsOk, exists = pcall(FS.fileExists, FS, path)
    if not existsOk or not exists then
      loaded = false
    else
      local ok, err = pcall(loadJsonMaterialsFile, path)
      if not ok then
        loaded = false
        if log then log('E', 'driftSketch', 'Cannot load materials: ' .. tostring(err)) end
      end
    end
  else
    local ok, err = pcall(loadJsonMaterialsFile, path)
    if not ok then
      loaded = false
      if log then log('E', 'driftSketch', 'Cannot load materials: ' .. tostring(err)) end
    end
  end
  materialsLoaded = loaded
  if loaded and log then log('I', 'driftSketch', 'Loaded cone materials.') end
  return loaded
end

local function rotationFromDir(dx, dy, dz)
  if not quatFromDir then return nil end
  local ok, q = pcall(quatFromDir, vec3(dx, dy, dz or 0))
  if ok and q then return q end
  return nil
end

local function addToScene(obj, group)
  if group then
    local ok = pcall(function() group:addObject(obj) end)
    if ok then return true end
  end
  local mission = scenetree and scenetree.MissionGroup
  if mission then
    return pcall(function()
      if mission.addObject then mission:addObject(obj) else mission:add(obj) end
    end)
  end
  return false
end

local function setConeCollision(obj, enabled)
  if not obj or not obj.setField then return false end
  local collisionType = enabled and 'Visible Mesh' or 'None'
  return pcall(obj.setField, obj, 'collisionType', 0, collisionType)
end

local function spawnVisualCone(x, y, z, rotation, group, name, useInstances, trackObject, collisionEnabled)
  if not createObject then return nil end
  local ok, obj = pcall(createObject, 'TSStatic')
  if not ok or not obj then return nil end
  objectSerial = objectSerial + 1
  obj.shapeName = ASSET_DIR .. 'cone.dae'
  obj.canSave = false
  obj.useInstanceRenderData = useInstances ~= false
  if obj.setField then
    -- Optional TSStatic mesh collision; never create a JBeam vehicle per cone.
    setConeCollision(obj, collisionEnabled == true)
    pcall(obj.setField, obj, 'decalType', 0, 'None')
  end
  if collisionEnabled then collisionDirty = true end
  if rotation and obj.setPosRot then
    obj:setPosRot(x, y, z, rotation.x, rotation.y, rotation.z, rotation.w)
  elseif obj.setPosition then
    obj:setPosition(vec3(x, y, z))
  end
  if obj.setScale then obj:setScale(vec3(1, 1, 1)) end
  local registeredName = string.format('%s%s_%d', name or 'driftSketch_visual_', session, objectSerial)
  obj:registerObject(registeredName)
  addToScene(obj, group)
  if trackObject ~= false then
    local index = #spawned + 1
    spawned[index] = obj
    spawnedNames[index] = registeredName
    spawnedPositions[index] = {x=x, y=y, z=z}
  end
  return obj, registeredName
end

local function quaternionParts(q)
  if not q then return 0, 0, 0, 1 end
  return tonumber(q.x) or 0, tonumber(q.y) or 0,
    tonumber(q.z) or 0, tonumber(q.w) or 1
end

local function multiplyQuaternion(ax, ay, az, aw, bx, by, bz, bw)
  return aw * bx + ax * bw + ay * bz - az * by,
    aw * by - ax * bz + ay * bw + az * bx,
    aw * bz + ax * by - ay * bx + az * bw,
    aw * bw - ax * bx - ay * by - az * bz
end

local function toppleRotation(baseRotation, fallX, fallY, angle)
  -- Rotate the local up-axis toward the direction away from the car.
  local axisX, axisY = -fallY, fallX
  local sine, cosine = math.sin(angle * 0.5), math.cos(angle * 0.5)
  local tx, ty, tz, tw = axisX * sine, axisY * sine, 0, cosine
  local bx, by, bz, bw = quaternionParts(baseRotation)
  return multiplyQuaternion(tx, ty, tz, tw, bx, by, bz, bw)
end

local function spawnCone(x, y, z, rotation, group, name)
  -- Respect World Editor deletions during replay/rebuild restoration.
  if isRemovedPosition(x, y) then return nil end
  -- TSStatic renders cheaply. Contact is visual by default; an optional static
  -- visible-mesh collider gives the vehicle a real hit without any JBeam spawns.
  local collisionEnabled = SETTINGS.coneCollision and SETTINGS.topple
  local obj, registeredName = spawnVisualCone(x, y, z, rotation, group, name, true, true, collisionEnabled)
  if not obj then return nil end
  tumbleCones[#tumbleCones + 1] = {
    object = obj, objectName = registeredName, x = x, y = y, z = z, rotation = rotation,
    group = group, name = name, spawnIndex = #spawned, collisionEnabled = collisionEnabled,
    moving = false, started = false, finished = false, elapsed = 0
  }
  return obj
end

local function vehicleHalfHeight(veh, id)
  if be and id and be.getObjectOOBBHalfAxisXYZ then
    local extent = 0
    for axis = 0, 2 do
      local ok, _, _, z = pcall(be.getObjectOOBBHalfAxisXYZ, be, id, axis)
      if not ok or type(z) ~= 'number' then return 1.2 end
      extent = extent + math.abs(z)
    end
    if extent > 0.1 then return clamp(extent, 0.3, 4.0) end
  end
  return 1.2
end

local function vehicleContactShape(veh, id)
  if not veh or not id then return nil end
  local pos = vehiclePosition(veh, id)
  if not pos or type(pos.x) ~= 'number' or type(pos.y) ~= 'number' or type(pos.z) ~= 'number' then return nil end
  local fx, fy = 1, 0
  if veh.getDirectionVector then
    local ok, forward = pcall(veh.getDirectionVector, veh)
    if ok and forward and type(forward.x) == 'number' and type(forward.y) == 'number' then
      local length = math.sqrt(forward.x * forward.x + forward.y * forward.y)
      if length > 0.001 then fx, fy = forward.x / length, forward.y / length end
    end
  end
  local halfLength, halfWidth = vehicleFootprint(veh, id, fx, fy)
  return {id=id, object=veh, pos=pos, fx=fx, fy=fy,
    halfLength=halfLength, halfWidth=halfWidth, halfHeight=vehicleHalfHeight(veh, id)}
end

local function makeConeMovable(cone)
  if cone.moving then return true end
  if not sceneObjectExists(cone.objectName) then
    rememberRemovedPosition({x=cone.x, y=cone.y, z=cone.z})
    cone.removed, cone.started, cone.finished = true, true, true
    return false
  end
  local replacement, replacementName = spawnVisualCone(cone.x, cone.y, cone.z, cone.rotation,
    cone.group, cone.name, false, false, false)
  if not replacement then return false end
  -- The toppled replacement stays visual-only; remove any remaining contact
  -- from the original before deleting it. Refresh the collision world below.
  if cone.collisionEnabled then
    setConeCollision(cone.object, false)
    collisionDirty = true
  end
  cone.collisionEnabled = false
  if cone.object and cone.object.delete then pcall(cone.object.delete, cone.object) end
  if cone.spawnIndex and spawned[cone.spawnIndex] then
    spawned[cone.spawnIndex] = replacement
    spawnedNames[cone.spawnIndex] = replacementName
  else
    -- Defensive fallback if another code path ever alters the tracked object list.
    local index = #spawned + 1
    spawned[index] = replacement
    spawnedNames[index] = replacementName
    spawnedPositions[index] = {x=cone.x, y=cone.y, z=cone.z}
    cone.spawnIndex = index
  end
  cone.object = replacement
  cone.objectName = replacementName
  cone.moving = true
  return true
end

local function animateMovingCones(dt)
  for i = #movingCones, 1, -1 do
    local cone = movingCones[i]
    cone.elapsed = cone.elapsed + dt
    local progress = clamp(cone.elapsed / 0.28, 0, 1)
    local eased = 1 - (1 - progress) * (1 - progress)
    local angle = (math.pi * 0.5) * eased
    local qx, qy, qz, qw = toppleRotation(
      cone.rotation, cone.fallX, cone.fallY, angle)
    local slide = 0.16 * eased
    local lift = CONE_CONTACT_RADIUS * 0.8 * math.sin(angle)
    local x = cone.x + cone.fallX * slide
    local y = cone.y + cone.fallY * slide
    local z = cone.z + lift
    if cone.object and cone.object.setPosRot then
      pcall(cone.object.setPosRot, cone.object, x, y, z, qx, qy, qz, qw)
    end
    if progress >= 1 then
      cone.finished = true
      table.remove(movingCones, i)
    end
  end
end

local function updateTumbles(dtReal)
  local dt = clamp(tonumber(dtReal) or 0, 0, 0.1)
  if not SETTINGS.topple or #tumbleCones == 0 then
    animateMovingCones(dt)
    return
  end

  tumbleCheckClock = tumbleCheckClock + dt
  if tumbleCheckClock >= 0.033 then
    -- Scan at ~30 Hz, including every vehicle linked by an active coupler.
    tumbleCheckClock = tumbleCheckClock % 0.033
    local veh, id = currentVehicle()
    local contactVehicles = {}
    local seenVehicleIds = {}
    local function addContactVehicle(candidate, candidateId)
      local normalizedId = normalizeObjectId(candidateId)
      if not normalizedId or seenVehicleIds[normalizedId] then return end
      seenVehicleIds[normalizedId] = true
      local shape = vehicleContactShape(candidate, normalizedId)
      if shape then contactVehicles[#contactVehicles + 1] = shape end
    end
    addContactVehicle(veh, id)
    if id then
      for _, coupled in ipairs(getCoupledVehicleObjects(id)) do
        addContactVehicle(coupled.object, coupled.id)
      end
    end

    for _, cone in ipairs(tumbleCones) do
      if not cone.started then
        for _, vehicle in ipairs(contactVehicles) do
          local pos = vehicle.pos
          local verticalOverlap = pos.z + vehicle.halfHeight >= cone.z - 0.03
            and pos.z - vehicle.halfHeight <= cone.z + CONE_BODY_HEIGHT
          if verticalOverlap then
            local dx, dy = cone.x - pos.x, cone.y - pos.y
            local longitudinal = dx * vehicle.fx + dy * vehicle.fy
            local lateral = -dx * vehicle.fy + dy * vehicle.fx
            local excessLong = math.max(0, math.abs(longitudinal) - vehicle.halfLength)
            local excessSide = math.max(0, math.abs(lateral) - vehicle.halfWidth)
            if excessLong * excessLong + excessSide * excessSide
                <= CONE_CONTACT_RADIUS * CONE_CONTACT_RADIUS then
              local distance = math.sqrt(dx * dx + dy * dy)
              if distance > 0.02 then
                cone.fallX, cone.fallY = dx / distance, dy / distance
              else
                cone.fallX, cone.fallY = vehicle.fx, vehicle.fy
              end
              if makeConeMovable(cone) then
                cone.started = true
                cone.elapsed = 0
                movingCones[#movingCones + 1] = cone
                notifyConeToppled()
              else
                -- Keep the original instanced cone upright if cloning fails, but
                -- never leave a failed cone as a hard obstacle.
                if cone.collisionEnabled then
                  setConeCollision(cone.object, false)
                  collisionDirty = true
                end
                cone.collisionEnabled = false
                cone.started, cone.finished = true, true
              end
              break
            end
          end
        end
      end
    end
  end
  animateMovingCones(dt)
end

local function markerRotation(q)
  if q and q.nx and q.ny then return rotationFromDir(-q.nx, -q.ny, 0) end
  return nil
end


-- Finish-only cross-row of traffic cones. The start remains open.
-- Both side lines continue beyond the final car and meet the cross-row.
local function prepareFinishRow(row, lines)
  if not row or not row.p or not row.baseP or not row.tx or not row.ty then return nil end
  local p, baseP = row.p, row.baseP
  local tx, ty, nx, ny = row.tx, row.ty, row.nx, row.ny
  local backset = markerRadius() * 1.8
  local tieThreshold = markerRadius() * 2.0
  local sideStep = math.max(0.5, SETTINGS.spacing)
  local tieDistance = math.max(0, row.extension - backset)
  local pending = {}
  local function queueMarker(x, y, distance, q, faceDirection, prefix)
    local zHint = baseP.z + row.zSlope * distance
    pending[#pending + 1] = {
      x = x, y = y, z = groundZ(x, y, zHint),
      q = q, faceDirection = faceDirection, prefix = prefix
    }
  end
  local function alreadyNear(x, y, line)
    for _, q in ipairs(line or {}) do
      local dx, dy = q.x - x, q.y - y
      if dx * dx + dy * dy <= tieThreshold * tieThreshold then return true end
    end
    for _, q in ipairs(pending) do
      local dx, dy = q.x - x, q.y - y
      if dx * dx + dy * dy <= tieThreshold * tieThreshold then return true end
    end
    return false
  end

  -- Extend both side lines past the last recorded car position so the finish row
  -- joins them beyond the bumper instead of forming a wall through the stopped car.
  for side, lateral in ipairs({-row.right, row.left}) do
    local outwardX, outwardY = side == 1 and -nx or nx, side == 1 and -ny or ny
    local distance = 0
    while distance < tieDistance - 0.001 do
      local x = baseP.x + tx * distance + nx * lateral
      local y = baseP.y + ty * distance + ny * lateral
      if not alreadyNear(x, y, lines[side]) then
        local q = {x = x, y = y, nx = outwardX, ny = outwardY}
        queueMarker(x, y, distance, q, nil, 'driftSketch_finishExtension_')
      end
      distance = distance + sideStep
    end
    local x = baseP.x + tx * tieDistance + nx * lateral
    local y = baseP.y + ty * tieDistance + ny * lateral
    if not alreadyNear(x, y, lines[side]) then
      local q = {x = x, y = y, nx = outwardX, ny = outwardY}
      queueMarker(x, y, tieDistance, q, nil, 'driftSketch_finishTie_')
    end
  end

  local count = math.max(2, row.count or finishRowCount(row.left + row.right))
  local faceDirection = {x = -tx, y = -ty}
  for i = 0, count - 1 do
    local t = i / (count - 1)
    local lateral = -row.right + (row.left + row.right) * t
    local x, y = p.x + nx * lateral, p.y + ny * lateral
    local q = {x = x, y = y, nx = nx, ny = ny}
    queueMarker(x, y, row.extension, q, faceDirection, 'driftSketch_finish_')
  end
  return pending
end

local function spawnFinishRow(pending, group)
  -- Ground rays are resolved before the side cones are created, so a cone cannot
  -- become the false ground surface for its neighbour.
  for _, item in ipairs(pending or {}) do
    spawnCone(item.x, item.y, item.z, markerRotation(item.q), group, item.prefix)
  end
end

local function buildPath(path, group, objectCap)
  if #path < 2 or (tonumber(objectCap) or 0) < 2 then return 0 end
  local closedLoop = isClosedLoop(path)
  local includeFinishRow = not closedLoop
  local lines, _, finishRow = buildOffsetLines(path, math.max(0.5, SETTINGS.spacing), 0,
    includeFinishRow, objectCap)
  local before = #spawned
  local finishObjects = finishRow and prepareFinishRow(finishRow, lines) or nil
  local count = math.max(#lines[1], #lines[2])
  for index = 1, count do
    for _, line in ipairs(lines) do
      local q = line[index]
      if q then
        spawnCone(q.x, q.y, groundZ(q.x, q.y, q.z), markerRotation(q), group, 'driftSketch_')
      end
    end
  end
  if finishObjects then spawnFinishRow(finishObjects, group) end
  return #spawned - before
end

local function rebuildEverything()
  removeMarkers()
  sweepLegacySoftCones()
  reloadCollision()
  ensureMaterials()
  local group = objectGroup()
  local remaining = SETTINGS.maxCones
  for _, path in ipairs(savedPaths) do
    if remaining < 2 then break end
    local created = buildPath(path, group, remaining)
    remaining = math.max(0, remaining - created)
  end
  reloadCollision()
  return #spawned
end

function M.start()
  if recording then return sendState() end
  sweepLegacySoftCones()
  reloadCollision()
  if not SETTINGS.keepBuilds then
    savedPaths = {}
    removedConePositions = {}
    removeMarkers()
    sweepLegacySoftCones()
    reloadCollision()
  end
  local veh, id = currentVehicle()
  activeVehicleId = id
  activeVehicleName = vehicleName(veh, id)
  points = {}
  recording = true
  statusError = false
  status = id and ('Recording ' .. activeVehicleName .. '…') or 'Recording armed. Enter a vehicle.'
  return sendState()
end

function M.stop()
  if not recording then return sendState() end
  recording = false
  if #points < 2 or pathLength(points) < 1.0 then
    statusError = true
    status = 'Drive at least 1 metre before Stop & Build.'
    return sendState()
  end
  savedPaths[#savedPaths + 1] = copyPoints(points)
  sweepLegacySoftCones()
  reloadCollision()
  ensureMaterials()
  local remaining = math.max(0, SETTINGS.maxCones - #spawned)
  local created = buildPath(points, objectGroup(), remaining)
  reloadCollision()
  statusError = created == 0
  if created > 0 then
    local interaction
    if SETTINGS.coneCollision and SETTINGS.topple then
      interaction = 'cones with optional physical contact and visual topple'
    elseif SETTINGS.coneCollision then
      interaction = 'visual cones (turn on topple for physical contact)'
    elseif SETTINGS.topple then
      interaction = 'visual cones with touch topple'
    else
      interaction = 'visual-only cones'
    end
    status = string.format('Built %d %s. They remain in the scene for replay.', created, interaction)
  elseif remaining < 2 then
    status = 'The scene cone cap is full. The drive was saved; raise the cap or Clear, then Rebuild.'
  else
    status = 'No cones could be created. Check the BeamNG console for errors.'
  end
  return sendState()
end

local function rebuildSavedPaths(resetRemoved)
  if recording then
    statusError = true
    status = 'Stop recording before Rebuild.'
    return sendState()
  end
  pathRebuildAt = nil
  if resetRemoved then removedConePositions = {} end
  if #savedPaths == 0 then
    removeMarkers()
    sweepLegacySoftCones()
    reloadCollision()
    statusError = false
    status = 'No saved drive yet. Press Start first.'
    return sendState()
  end
  local created = rebuildEverything()
  statusError = created == 0
  status = string.format('Rebuilt %d cones across %d saved drive(s).',
    created, #savedPaths)
  return sendState()
end

function M.rebuild()
  -- The UI button is an explicit opt-in to restore editor-removed cones.
  return rebuildSavedPaths(true)
end

function M.clear()
  clearAll()
  statusError = false
  status = 'All generated cones and saved drives were cleared.'
  return sendState()
end

local function normalizeSetting(key, value)
  local number = tonumber(value)
  if key == 'spacing' then return clamp(number or SETTINGS.spacing, 0.5, 10.0) end
  if key == 'gap' then return clamp(number or SETTINGS.gap, 0.0, 3.0) end
  if key == 'groundOffset' then return clamp(number or SETTINGS.groundOffset, -2.0, 1.0) end
  if key == 'maxCones' then return math.floor(clamp(number or SETTINGS.maxCones, 100, 4000) + 0.5) end
  if key == 'hudTotal' then return math.floor(clamp(number or SETTINGS.hudTotal, 0, 9999999) + 0.5) end
  if key == 'hudSize' then return clamp(number or SETTINGS.hudSize, 0.5, 3.0) end
  if key == 'hudStyle' then
    local style = tostring(value or '')
    if style == 'neon' or style == 'outline' then return style end
    -- Map the removed 0.9.13/0.9.14 styles to the clean outline preset.
    if style == 'slant' or style == 'condensed' or style == 'glow' then return 'outline' end
    return SETTINGS.hudStyle
  end
  if key == 'hudOutline' or key == 'hudGlow' or key == 'hudShadow' or key == 'hudCard' then return truthy(value) end
  if key == 'soundVolume' then return clamp(number or SETTINGS.soundVolume, 0, 5) end
  if key == 'hudLabel' then
    local text = tostring(value or ''):gsub('[\r\n\t]', ' '):gsub('%s+', ' ')
    text = text:gsub('^%s+', ''):gsub('%s+$', '')
    if #text > 48 then text = text:sub(1, 48) end
    return text
  end
  if key == 'smooth' or key == 'keepBuilds' or key == 'topple' or key == 'coneCollision' or key == 'soundEnabled' or key == 'driftWidth' then
    return truthy(value)
  end
  return nil
end

local function applyCollisionSetting(enabled)
  local count = 0
  enabled = enabled == true
  for _, cone in ipairs(tumbleCones) do
    if not cone.started and cone.object and cone.collisionEnabled ~= enabled
        and setConeCollision(cone.object, enabled) then
      cone.collisionEnabled = enabled
      count = count + 1
    end
  end
  if count > 0 then
    collisionDirty = true
    reloadCollision()
  end
  return count
end

function M.setSetting(key, value)
  local normalized = normalizeSetting(key, value)
  if normalized == nil then return sendState() end
  local changed = SETTINGS[key] ~= normalized
  SETTINGS[key] = normalized
  if key == 'hudStyle' then
    SETTINGS.hudGlow = normalized == 'neon'
    SETTINGS.hudShadow = normalized == 'outline'
  end
  if (key == 'coneCollision' or key == 'topple') and changed then
    local collisionActive = SETTINGS.coneCollision and SETTINGS.topple
    local affected = applyCollisionSetting(collisionActive)
    if key == 'topple' and not SETTINGS.coneCollision then return sendState() end
    statusError = false
    if SETTINGS.coneCollision and not SETTINGS.topple then
      status = 'Physical cone contact waits until “Rrëzohen kur preken” is ON.'
    elseif collisionActive then
      status = string.format('Static cone collision enabled for %d upright cone(s). Check FPS; turn it off if needed.', affected)
    else
      status = string.format('Static cone collision disabled for %d upright cone(s).', affected)
    end
    return sendState()
  end
  local idle = not recording
  if key == 'driftWidth' or key == 'smooth' then
    if changed and idle and #savedPaths > 0 then return rebuildSavedPaths(false) end
  elseif key == 'gap' or key == 'spacing' or key == 'groundOffset' or key == 'maxCones' then
    if changed and idle and #savedPaths > 0 then pathRebuildAt = clockTotal + 0.35 end
  end
  return sendState()
end

function M.uiState() return sendState() end

function M.onUpdate(dtReal)
  local dt = tonumber(dtReal) or 0
  uiClock = uiClock + dt
  clockTotal = clockTotal + dt
  if pendingRestore then
    pendingRestore = false
    if not recording and #savedPaths > 0 then
      local created = rebuildEverything()
      statusError = false
      status = string.format('Restored %d cone(s) from %d saved drive(s).',
        created, #savedPaths)
      sendState()
    end
  end
  if pathRebuildAt and clockTotal >= pathRebuildAt then
    pathRebuildAt = nil
    if not recording and #savedPaths > 0 then
      rebuildSavedPaths(false)
      if not statusError then
        status = string.format('Rebuilt with %.2f m gap and %.1f m spacing.', SETTINGS.gap, SETTINGS.spacing)
      end
      sendState()
    end
  end
  if recording then
    local veh, id = currentVehicle()
    if veh and id then
      if activeVehicleId ~= id then
        activeVehicleId = id
        activeVehicleName = vehicleName(veh, id)
        points = {}
        status = 'Vehicle changed. Recording restarted for ' .. activeVehicleName .. '.'
      end
      local pos = vehiclePosition(veh, id)
      if pos then
        local p = vehiclePathPoint(veh, pos, id)
        local last = points[#points]
        if not last then
          points[1] = p
        else
          local dx, dy = p.x - last.x, p.y - last.y
          if dx * dx + dy * dy >= 0.75 * 0.75 then points[#points + 1] = p end
        end
      end
    end
  end
  updateTumbles(dt)
  reloadCollision()
  if uiClock >= 0.25 then
    uiClock = 0
    sendState()
  end
end

local function validPoint(p)
  return type(p) == 'table' and type(p.x) == 'number' and type(p.y) == 'number' and type(p.z) == 'number'
end

local function restoreState(data)
  if restored or type(data) ~= 'table' then return end
  restored = true
  local sameVersion = data.version == M.version
  if type(data.settings) == 'table' then
    for key, value in pairs(data.settings) do
      local reducedLegacyCap = key == 'maxCones' and not sameVersion
        and data.version ~= '0.9.16' and data.version ~= '0.9.17' and data.version ~= '0.9.18' and data.version ~= '0.9.19' and (tonumber(value) or 0) <= 500
      local restoredValue = value
      if not sameVersion then
        if key == 'hudLabel' and data.version ~= '0.9.10' and data.version ~= '0.9.11' and data.version ~= '0.9.12' and data.version ~= '0.9.13' and data.version ~= '0.9.14' and data.version ~= '0.9.15' and data.version ~= '0.9.16' and data.version ~= '0.9.17' and data.version ~= '0.9.18' and data.version ~= '0.9.19' and tostring(value) == 'TOUCHED' then
          restoredValue = 'CONES DOWN'
        elseif key == 'hudSize' and data.version ~= '0.9.10' and data.version ~= '0.9.11' and data.version ~= '0.9.12' and data.version ~= '0.9.13' and data.version ~= '0.9.14' and data.version ~= '0.9.15' and data.version ~= '0.9.16' and data.version ~= '0.9.17' and data.version ~= '0.9.18' and data.version ~= '0.9.19' then
          -- Scale the 0.9.9-and-earlier counter; 0.9.10+ already used this scale.
          restoredValue = (tonumber(value) or SETTINGS.hudSize) * 1.25
        elseif key == 'soundVolume' and data.version ~= '0.9.10' and data.version ~= '0.9.11' and data.version ~= '0.9.12' and data.version ~= '0.9.13' and data.version ~= '0.9.14' and data.version ~= '0.9.15' and data.version ~= '0.9.16' and data.version ~= '0.9.17' and data.version ~= '0.9.18' and data.version ~= '0.9.19' then
          -- v0.9.9 stored 0..1; map its 55% default to 300% gain, capped at 500%.
          local oldVolume = tonumber(value)
          if oldVolume and oldVolume <= 1 then restoredValue = (oldVolume / 0.55) * 3 end
        end
      end
      if SETTINGS[key] ~= nil and (key ~= 'topple' or sameVersion or data.version == '0.9.16' or data.version == '0.9.17' or data.version == '0.9.18' or data.version == '0.9.19') and not reducedLegacyCap then
        local normalized = normalizeSetting(key, restoredValue)
        if normalized ~= nil then SETTINGS[key] = normalized end
      end
    end
  end
  if type(data.settings) == 'table' and data.settings.hudShadow == nil then
    SETTINGS.hudShadow = SETTINGS.hudStyle == 'outline'
  end
  savedPaths = {}
  for _, path in ipairs(type(data.savedPaths) == 'table' and data.savedPaths or {}) do
    if type(path) == 'table' and #path >= 2 then
      local ok = true
      for _, p in ipairs(path) do if not validPoint(p) then ok = false break end end
      if ok then savedPaths[#savedPaths + 1] = copyPoints(path) end
    end
  end
  removedConePositions = {}
  for _, p in ipairs(type(data.removedConePositions) == 'table' and data.removedConePositions or {}) do
    if validPoint(p) then rememberRemovedPosition(p) end
  end
  pendingRestore = #savedPaths > 0
end

function M.onSerialize()
  captureManualDeletions()
  local settings, removed = {}, {}
  for k, v in pairs(SETTINGS) do settings[k] = v end
  for i, p in ipairs(removedConePositions) do
    removed[i] = {x=p.x, y=p.y, z=p.z}
  end
  return {version = M.version, settings = settings, savedPaths = savedPaths,
    removedConePositions = removed}
end

function M.onDeserialized(data)
  restoreState(data)
end

function M.onCouplerAttached(objId1, objId2)
  addCouplerLink(objId1, objId2)
end

function M.onCouplerDetached(objId1, objId2)
  removeCouplerLink(objId1, objId2)
end

function M.onExtensionLoaded(data)
  sweepGroup()
  sweepLegacySoftCones()
  reloadCollision()
  status = 'Ready. Record a drive to place cones that topple on touch.'
  restoreState(data)
  sendState()
  return true
end

function M.onClientEndMission()
  materialsLoaded = false
  couplerLinks = {}
  clearAll()
end

function M.onExtensionUnloaded()
  couplerLinks = {}
  clearAll()
end

return M
