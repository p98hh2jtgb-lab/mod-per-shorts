DRIFTSKETCH 0.9.23 — KONET PËR KERRIN + RIMORKION BASHK
=========================================================
Bazuar te 0.9.4 (versioni që punonte më mirë). S'ka rrëzim, s'ka numra/counter,
s'ka HUD, s'ka tingull, s'ka automjet JBeam për kon. Konet janë mesh-e TSStatic
të lehta; "Solid / car damage" është OFF si parazgjedhje — lëre OFF për FPS.

ÇFARË ËSHTË E RE
----------------
Rimorkioja që e ke "ngjitur" me World Editor (ose që mbahet me collision, JO me
kuk/hitch dhe JO me tastin L) është një automjet më vete që lëviz me pozitë FIKSE
ndaj makinës. Prandaj s'ka event coupler për ta kapur. 0.9.23 e gjen VETË:

1. Gjatë FILLO, mod-i kontrollon vetëm automjetet pranë kerrin (<= 12 m) dhe
   vetëm në çdo pikë të regjistruar të rrugës (çdo >= 0.75 m), JO në çdo kornizë.
2. Nëse një automjet ruan të njëjtën pozitë/kënd relativ ndaj makinës për 3
   pika rresht ndërsa makina lëviz, quhet "i kaptur" (attached). Një makinë e
   parkuar ose që kalon pranë nuk mund ta mbajë atë pozitë, prandaj refuzohet.
3. Gjerësia e korridorit, rreshti i finish-it dhe zgjerimi në drift llogariten
   për TË DY automjetet bashk. Konet vendosen jashtë "rigut" të plotë, kështu
   rimorkioja nuk i prek më konat as në kthesa ku ajo "pret" nga brenda.
4. Një coupler/hitch normal vazhdon të njihet gjithashtu (event-i i tij ruhet).

MANUAL (nëse zbulimi automatik s'e kap)
---------------------------------------
Nëse rimorkioja është larg, ose do ta detyrosh: hap World Editor, selektoje
rimorkion (Object Selection) dhe te paneli shtyp "Përdor rimorkion e zgjedhur".
Mod-i lexon editor.selection.object dhe pranon VETËM automjete (BeamNGVehicle);
konet/prop-at refuzohen. Për ta hequr: "Hiq të zgjedhurën", × në listë ose
"Hiq të gjitha". Lista në panel tregon çfarë është në llogaritje (Auto,
World Editor, Coupler).

ÇELËSAT E RI NË PANEL
---------------------
- "Auto-detect attached trailer" (ON): zbulimi automatik. Fikja e rikthen
  llogaritjen vetëm te kerri; Rebuild e zbaton menjëherë te drive-t e ruajtura.
- "Extra rig clearance" (0–2 m, 0.25 m): pak hapësirë shtesë rreth tërë rigut.
- Butonat e World Editor dhe lista e automjeteve të zbuluara/regjistruara.

INSTALIMI
---------
1. Çaktivizoji/fshiji TË GJITHA ZIP-at e vjetër të DriftSketch (0.9.1–0.9.22).
   Mos i mbaj dy versione aktive bashkë.
2. Kopjo DriftSketch_v0.9.23.zip te Mods PA E NXJERRË nga ZIP-i.
3. RINISE BeamNG.drive që materialet, mesh-et dhe app-i të rikarikohen pastër.
4. Shto panelin DriftSketch te App menu > Add App. Nuk ka app "Counter".

PËRDORIMI
---------
1. FILLO → vozit vijën (me rimorkion të ngjitur) → NDALO & NDËRTO.
2. Zbulimi ndodh vetë pas ~2–3 m vozitje; modulo e aplikon edhe për pikat e
   para, sepse rimorkioja është prapa kerrin. Nuk duhet të bësh asgjë me L.
3. Hap replay-in normal të BeamNG; konat mbeten në skenë.
4. REBUILD rindërton me cilësimet aktuale; CLEAR heq konet, rrathët dhe drive-t.

PERFORMANCA DHE SIGURIA
-----------------------
- Kontrolli i automjeteve bëhet vetëm gjatë regjistrimit, një herë në ~0.75 m,
  dhe vetëm brenda 12 m. Nuk ka skanim të gjithë hartës, as skanim konash për
  kornizë, as animacione, as audio — prandaj FPS-i mbetet si te 0.9.4.
- Regjistrimet janë per-sesion (pastrohen në fund të misionit / ngarkim të ri),
  që ID-të e vjetra të mos përkasin kurrë me një makinë tjetër.
- Konet janë TSStatic me instance rendering dhe collision=None kur "Solid" është
  OFF. Nuk krijohet asnjë automjet JBeam për kon (mënyra e 0.9.5 që ulte FPS-in
  në ~10 nuk rikthehet).
- Me shumë kone FPS-i varet vetëm nga renderimi: provoje me "Performance cap"
  më të ulët dhe rrite gradualisht.

CILËSIMET E PANELIT (0.9.4 + të rejat)
--------------------------------------
Mesh (7 lloje), ngjyrat e gomave, Spacing 0.5–10 m, Gap to car 0–3 m, Mesh scale,
Ground fallback, Performance cap 100–4000, Smooth path, Keep builds, Drift widen,
Start/Finish truss gates (OFF), Solid / car damage (OFF), Rings (OFF) + Count/Size/
Gap/Lift/Follow airborne path, Rebuild, Clear, Clear rings — të gjitha si te 0.9.4.
Të reja: Auto-detect attached trailer (ON), Extra rig clearance, butonat e World
Editor dhe lista e rigut.

MIGRIMI
-------
Cilësimet, drive-t e ruajtura dhe rrathët nga 0.9.4 ruhen. Drive-t e vjetra (pa
të dhëna rigu) rindërtohen saktësisht si më parë; regjistro një run të ri që
korridori ta marrë parasysh rimorkion. Nga 0.9.20/0.9.21/0.9.22 ruhen vetëm
cilësimet e përbashkëta; çelësat e hequr (topple, coneCollision, hud*, sound*)
injorohen dhe nuk rikthejnë rrëzimin apo numrat.

HISTORIA E SHKURTËR
-------------------
0.9.4  versioni i pastër që punonte perfekt; konet TSStatic, pa rrëzim/numra.
0.9.5  konet si automjete JBeam → rënie e madhe FPS-i (NUK rikthehet).
0.9.6  rrëzim vizual. 0.9.8 counter/numrat. 0.9.17 collision fizik (FPS 2–3).
0.9.22 kthim i pastër, vetëm kone statike (pa rrëzim/numra/fizikë/tingull).
0.9.23 kthim te PANELI + motori i 0.9.4, me korridor që llogarit kerrin dhe
       rimorkion bashk pa kuk/hitch. Asnjë nga problemet e mësipërme nuk kthehet.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
