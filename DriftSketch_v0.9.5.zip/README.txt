DRIFTSKETCH 0.9.5 — TRAFFIC CONES QË RRËZOHEN
================================================

DriftSketch regjistron vijën e vozitjes dhe vendos vetëm traffic cones në të dy
anët. Konat fizike janë props JBeam me masë totale afërsisht 1 kg secila; kur
makina i prek, duhet t'i shtyjë, t'i rrëshqasë ose t'i rrëzojë, jo të përplaset
me një mesh statik si me mur.

INSTALIMI
---------
1. Në BeamNG.drive > Mods > Open Mod Folder, fshiji ZIP-at e vjetër
   DriftSketch (p.sh. 0.9.1–0.9.4). Mos i lër dy versione aktive bashkë.
2. Kopjo DriftSketch_v0.9.5.zip në folderin Mods pa e nxjerrë nga ZIP-i.
3. Aktivizo DriftSketch te Mod Manager nëse duhet dhe rinise BeamNG.drive.
4. Në hartë: App menu > Add App > DriftSketch.

PËRDORIMI
---------
1. Zgjidh hapësirën mes konave dhe distancën nga makina.
2. Lëre "Fizikë: rrëzohen kur goditen" ON për kone të lëvizshme. Kjo është
   mënyra e parazgjedhur. OFF i lë konat vetëm vizuale, pa collision.
3. Shtyp FILLO, vozit vijën, pastaj NDALO & NDËRTO.
4. Hap replay-in normal të BeamNG; konat e krijuara mbeten në skenë.
5. REBUILD i rindërton drive-t e ruajtura me cilësimet aktuale. CLEAR heq vetëm
   objektet dhe drive-t e krijuara nga DriftSketch.

ÇFARË KA NDRYSHUAR NË 0.9.5
---------------------------
- U hoqën tire stacks, kerbs, apex bumps, flamujt, tabelat e frenimit, porta
  START/FINISH dhe rrathët. Tash mod-i është vetëm për traffic cones.
- Në vend të TSStatic me collision të palëvizshëm, mënyra fizike përdor modelin
  JBeam "driftsketchcone". Nyjet e tij kanë masë totale 1 kg dhe formojnë trup
  të lehtë që mund të lëvizë e të përmbyset.
- Nëse modeli JBeam nuk mund të krijohet, fallback-u është vetëm vizual dhe
  paneli tregon paralajmërim; mod-i nuk kthehet te collision statik i fortë.
- Kufiri i konave është global për skenën (50–500, parazgjedhja 200), që
  disa drive të ruajtura të mos krijojnë pa fund objekte fizike.
- Drive-t e ruajtura nga versionet e vjetra mbeten të përdorshme; objektet e
  vjetra statike pastrohen kur ngarkohet versioni i ri.

CILËSIMET
---------
- Hapësira: largësia mes konave në të njëjtën vijë.
- Hapësira nga kerri: largësia e konave nga ana e veturës; gjerësia e makinës
  matet automatikisht.
- Kufiri total i konave: numri maksimal i objekteve për tërë skenën.
- Lartësia rezervë: përdoret vetëm kur raycast-i nuk gjen sipërfaqen e tokës.
- Vijë e lëmuar: zbut korrigjimet e timonit dhe dridhjet e drift-it.
- Zgjero në drift: hap korridorin lokalisht kur vetura është anash.
- Ruaj pistat: mban drive-t e mëparshme; ato ndajnë të njëjtin kufi total.

SHËNIM PËR PERFORMANCËN DHE TESTIMIN
------------------------------------
Konat fizike janë objekte JBeam, jo mesh-e dekorative. Mbaje kufirin e konave
në vlera të arsyeshme; ule nëse simulimi ngadalësohet. Nuk është kryer test
brenda BeamNG.drive në këtë paketim. Sintaksa, struktura e paketës, lidhja e
mesh-it/materialeve dhe masa e deklaruar e JBeam-it janë kontrolluar, por
ndjesia e përplasjes dhe sjellja e saktë duhet provuar në lojë.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
