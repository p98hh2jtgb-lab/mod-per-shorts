DRIFTSKETCH 0.9.24 — KONET PËR KERRIN + RIMORKION BASHK
=========================================================
Bazuar te 0.9.4 (versioni që punonte më mirë). S'ka rrëzim, s'ka numra/counter,
s'ka HUD, s'ka tingull, s'ka automjet JBeam për kon. Konet janë mesh-e TSStatic
të lehta; "Solid / car damage" është OFF si parazgjedhje — lëre OFF për FPS.

PSE 0.9.23 NUK E RREGULLOI PROBLEMIN
------------------------------------
Screenshot-et tregonin v0.9.23 me një **drive të ruajtur nga 0.9.4**
(434 pika / 496.5 m / 1992 kone, "Rebuilt: gap 0.00 m, spacing 0.5 m").
Zbulimi i 0.9.23 ndodhte VETËM gjatë regjistrimit të një run-i të ri; një drive
i vjetër nuk ka asnjë të dhënë rimorkioje, prandaj REBUILD e rindërtonte saktë
njësoj si më parë. Për më tepër seksioni i ri ishte në FUND të panelit, jashtë
ekranit, kështu që butoni i World Editor nuk dukej fare.

ÇFARË NDRYSHOI TE 0.9.24 (RREGULLIMI I VËRTETË)
-----------------------------------------------
1. **Gjerësia shtesë për rimorkio / Trailer width** (0–4 m, parazgjedhje 2.0 m)
   aplikohet në **çastin e NDËRTIMIT** të koneve, në TË DYJA anët, për ÇDO drive
   — përfshirë drive-t e ruajtura nga 0.9.4. Prandaj mjafton ta instalosh dhe/ose
   të shtypësh **REBUILD**: konet hapen menjëherë, pa regjistruar vijën përsëri.
   Vendos 0 m nëse vozit pa rimorkio (kthehen vijat e ngushta si te 0.9.4).
   Parazgjedhja është bujare (2.0 m); uli në 1.0–1.5 m nëse vijat duken shumë larg, ose rrite në 3 m nëse rimorkioja pret nga brenda në kthesa.
2. Seksioni **RIMORKIO / TRAILER** u ngjit në **KRYE** të panelit, direkt nën
   START / STOP, që të jetë i dukshëm pa scroll.
3. **Përdor rimorkion e zgjedhur** tani mat pozitën dhe gjerësinë e objektit të
   selektuar në World Editor, vendos vetë gjerësinë e duhur dhe **rindërton
   pikën menjëherë** — pranon edhe prop-a TSStatic (rimorkio të ngjitura si
   objekt skene), jo vetëm automjete BeamNGVehicle. Konet e vetë mod-it dhe
   makina jote refuzohen.
4. **Zbulimi automatik punon edhe gjatë REPLAY-T / kur je ulur**, jo vetëm gjatë
   FILLO: nëse një automjet afër ruan pozitë fikse ndaj makinës ndërsa ajo lëviz
   (si rimorkioja e ngjitur me World Editor apo me collision), mod-i e gjen pas
   3 matjesh, vendos gjerësinë dhe rindërton një herë. Pa kuk/hitch, pa L.
5. Zbulimi gjatë regjistrimit mbetet (3 pika rresht, pozitë/kënd fiks), si dhe
   event-et e coupler/hitch. Të gjitha regjistrimet janë per-sesion.

SI TA PËRDORËSH (30 SEKONDA)
-----------------------------
1. Çaktivizoji/fshiji TË GJITHA ZIP-at e vjetër DriftSketch (0.9.1–0.9.23).
   Mos i mbaj dy versione aktive bashkë. Kopjo DriftSketch_v0.9.24.zip te Mods
   PA E NXJERRË nga ZIP-i dhe **rindis BeamNG.drive**.
2. Hap panelin DriftSketch. Në krye ke seksionin RIMORKIO / TRAILER.
3. Me drive-n tënd të vjetër tashmë të rindërtuar, konet duhet të jenë më larg.
   Nëse rimorkioja i prek ende: rrit **Gjerësinë shtesë** (p.sh. 2.0–2.5 m) ose
   selekto rimorkion në World Editor → **Përdor rimorkion e zgjedhur**.
   Shtyp **REBUILD WITH CURRENT SETTINGS** nëse nuk u rindërtua vetë.
4. Për një run të ri: FILLO → vozit me rimorkion → NDALO & NDËRTO. Zbulimi
   automatik shton gjerësi lokale aty ku rimorkioja pret nga brenda, mbi
   gjerësinë bazë. Hap replay-in normal të BeamNG; konet mbeten në skenë.

SHËNIME PËR SCREENSHOT-IN TËND
------------------------------
Ke **Gap to car = 0 m** dhe **Spacing = 0.5 m** me **Performance cap 2000** dhe
tashmë **1992 kon/e**. Me gjerësi më të madhe rreshti i finish-it merr disa
objekte më shumë; nëse vijat anësore duken më të rralla, rrit pak Performance
cap (p.sh. 2500). Kjo nuk shton fizikë apo animacion — vetëm mesh-e statike.
Nëse "Drift widen" është ON, ai vazhdon të zgjerojë vetëm aty ku vetura është
anash; gjerësia e rimorkios i shtohet si dysheme, nuk e zëvendëson.

PERFORMANCA DHE SIGURIA
-----------------------
- Gjerësia shtesë është një numër i thjeshtë në llogaritjen e korridorit: **zero
  punë shtesë për kornizë, zero objekte që lëvizin, zero fizikë**.
- Zbulimi gjatë replay-t është 3 herë/sekondë, vetëm brenda 12 m, vetëm derisa
  të gjejë rimorkion (maks. 90 s) dhe vetëm kur makina lëviz. Gjatë regjistrimit
  bëhet vetëm në pikat e rrugës (çdo >= 0.75 m). Nuk skanohen kurrë konet dhe
  nuk bëhet asnjë punë në çdo kornizë.
- Konet janë TSStatic me instance rendering dhe collision=None kur "Solid" është
  OFF. Nuk krijohet asnjë automjet JBeam për kon (mënyra e 0.9.5 që ulte FPS-in
  nuk rikthehet). As rrëzim, as numërues/HUD, as WAV/tingull nuk kthehet.

CILËSIMET E PANELIT
-------------------
Në krye: Gjerësia shtesë për rimorkio, Auto-detect, Margjinë sigurie, butonat e
World Editor dhe lista e objekteve të zbuluara/regjistruara.
Më poshtë, si te 0.9.4: Mesh (7 lloje), ngjyrat e gomave, Spacing, Gap to car,
Mesh scale, Ground fallback, Performance cap, Smooth path, Keep builds, Drift
widen, Start/Finish truss gates (OFF), Solid / car damage (OFF), Rings (OFF) +
Count/Size/Gap/Lift/Follow airborne path, Rebuild, Clear, Clear rings.

MIGRIMI
-------
Cilësimet, drive-t e ruajtura dhe rrathët nga 0.9.4 / 0.9.23 ruhen. Drive-t e
vjetra (pa të dhëna rigu) tani rindërtohen MË TË GJERA falë gjerësisë shtesë;
regjistro një run të ri vetëm nëse do gjerësi lokale sipas kthesave. Nga
0.9.20/0.9.21/0.9.22 ruhen vetëm cilësimet e përbashkëta; çelësat e hequr
(topple, coneCollision, hud*, sound*) injorohen.

HISTORIA E SHKURTËR
-------------------
0.9.4  versioni i pastër që punonte perfekt; konet TSStatic, pa rrëzim/numra.
0.9.5  konet si automjete JBeam → rënie e madhe FPS-i (NUK rikthehet).
0.9.6  rrëzim vizual. 0.9.8 counter/numrat. 0.9.17 collision fizik (FPS 2–3).
0.9.22 kthim i pastër, vetëm kone statike.
0.9.23 paneli + motori i 0.9.4 me zbulim rimorkioje VETËM gjatë regjistrimit —
       nuk prekte drive-t e ruajtura; seksioni ishte jashtë ekranit.
0.9.24 gjerësia aplikohet në ndërtim/rindërtim (vlen për drive-t e vjetra),
       seksioni sipër, matje nga World Editor (edhe prop-a), zbulim në replay.

DriftSketch është standalone dhe nuk kërkon CreatorPack.
